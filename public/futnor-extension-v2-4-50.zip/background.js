// Background service worker — manages session state for Instagram & TikTok
// Persists state to chrome.storage.local for resume capability

const DEFAULT_STATE = {
  isRunning: false,
  isPaused: false,
  reconnecting: false,
  platform: 'instagram',
  tier: 'free',
  config: {
    sessionMin: 10,
    sessionMax: 25,
    scrollWeight: 70,
    likeWeight: 20,
    dmWeight: 10,
    minActionDelay: 2,
    maxActionDelay: 10,
    dailyMaxDMs: 15,
    dailyMaxLikes: 50,
    dailyMaxFollows: 20,
    followEnabled: false,
  },
  targeting: {
    targetTypes: [],
    hashtags: '',
    location: '',
    targetUsername: '',
    targetPostLink: '',
    customUsernames: [],
  },
  aiTargeting: {
    enabled: false,
    keywords: [],
    contentTags: [],
    targetAudience: '',
    searchTerms: [],
  },
  dmTemplates: [],
  stats: {
    dmsSent: 0,
    likesSent: 0,
    followsSent: 0,
    scrolls: 0,
    elapsedTime: 0,
    sessionTime: 0,
  },
  logs: [],
};

let sessionState = { ...DEFAULT_STATE };
let activeAccountUsername = null; // Scopes DM/processed history per Instagram account

// Normalize whatever tier string the dashboard / billing provider pushed into
// `subscriptionTier` (or a START_SESSION message) to a canonical key. Keep in
// sync with normalizeTier() in popup.js so the session block, the popup badge,
// and any future stats surface all agree on whether a user is paid.
// Rationale: Scale- and Growth-plan users on free trials were being reported
// as `scale_trial` / `growth_trial` / `trialing` — the extension never knew
// those names and the popup labelled them "Free Plan", while the block check
// `tier === 'free'` worked by accident (string inequality) but left reviewers
// reading logs confused about which tier was actually active.
function normalizeTier(raw) {
  if (!raw) return 'free';
  let t = String(raw).toLowerCase().trim().replace(/[\s-]+/g, '_');
  if (!t) return 'free';
  const KNOWN = new Set(['free','trial','starter','scale','growth','pro','business','admin']);
  if (KNOWN.has(t)) return t;
  const trialMatch = t.match(/^(?:trial_|trialing_)?(scale|growth|starter|pro|business)(?:_trial(?:ing)?)?$/);
  if (trialMatch) return `${trialMatch[1]}_trial`;
  if (t === 'trialing' || t === 'on_trial' || t === 'in_trial') return 'trial';
  if (t !== 'free') return 'subscribed';
  return 'free';
}

// True if the (normalized) tier grants session access. Accepts any paid tier
// plus any trial variant — all trials unlock full features until they expire.
function isPaidTier(tier) {
  const n = normalizeTier(tier);
  if (!n || n === 'free') return false;
  return true; // trial / *_trial / starter / scale / growth / pro / business / admin / subscribed
}
let sessionLoopActive = false;
let sessionLoopPromise = null; // Track the running session promise
let pendingSessionStart = null;
let pendingSessionStartFingerprint = null;

// ─── MV3 Service Worker Keepalive ──────────────────────────────────────────
// MV3 service workers terminate after ~30 seconds of inactivity.
// Without a keepalive the dashboard sees the extension as "disconnected"
// whenever there is no active session.  We solve this two ways:
//   1. A persistent alarm (fires every 20s) — survives service worker restarts
//      because chrome.alarms persist in Chrome even after the worker dies.
//   2. A long-lived onConnect port (from content.js on the Instagram tab) —
//      the most reliable mechanism; an open port prevents termination entirely.
const IDLE_KEEPALIVE_ALARM = 'futnor-idle-keepalive';

// Create the alarm on every startup if it doesn't already exist.
// Periodic alarms persist across service worker restarts, so this only
// actually creates it once; subsequent startups are a no-op.
//
// IMPORTANT: chrome.alarms.get() only returns a Promise in Chrome 117+.
// Calling .then() on undefined (older Chrome) throws a synchronous TypeError
// that bypasses .catch() — the alarm is never created and the worker sleeps.
// We use the universal callback form instead, which works on all Chrome versions.
chrome.alarms.get(IDLE_KEEPALIVE_ALARM, (existing) => {
  if (!existing) {
    chrome.alarms.create(IDLE_KEEPALIVE_ALARM, { periodInMinutes: 20 / 60 }); // every 20s
    console.log('[Futnor Background] Idle keepalive alarm created');
  }
});

// Ensure the alarm is also (re)created on install, update, and browser startup.
// Chrome clears alarms when an extension is updated; onInstalled covers that case.
// onStartup covers a fresh browser launch where no SW startup code has run yet.
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(IDLE_KEEPALIVE_ALARM, { periodInMinutes: 20 / 60 });
  console.log('[Futnor Background] Keepalive alarm (re)created on install/update');
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(IDLE_KEEPALIVE_ALARM, { periodInMinutes: 20 / 60 });
  console.log('[Futnor Background] Keepalive alarm (re)created on browser startup');
});

// Long-lived port from content scripts — keeps the worker alive while a
// platform tab is open with the content script running.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'futnor-keepalive') {
    console.log('[Futnor Background] Keepalive port connected from', port.sender?.tab?.id);
    port.onDisconnect.addListener(() => {
      console.log('[Futnor Background] Keepalive port disconnected');
    });
    // Acknowledge — content script uses this to confirm the worker is alive
    port.onMessage.addListener((msg) => {
      if (msg.type === 'KEEPALIVE_PING') {
        port.postMessage({ type: 'KEEPALIVE_PONG' });
      }
    });
  }
});

// ─── Background-routed timers ─────────────────────────────────────────────
// Chrome throttles setTimeout to 1000ms minimum on hidden/minimized tabs in
// document context, which destroys human-simulation delays for bots running
// in background tabs. Service worker setTimeout is NOT subject to that
// throttling, so content scripts route all delays through here. The host
// page's CSP can also block worker-src blob: (e.g. on Instagram), making
// the older Worker-based unthrottling silently fail; the bg-routed path
// works regardless because it doesn't touch page CSP at all.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'TIMER_REQUEST' && typeof msg.ms === 'number') {
    setTimeout(() => {
      try { sendResponse({ done: true }); } catch {}
    }, Math.max(0, msg.ms));
    return true; // keep the response channel open for the async reply
  }

  // ─── Instagram DM delivery failure (rate limit / action block) ───────────
  // Sent by content.js when the just-sent DM is flagged as undelivered or
  // an "action blocked" / "try again later" modal appears. We treat both as
  // hard rate-limit signals: stop the session immediately, override any
  // active session goal, and surface a clear log/banner message.
  if (msg && msg.type === 'IG_DM_DELIVERY_FAILED') {
    handleDMDeliveryFailure(msg.reason || 'unknown', msg.phrase || '');
    try { sendResponse({ ok: true }); } catch {}
    return false;
  }
});

// ─── DM delivery failure handler ────────────────────────────────────────────
// Called when Instagram refuses to deliver a DM (red ✕ on the bubble) or
// shows a rate-limit / action-blocked modal. The bot must:
//   1. NOT count the failed DM (handled in content.js — executeValidatedDMFlow
//      returns false, so callers never increment dmsSent)
//   2. Stop the session immediately, even if a sessionDmGoal is active
//   3. Make the reason visible in logs and the live banner
let _futnorLastDeliveryFailureAt = 0;
function handleDMDeliveryFailure(reason, phrase) {
  const now = Date.now();
  // Debounce: a single block can fire from both bubble + modal almost
  // simultaneously. Only act on the first signal in any 5-second window.
  if (now - _futnorLastDeliveryFailureAt < 5000) {
    console.log('[Futnor Background] Duplicate delivery-failure signal ignored:', reason);
    return;
  }
  _futnorLastDeliveryFailureAt = now;

  const isModal = reason === 'action_blocked_modal';
  const headline = isModal
    ? '🛑 Instagram action-blocked this account'
    : '🛑 Instagram refused to deliver the DM (rate limit hit)';
  const detail = phrase ? ` — "${phrase}"` : '';

  console.warn('[Futnor Background]', headline, detail);

  try {
    if (typeof addLog === 'function') {
      addLog('session_end', `${headline}${detail} — stopping session immediately to protect the account.`);
    }
  } catch {}

  // Hard-stop the bot loop — every dispatch site checks shouldStop() /
  // sessionState.isRunning between actions, so this kills the session
  // regardless of any active sessionDmGoal.
  try {
    if (sessionState) {
      sessionState.isRunning = false;
      sessionState.isPaused = false;
    }
  } catch {}

  try {
    if (typeof updateBannerLive === 'function') {
      updateBannerLive(`${headline}${detail}`);
    }
  } catch {}
}

// ─── POST-DM AI COMMENTING (v2.4.50+) ───────────────────────────────────────
// After every successful DM, leave a personalized AI-generated comment on the
// target's most recent post. Soft-fails — never throws, never blocks the DM
// loop. The whole helper is wrapped in try/catch so any error (network, AI,
// missing post, rate limit) is logged and silently skipped.
async function postCommentAfterDM(targetUsername) {
  if (!targetUsername) return false;
  const username = String(targetUsername).replace(/^@/, '').trim().toLowerCase();
  if (!username) return false;

  try {
    if (!sessionState.isRunning || (typeof shouldStop === 'function' && shouldStop())) return false;

    // Step 1: navigate back to the target's profile (DM flow leaves us on /direct/).
    const navOk = await sendActionToTab('navigateProfile', null, [username]);
    if (!navOk) {
      console.log(`[Futnor Background] post-DM comment: nav to @${username} failed — skipping`);
      return false;
    }
    await new Promise((r) => setTimeout(r, 1200));

    // Step 2: ask content script for the recent post URL + caption + image.
    const ctxRes = await sendActionToTab('getRecentPostContext');
    const ctx = ctxRes && ctxRes.context;
    if (!ctx || !ctx.postUrl) {
      console.log(`[Futnor Background] post-DM comment: no recent post for @${username} — skipping`);
      return false;
    }

    // Step 3: call the AI edge function for ONE comment.
    const stored = await chrome.storage.local.get([
      'futnor_supabase_token', 'futnor_supabase_url', 'futnor_supabase_anon_key',
    ]);
    const { futnor_supabase_token: token, futnor_supabase_url: baseUrl, futnor_supabase_anon_key: anonKey } = stored;
    if (!token || !baseUrl) {
      console.log('[Futnor Background] post-DM comment: missing Supabase auth — skipping');
      return false;
    }
    const normalizedBaseUrl = baseUrl.replace(/\/+$/, '');

    let comment = '';
    try {
      const aiResp = await fetch(`${normalizedBaseUrl}/functions/v1/generate-post-comment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'apikey': anonKey || token,
        },
        body: JSON.stringify({
          caption: ctx.caption || '',
          imageUrl: ctx.imageUrl || '',
          username,
          isReel: !!ctx.isReel,
        }),
      });
      if (!aiResp.ok) {
        console.log(`[Futnor Background] post-DM comment: AI returned ${aiResp.status} — skipping`);
        return false;
      }
      const data = await aiResp.json().catch(() => ({}));
      comment = (data && data.comment) ? String(data.comment).trim() : '';
    } catch (e) {
      console.log('[Futnor Background] post-DM comment: AI call failed —', e?.message || e);
      return false;
    }
    if (!comment) return false;

    if (!sessionState.isRunning || (typeof shouldStop === 'function' && shouldStop())) return false;

    // Step 4: post the comment on the currently-open post page.
    await new Promise((r) => setTimeout(r, 800));
    const postRes = await sendActionToTab('postCommentOnCurrentPost', comment);
    if (postRes) {
      try { addLog('dm', `💬 Commented on @${username}'s recent post: "${comment}"`); } catch {}
      return true;
    }
    console.log(`[Futnor Background] post-DM comment: posting failed for @${username}`);
    return false;
  } catch (e) {
    console.warn('[Futnor Background] postCommentAfterDM unexpected error:', e?.message || e);
    return false;
  }
}


// ─── Auto-resume warmup after service worker restart ───
(async () => {
  try {
    const data = await chrome.storage.session.get('_warmupPersist');
    const wp = data && data._warmupPersist;
    if (wp && wp.isRunning && wp.startTime && wp.sessionMinutes) {
      const elapsedMs = Date.now() - wp.startTime;
      const totalMs = wp.sessionMinutes * 60 * 1000;
      const remainingMs = totalMs - elapsedMs;
      if (remainingMs > 30000) {
        const remainingMin = Math.ceil(remainingMs / 60000);
        console.log(`[Futnor] Auto-resuming warmup: ${remainingMin} min remaining`);
        runWarmup(wp.sessionMinutes, wp.platform || 'instagram', wp.enableComments || false, wp.startTime);
      } else {
        await chrome.storage.session.remove('_warmupPersist');
      }
    }
  } catch (e) {
    console.log('[Futnor] No warmup to resume:', e.message);
  }
})();

function getSessionStartFingerprint(msg = {}) {
  const platform = msg.platform || sessionState.platform || 'instagram';
  const timestamp = Number(msg.timestamp) || 0;
  return `${msg.type || 'START_SESSION'}:${platform}:${timestamp}`;
}

// ─── Persistent account history (background-side mirrors) ───
// Keys are scoped by active Instagram account to prevent cross-account contamination
const DM_HISTORY_KEY_BASE = 'dm_history';
const PROCESSED_ACCOUNTS_KEY_BASE = 'processed_accounts_history';
let bgDMHistoryCache = new Set();
let bgProcessedAccountsCache = new Set();

function getDMHistoryKey() {
  return activeAccountUsername ? `${DM_HISTORY_KEY_BASE}_${activeAccountUsername}` : DM_HISTORY_KEY_BASE;
}

function getProcessedAccountsKey() {
  return activeAccountUsername ? `${PROCESSED_ACCOUNTS_KEY_BASE}_${activeAccountUsername}` : PROCESSED_ACCOUNTS_KEY_BASE;
}

function normalizeHistoryEntry(value) {
  const raw = (value || '').toString().toLowerCase().trim();
  if (!raw) return null;
  if (raw.startsWith('thread_')) return raw;
  return raw.replace(/^@/, '');
}

function normalizeAccountUsername(value) {
  const normalized = normalizeHistoryEntry(value);
  if (!normalized || normalized.startsWith('thread_')) return null;
  return normalized;
}

async function refreshBgDMHistory() {
  try {
    const key = getDMHistoryKey();
    const data = await new Promise(resolve => {
      chrome.storage.local.get({ [key]: [] }, resolve);
    });
    const raw = data[key];
    bgDMHistoryCache = new Set(
      Array.isArray(raw)
        ? raw.map(normalizeHistoryEntry).filter(Boolean)
        : []
    );
    console.log(`[Futnor Background] DM history loaded (${key}): ${bgDMHistoryCache.size} entries`);
  } catch {
    bgDMHistoryCache = new Set();
  }
}

async function refreshBgProcessedAccounts() {
  try {
    const key = getProcessedAccountsKey();
    const data = await new Promise(resolve => {
      chrome.storage.local.get({ [key]: [] }, resolve);
    });
    const raw = data[key];
    bgProcessedAccountsCache = new Set(
      Array.isArray(raw)
        ? raw.map(normalizeAccountUsername).filter(Boolean)
        : []
    );
    console.log(`[Futnor Background] Processed accounts loaded (${key}): ${bgProcessedAccountsCache.size} entries`);
  } catch {
    bgProcessedAccountsCache = new Set();
  }
}

function isInBgDMHistory(username) {
  const normalized = normalizeAccountUsername(username);
  return !!normalized && bgDMHistoryCache.has(normalized);
}

function isInBgProcessedAccounts(username) {
  const normalized = normalizeAccountUsername(username);
  return !!normalized && bgProcessedAccountsCache.has(normalized);
}

async function addToBgDMHistory(username) {
  const normalized = normalizeAccountUsername(username);
  if (!normalized || bgDMHistoryCache.has(normalized)) return;

  bgDMHistoryCache.add(normalized);
  try {
    const key = getDMHistoryKey();
    await chrome.storage.local.set({ [key]: Array.from(bgDMHistoryCache) });
  } catch (error) {
    console.warn('[Futnor Background] Failed to persist DM history entry:', error?.message || error);
  }

  // Track DM in Supabase for response rate analytics
  trackDMSentToSupabase(normalized);
}

// Fetch the authoritative subscription tier for the currently-authenticated
// user directly from Supabase, bypassing the dashboard localStorage bridge.
// Motivation: users who start a Scale / Growth / Pro plan free trial and
// then open the extension without ever revisiting the dashboard tab used to
// see "Free Plan" in the popup, because syncTier() only fires when the
// dashboard content script runs.  Querying the `subscribers` table directly
// with the user's access token (Lovable template schema) closes that gap.
// Returns the raw tier string (pre-normalization) or null on any failure —
// the caller decides what to do when we don't know.
async function fetchSubscriberTierFromSupabase() {
  try {
    const stored = await chrome.storage.local.get([
      'futnor_supabase_token',
      'futnor_supabase_url',
      'futnor_supabase_anon_key',
      'futnor_user_id',
    ]);
    const {
      futnor_supabase_token: token,
      futnor_supabase_url: baseUrl,
      futnor_supabase_anon_key: anonKey,
      futnor_user_id: userId,
    } = stored;
    if (!token || !baseUrl || !userId) return null;

    const normalizedBaseUrl = baseUrl.replace(/\/+$/, '');
    const headers = {
      'Authorization': `Bearer ${token}`,
      'apikey': anonKey || token,
      'Accept': 'application/json',
    };

    // Primary path: the Lovable-standard `subscribers` table (one row per
    // user_id, carries `subscribed`, `subscription_tier`, `subscription_end`).
    // RLS is expected to let the user read their own row via the access token.
    try {
      const url = `${normalizedBaseUrl}/rest/v1/subscribers`
        + `?user_id=eq.${encodeURIComponent(userId)}`
        + `&select=subscription_tier,subscribed,subscription_end,trial_end,is_trial`;
      const res = await fetch(url, { headers });
      if (res.ok) {
        const rows = await res.json().catch(() => []);
        const row = Array.isArray(rows) ? rows[0] : null;
        if (row) {
          const nowMs = Date.now();
          const trialEndMs = row.trial_end ? Date.parse(row.trial_end) : NaN;
          const onTrial = row.is_trial === true
            || (Number.isFinite(trialEndMs) && trialEndMs > nowMs);
          const rawTier = (row.subscription_tier || '').toString().trim();
          if (rawTier) {
            // Trials: annotate the tier so the popup can show "Scale — Free
            // Trial" instead of just "Scale", matching the trial badge path.
            return onTrial ? `${rawTier}_trial` : rawTier;
          }
          if (row.subscribed === true) return 'subscribed';
          if (row.subscribed === false) return 'free';
        }
      }
    } catch (e) {
      console.warn('[Futnor Background] subscribers table query failed:', e?.message || e);
    }

    // Fallback: Lovable's `check-subscription` edge function (if deployed).
    // It reads Stripe and updates the subscribers table, returning the same
    // fields.  Non-fatal if the function is missing (404) — just means this
    // project didn't ship the template function.
    try {
      const res = await fetch(`${normalizedBaseUrl}/functions/v1/check-subscription`, {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        const rawTier = (data?.subscription_tier || '').toString().trim();
        const onTrial = data?.is_trial === true;
        if (rawTier) return onTrial ? `${rawTier}_trial` : rawTier;
        if (data?.subscribed === true) return 'subscribed';
      }
    } catch (e) {
      console.warn('[Futnor Background] check-subscription edge function failed:', e?.message || e);
    }

    return null;
  } catch (e) {
    console.warn('[Futnor Background] fetchSubscriberTierFromSupabase error:', e?.message || e);
    return null;
  }
}

// Refresh `subscriptionTier` in storage from Supabase.  Safe to call whenever
// — it never writes `free` over an existing paid tier unless Supabase is the
// source of truth saying the user lapsed.  Returns the normalized tier or
// null on failure.
async function refreshSubscriptionFromSupabase({ force = false } = {}) {
  const raw = await fetchSubscriberTierFromSupabase();
  if (!raw) return null;
  const normalized = normalizeTier(raw);
  try {
    const stored = await chrome.storage.local.get(['subscriptionTier']);
    const current = normalizeTier(stored.subscriptionTier);
    // Never downgrade a paid tier to free unless we're explicitly forced,
    // to avoid a transient Supabase blip knocking a subscribed user out.
    if (!force && normalized === 'free' && current !== 'free' && current !== 'subscribed') {
      return current;
    }
    if (normalized !== current) {
      await chrome.storage.local.set({ subscriptionTier: normalized });
      sessionState.tier = normalized;
      console.log(`[Futnor Background] Tier refreshed from Supabase: ${current} → ${normalized}`);
    }
  } catch (e) {
    console.warn('[Futnor Background] refreshSubscriptionFromSupabase set failed:', e?.message || e);
  }
  return normalized;
}

async function trackDMSentToSupabase(recipientUsername) {
  try {
    const stored = await chrome.storage.local.get(['futnor_supabase_token', 'futnor_supabase_url', 'futnor_supabase_anon_key', 'futnor_user_id']);
    const { futnor_supabase_token: token, futnor_supabase_url: baseUrl, futnor_supabase_anon_key: anonKey, futnor_user_id: userId } = stored;
    if (!token || !baseUrl || !userId) return;

    const platform = sessionState.platform || 'instagram';
    const body = {
      user_id: userId,
      recipient_username: recipientUsername,
      platform,
      instagram_account_username: activeAccountUsername || null,
    };

    await fetch(`${baseUrl}/rest/v1/dm_tracking`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'apikey': anonKey || token,
        'Prefer': 'return=minimal',
      },
      body: JSON.stringify(body),
    });
    console.log(`[Futnor Background] DM tracked to Supabase: @${recipientUsername}`);
  } catch (err) {
    console.warn('[Futnor Background] DM tracking failed (non-fatal):', err?.message || err);
  }
}

async function trackDMResponsesToSupabase(recipientUsernames, platform) {
  try {
    const stored = await chrome.storage.local.get(['futnor_supabase_token', 'futnor_supabase_url', 'futnor_supabase_anon_key']);
    const { futnor_supabase_token: token, futnor_supabase_url: baseUrl, futnor_supabase_anon_key: anonKey } = stored;
    if (!token || !baseUrl || recipientUsernames.length === 0) return;

    const normalizedBaseUrl = baseUrl.replace(/\/+$/, '');
    await fetch(`${normalizedBaseUrl}/functions/v1/dm-response-tracking`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'apikey': anonKey || token,
      },
      body: JSON.stringify({
        action: 'check-responses',
        recipients: recipientUsernames.map((u) => u.toLowerCase()),
        platform: platform || 'instagram',
      }),
    });
    console.log(`[Futnor Background] Response tracking: checked ${recipientUsernames.length} usernames`);
  } catch (err) {
    console.warn('[Futnor Background] Response tracking failed (non-fatal):', err?.message || err);
  }
}

async function addToBgProcessedAccounts(username) {
  const normalized = normalizeAccountUsername(username);
  if (!normalized || bgProcessedAccountsCache.has(normalized)) return;

  bgProcessedAccountsCache.add(normalized);
  try {
    const key = getProcessedAccountsKey();
    await chrome.storage.local.set({ [key]: Array.from(bgProcessedAccountsCache) });
  } catch (error) {
    console.warn('[Futnor Background] Failed to persist processed account entry:', error?.message || error);
  }
}

// ─── Persistence helpers ───
const SESSION_STATE_KEY_BASE = 'futnor_session';

function getSessionStateKey(accountOverride = activeAccountUsername) {
  const normalized = normalizeAccountUsername(accountOverride);
  return normalized ? `${SESSION_STATE_KEY_BASE}_${normalized}` : SESSION_STATE_KEY_BASE;
}

function resetSessionState(tierOverride = sessionState.tier || DEFAULT_STATE.tier) {
  sessionState = {
    ...DEFAULT_STATE,
    tier: tierOverride,
    config: { ...DEFAULT_STATE.config },
    targeting: { ...DEFAULT_STATE.targeting },
    aiTargeting: { ...DEFAULT_STATE.aiTargeting },
    dmTemplates: [],
    stats: { ...DEFAULT_STATE.stats },
    logs: [],
  };
}

function sanitizeDMTemplates(rawTemplates) {
  const templates = Array.isArray(rawTemplates)
    ? rawTemplates
    : (typeof rawTemplates === 'string' ? [rawTemplates] : []);

  return templates
    .map((template) => (typeof template === 'string' ? template.replace(/\r\n?/g, '\n') : ''))
    .filter((template) => template.trim().length > 0);
}

function saveState(accountOverride = activeAccountUsername) {
  const key = getSessionStateKey(accountOverride);
  chrome.storage.local.set({
    [key]: {
      accountUsername: normalizeAccountUsername(accountOverride),
      platform: sessionState.platform,
      tier: sessionState.tier,
      config: sessionState.config,
      targeting: sessionState.targeting,
      aiTargeting: sessionState.aiTargeting,
      dmTemplates: sessionState.dmTemplates || [],
      stats: sessionState.stats,
      logs: sessionState.logs.slice(0, 50),
      isRunning: sessionState.isRunning,
      isPaused: sessionState.isPaused,
      reconnecting: sessionState.reconnecting,
      savedAt: Date.now(),
    }
  });
}

async function loadState(accountOverride = activeAccountUsername) {
  const key = getSessionStateKey(accountOverride);
  return new Promise((resolve) => {
    chrome.storage.local.get({ [key]: null, subscriptionTier: null }, (result) => {
      const storedState = result[key];
      const resolvedTier = result.subscriptionTier || storedState?.tier || sessionState.tier || DEFAULT_STATE.tier;

      resetSessionState(resolvedTier);

      if (storedState) {
        sessionState.platform = storedState.platform || 'instagram';
        sessionState.config = sanitizeSessionConfig(storedState.config);
        sessionState.targeting = { ...DEFAULT_STATE.targeting, ...storedState.targeting };
        sessionState.aiTargeting = { ...DEFAULT_STATE.aiTargeting, ...storedState.aiTargeting };
        sessionState.dmTemplates = Array.isArray(storedState.dmTemplates) ? storedState.dmTemplates : [];
        sessionState.stats = { ...DEFAULT_STATE.stats, ...storedState.stats };
        sessionState.logs = Array.isArray(storedState.logs) ? storedState.logs : [];
        const restorePausedSession = Boolean(storedState.isRunning && storedState.isPaused);
        sessionState.isRunning = restorePausedSession;
        sessionState.isPaused = restorePausedSession;
        sessionState.reconnecting = false;
        sessionState.tier = storedState.tier || resolvedTier;
      }

      if (result.subscriptionTier) {
        sessionState.tier = result.subscriptionTier;
      }

      resolve();
    });
  });
}

// Listen for CONTENT_SCRIPT_READY signals from content scripts
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'CONTENT_SCRIPT_READY' && msg.platform) {
    console.log(`[Futnor Background] Content script ready signal from ${msg.platform} tab`);
    // If a session is running but reconnecting, attempt recovery
    if (sessionState.isRunning && sessionState.reconnecting) {
      console.log('[Futnor Background] Session reconnecting — attempting auto-recovery via CONTENT_SCRIPT_READY');
      handleExtensionReconnect('content_script_ready_signal');
    }
  }
});

// Load saved state and warm caches on startup
(async () => {
  const data = await new Promise((resolve) => {
    chrome.storage.local.get({ futnor_active_account: null }, resolve);
  });

  activeAccountUsername = normalizeAccountUsername(data?.futnor_active_account) || null;
  if (activeAccountUsername) {
    console.log('[Futnor Background] Active account restored:', activeAccountUsername);
  }

  await loadState(activeAccountUsername);
  await refreshBgDMHistory();
  await refreshBgProcessedAccounts();

  // Proactive first-detection for any IG tab already open when the SW wakes.
  // Scripting-fallback in the helper handles the case where the extension was just installed
  // after the IG tab had already loaded (content script not injected yet).
  detectAndSyncActiveAccount('instagram').catch(() => {});
  // Keep retrying for ~2 min so a slow IG hydrate eventually resolves.
  startActiveAccountDetectionPoll();

  // Refresh subscription tier from Supabase whenever the SW wakes — covers the
  // case where the user started a Scale/Growth trial on the dashboard but
  // hasn't reopened that tab, so the dashboard bridge never fired syncTier().
  // Without this, the popup keeps showing "Free Plan" indefinitely.
  refreshSubscriptionFromSupabase().catch(() => {});
})();

// ─── Sync from dashboard website ───
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;

  if (changes.subscriptionTier) {
    // Normalize on ingress so the session block, popup badge, and stored
    // state never disagree about a scale/growth trial vs. literal 'free'.
    sessionState.tier = normalizeTier(changes.subscriptionTier.newValue);
    saveState();
  }

  // When the auth token or user_id first arrives (right after the user signs
  // in on the dashboard), refresh the tier from Supabase.  This is what
  // catches a trial user who subscribed on the dashboard, closed that tab,
  // and opened the extension — without this, the popup has nothing to show.
  if (changes.futnor_supabase_token?.newValue || changes.futnor_user_id?.newValue) {
    refreshSubscriptionFromSupabase().catch(() => {});
  }

  // Update active account if changed and reload caches + session state.
  //
  // NOTE (v2.4.48): a revert guard added in v2.4.47 (refuse any non-null →
  // different-non-null transition) was removed. It permanently trapped users
  // whose storage held a stale/bad value — the background would keep
  // reverting every subsequent correct detection. Legitimate account
  // switches (user logs into a different IG account in Chrome) were blocked
  // the same way. The content-script guards (URL-match + unsafe-surface)
  // plus the `once-set, never overwrite via auto-detect` rule inside
  // `detectAndSyncActiveAccount` are enough to stop bad writes without
  // losing the ability to recover.
  if (changes.futnor_active_account) {
    const newAccount = normalizeAccountUsername(changes.futnor_active_account.newValue) || null;
    if (newAccount !== activeAccountUsername) {
      console.log(`[Futnor Background] Active account changed via storage: ${activeAccountUsername} → ${newAccount}`);
      activeAccountUsername = newAccount;
      (async () => {
        await Promise.all([
          loadState(newAccount),
          refreshBgDMHistory(),
          refreshBgProcessedAccounts(),
        ]);
        saveState(newAccount);
      })();
    }
  }

  // Listen for changes to the current account's history keys
  const dmKey = getDMHistoryKey();
  const paKey = getProcessedAccountsKey();

  if (changes[dmKey]) {
    const incoming = changes[dmKey].newValue;
    bgDMHistoryCache = new Set(
      Array.isArray(incoming)
        ? incoming.map(normalizeHistoryEntry).filter(Boolean)
        : []
    );
  }

  if (changes[paKey]) {
    const incoming = changes[paKey].newValue;
    bgProcessedAccountsCache = new Set(
      Array.isArray(incoming)
        ? incoming.map(normalizeAccountUsername).filter(Boolean)
        : []
    );
  }

  // Sync config from website when not running
  if (changes.futnor_sync && !sessionState.isRunning) {
    const data = changes.futnor_sync.newValue;
    if (data?.config) {
      const wc = data.config;
      sessionState.config = sanitizeSessionConfig({
        ...sessionState.config,
        sessionMin: wc.sessionMin ?? sessionState.config.sessionMin,
        sessionMax: wc.sessionMax ?? sessionState.config.sessionMax,
        scrollWeight: wc.scrollWeight ?? sessionState.config.scrollWeight,
        likeWeight: wc.likeWeight ?? sessionState.config.likeWeight,
        dmWeight: wc.dmWeight ?? sessionState.config.dmWeight,
        minActionDelay: wc.minActionDelay ?? sessionState.config.minActionDelay,
        maxActionDelay: wc.maxActionDelay ?? sessionState.config.maxActionDelay,
        dailyMaxDMs: wc.dailyMaxDMs ?? sessionState.config.dailyMaxDMs,
        dailyMaxLikes: wc.dailyMaxLikes ?? sessionState.config.dailyMaxLikes,
        dailyMaxFollows: wc.dailyMaxFollows ?? sessionState.config.dailyMaxFollows,
        followEnabled: wc.followEnabled !== undefined ? !!wc.followEnabled : sessionState.config.followEnabled,
        dmMode: wc.dmMode ?? sessionState.config.dmMode ?? 'human',
      });
      sessionState.platform = wc.platform || sessionState.platform;
      const syncedTemplates = sanitizeDMTemplates(wc.dmTemplates);
      if (syncedTemplates.length > 0) {
        sessionState.dmTemplates = syncedTemplates;
        console.log('[Futnor Background] Synced DM templates from dashboard:', syncedTemplates.length);
      }
      if (wc.aiTargeting) {
        sessionState.aiTargeting = { ...DEFAULT_STATE.aiTargeting, ...wc.aiTargeting };
      }
      if (wc.targeting) {
        sessionState.targeting = { ...DEFAULT_STATE.targeting, ...wc.targeting };
      }
    }
    if (data?.stats) {
      sessionState.stats = { ...sessionState.stats, ...data.stats };
    }
    saveState();
  }
});

// ─── Engine ───
const PLATFORM_URLS = {
  instagram: 'https://www.instagram.com/*',
  tiktok: 'https://www.tiktok.com/*',
  whatsapp: 'https://web.whatsapp.com/*',
};

const PLATFORM_HOME_URLS = {
  instagram: 'https://www.instagram.com',
  tiktok: 'https://www.tiktok.com',
  whatsapp: 'https://web.whatsapp.com/',
};

const PLATFORM_DOMAIN_MATCHERS = {
  instagram: 'instagram.com',
  tiktok: 'tiktok.com',
  whatsapp: 'web.whatsapp.com',
};

const RESERVED_IG_PATH_SEGMENTS = new Set([
  'accounts', 'about', 'explore', 'direct', 'reels', 'stories', 'p', 'reel', 'tv', 'tags', 'locations'
]);

let preferredInstagramTabId = null;

// ─── Active-account detection ───
// Store the detected logged-in username for a platform tab. Runs proactively on tab load
// and at extension startup so the dashboard sees the active account before any session starts.

// Inline detection probe — executed in the IG page context via
// chrome.scripting.executeScript when the content script isn't loaded yet
// (extension just installed, old discarded tab, etc). Mirrors the shared
// detection in instagram/content.js so both paths accept the same signals.
function detectIgUsernameInPage() {
  try {
    const RESERVED = new Set([
      'explore','reels','direct','accounts','p','stories','tv','about','shop',
      'developer','legal','privacy','emails','tags','locations','web','s','oauth',
      'api','graphql','channel','challenge','nometa','ads','business','creators',
      'press','jobs','help','invites','nametag','accounts_center',
    ]);
    const ok = (u) => !!u && !u.includes('/') && !RESERVED.has(u) && /^[a-z0-9._]{2,30}$/.test(u);
    const h2u = (el) => {
      const href = el?.getAttribute('href') || '';
      const cleaned = href.replace(/^\/+|\/+$/g, '').toLowerCase();
      if (!cleaned || cleaned.includes('/')) return null;
      return cleaned;
    };

    // Same-origin reject rule: a detected username that equals the first URL
    // path segment is almost certainly the profile we're *viewing* — which
    // happens constantly during commenters targeting, when the bot navigates
    // to each commenter's profile to DM them. Only accept such a match on
    // the logged-in user's own profile (verified by the "Edit profile"
    // affordance).  See content.js:detectedMatchesViewedProfile for detail.
    // HARDENED (v2.4.47): require (a) a strict /<handle>/ URL, and (b) an
    // anchor pointing at /accounts/edit/ OR an element inside <main> whose
    // *exact* trimmed textContent matches a locale "Edit profile" label.
    // The old regex-on-textContent was false-positive on commenter profiles
    // whose bios/highlights contained matching words and let Method 4
    // return the visited handle as the logged-in username.
    const OWN_PROFILE_LABELS = new Set([
      'edit profile','editar perfil','profil bearbeiten','profil anpassen',
      'modifier le profil','modifica profilo','profiel bewerken',
      'editar o perfil','perfil editar',
    ]);
    const isOwnProfile = () => {
      try {
        const path = (location && location.pathname) || '';
        if (!/^\/[a-z0-9._]{1,30}\/?$/i.test(path)) return false;
        const handle = path.split('/').filter(Boolean)[0]?.toLowerCase() || '';
        if (!handle || RESERVED.has(handle)) return false;
        if (document.querySelector('a[href="/accounts/edit/"]')) return true;
        if (document.querySelector('a[href^="/accounts/edit/"]')) return true;
        const main = document.querySelector('main, [role="main"]');
        if (!main) return false;
        const els = main.querySelectorAll('a, button, div[role="button"]');
        for (const el of els) {
          const txt = (el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
          if (txt && OWN_PROFILE_LABELS.has(txt)) return true;
        }
      } catch {}
      return false;
    };
    const isUnsafeSurface = () => {
      try {
        const path = (location && location.pathname) || '';
        if (/^\/(p|reel|reels|tv|explore|stories|direct)\b/.test(path)) return true;
        const parts = path.split('/').filter(Boolean);
        if (parts.length >= 1 && !RESERVED.has(parts[0]) && !isOwnProfile()) return true;
        const ownProfileLink = document.querySelector('nav a[href^="/"], [role="navigation"] a[href^="/"]');
        if (!ownProfileLink && !isOwnProfile()) return true;
        return false;
      } catch {
        return false;
      }
    };
    // NOTE (v2.4.48): removed early `if (isUnsafeSurface()) return null;`.
    // Nav-scoped methods below (aria-Profile link, avatar-in-nav, nav/[role=navigation] links)
    // always surface the logged-in user even while `main` is showing a
    // commenter's profile or a post. The `accept()` wrapper + `isOwnProfile()`
    // gate on Method 4 are enough to stop viewed-profile leaks. Short-
    // circuiting on `isUnsafeSurface()` was blocking correct detections and,
    // on non-English IG locales where `isOwnProfile()` can't prove own-profile,
    // even killed detection on the user's own profile page.
    const urlSeg = (() => {
      try {
        const parts = location.pathname.split('/').filter(Boolean);
        return (parts[0] || '').toLowerCase();
      } catch { return ''; }
    })();
    const notViewedProfile = (u) => {
      if (!u) return false;
      if (urlSeg && urlSeg === u && !RESERVED.has(urlSeg) && !isOwnProfile()) return false;
      return true;
    };
    const accept = (u) => (ok(u) && notViewedProfile(u)) ? u : null;

    // aria-labeled sidebar Profile entry (many locales).
    const aria = document.querySelector(
      'a[aria-label^="Profile" i][href^="/"], a[aria-label^="Profil" i][href^="/"], ' +
      'a[aria-label^="Perfil" i][href^="/"], a[aria-label^="Profiel" i][href^="/"], ' +
      'a[aria-label^="Profilo" i][href^="/"]'
    );
    if (aria) { const u = accept(h2u(aria)); if (u) return u; }

    // Avatar image inside the nav → enclosing anchor is always the logged-in user.
    const avatarImgs = document.querySelectorAll(
      'img[alt*="profile picture" i], img[alt*="profile photo" i], ' +
      'img[alt*="perfil" i], img[alt*="Profilbild" i], img[alt*="profile" i]'
    );
    for (const img of avatarImgs) {
      const a = img.closest('a[href^="/"]');
      if (!a) continue;
      if (!a.closest('nav, [role="navigation"]')) continue;
      const u = accept(h2u(a));
      if (u) return u;
    }

    // Nav-scoped links in general — IG only puts the logged-in user's profile
    // link inside nav / navigation landmarks.
    // Do NOT include `header a[...]`: /p/ and /reel/ pages put the post
    // AUTHOR's profile link inside <article><header>, which would clobber the
    // real logged-in user with the commenter-target account.
    const navLinks = document.querySelectorAll(
      'nav a[href^="/"], [role="navigation"] a[href^="/"]'
    );
    for (const l of navLinks) { const u = accept(h2u(l)); if (u && l.querySelector('img')) return u; }
    for (const l of navLinks) { const u = accept(h2u(l)); if (u) return u; }

    // On own profile — URL segment IS the logged-in user.
    if (isOwnProfile()) {
      const seg = location.pathname.split('/').filter(Boolean);
      if (seg.length === 1 && ok(seg[0].toLowerCase())) return seg[0].toLowerCase();
    }

    // Avatar alt "username's profile picture" fallback — DISABLED.
    // This used to iterate every profile-picture <img> on the page and return
    // the first matching alt. On a /p/ or /reel/ page (e.g. the post URL a
    // user pastes for commenters targeting) that regex matched the POST
    // AUTHOR's avatar before IG's left nav hydrated, and we'd persist the
    // post owner as `futnor_active_account` — making health stats and DM
    // scripts key off the wrong account. The nav-scoped signals above are
    // reliable on every IG surface; we no longer need this fallback.

    // Legacy meta tag fallback.
    const meta = document.querySelector('meta[property="al:ios:url"]');
    if (meta) {
      const m = (meta.getAttribute('content') || '').match(/user\?username=([a-z0-9._]+)/i);
      if (m) { const u = accept(m[1].toLowerCase()); if (u) return u; }
    }

    return null;
  } catch { return null; }
}

async function attemptDetectionOnce(tabId) {
  try {
    const resp = await chrome.tabs.sendMessage(tabId, { type: 'GET_LOGGED_IN_USERNAME' });
    if (resp?.success && resp.username) return resp.username;
  } catch {
    // Content script not injected — fall through to scripting injection.
  }
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: detectIgUsernameInPage,
    });
    const result = results?.[0]?.result;
    if (result) return result;
  } catch {}
  return null;
}

async function detectAndSyncActiveAccount(platform = 'instagram') {
  // Only Instagram currently exposes a "logged-in username" handler in its content script.
  if (platform !== 'instagram') return null;

  const urlPattern = PLATFORM_URLS[platform];
  const tabs = await chrome.tabs.query({ url: urlPattern });
  if (tabs.length === 0) return null;

  // Try every IG tab the user has open (handles "logged in on a different IG tab"),
  // and retry each tab a few times with backoff so a slow nav hydrate doesn't lose us.
  // Prefer ready tabs first so we don't waste retries on tabs still loading.
  const candidates = [
    ...tabs.filter(t => t.status === 'complete'),
    ...tabs.filter(t => t.status !== 'complete'),
  ].filter(t => t.id);

  const backoffsMs = [0, 1500, 4000];
  let detected = null;

  for (const tab of candidates) {
    for (const delay of backoffsMs) {
      if (delay > 0) await waitMs(delay);
      detected = await attemptDetectionOnce(tab.id);
      if (detected) break;
    }
    if (detected) break;
  }

  if (!detected) return null;

  const detectedUsername = detected.toLowerCase().trim();
  if (detectedUsername !== activeAccountUsername) {
    // Hard guard: once a connected account is set, NEVER let auto-detect
    // replace it. The extension navigates IG tabs to post/reel URLs and
    // commenter profiles during commenters targeting; on those pages a
    // racy detection (or a DOM that hasn't fully repainted after a SPA
    // navigation away) can yield the visited profile's username instead
    // of the actual logged-in user. Allowing that overwrite — even
    // between sessions — makes the dashboard show the wrong account in
    // Account Health and stops/restarts sessions on the wrong handle.
    //
    // To force a re-detection (e.g. user switched IG accounts in Chrome),
    // the dashboard must explicitly send RESET_ACTIVE_ACCOUNT, which
    // clears `activeAccountUsername` first.
    if (activeAccountUsername) {
      console.log(
        `[Futnor Background] Ignoring auto-detected account change: ` +
        `keep=${activeAccountUsername}, detected=${detectedUsername}`
      );
      return activeAccountUsername;
    }
    console.log(`[Futnor Background] Active account detected: (none) → ${detectedUsername}`);
    activeAccountUsername = detectedUsername;
    await chrome.storage.local.set({ futnor_active_account: detectedUsername });
  }
  return detectedUsername;
}

// Safety-net poll: if no account is detected yet, keep trying every 10s for the first
// ~2 minutes after the SW wakes. Covers the edge case where IG's nav hydrates AFTER
// our onUpdated 'complete' fires (common on slow networks / cold logins).
let _detectionPollAttempts = 0;
function startActiveAccountDetectionPoll() {
  const interval = setInterval(async () => {
    _detectionPollAttempts++;
    if (activeAccountUsername || _detectionPollAttempts > 12) {
      clearInterval(interval);
      return;
    }
    try { await detectAndSyncActiveAccount('instagram'); } catch {}
  }, 10000);
}

// Run detection when any Instagram tab finishes loading so the dashboard learns about the
// logged-in user the moment the user opens or navigates IG — no session start required.
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  const url = tab?.url || '';
  if (!/^https:\/\/www\.instagram\.com\//.test(url)) return;
  // Give the content script a moment to hydrate the DOM, then detect.
  setTimeout(() => {
    detectAndSyncActiveAccount('instagram').catch(() => {});
  }, 1500);
});

// ─── Centralized tab management ───
// Returns the single platform tab to use. Reuses existing, cleans duplicates, creates if needed.
async function getOrCreatePlatformTab(platform, options = {}) {
  const { createIfMissing = true, focus = false } = options;
  const urlPattern = PLATFORM_URLS[platform];
  const platformUrl = PLATFORM_HOME_URLS[platform] || PLATFORM_HOME_URLS.instagram;

  let tabs = await chrome.tabs.query({ url: urlPattern });

  // Validate preferred tab still exists
  if (preferredInstagramTabId && platform === 'instagram') {
    const preferred = tabs.find(t => t.id === preferredInstagramTabId);
    if (!preferred) {
      console.log('[Futnor Tab] Preferred tab no longer exists, clearing');
      preferredInstagramTabId = null;
    }
  }

  let targetTab = null;

  if (tabs.length === 0) {
    if (!createIfMissing) return null;
    console.log('[Futnor Tab] No platform tab found, creating one...');
    try {
      targetTab = await chrome.tabs.create({ url: platformUrl, active: true });
      await waitMs(3000);
      // Re-query to get updated tab info
      const refreshed = await chrome.tabs.query({ url: urlPattern });
      targetTab = refreshed.find(t => t.id === targetTab.id) || refreshed[0] || targetTab;
    } catch (e) {
      console.error('[Futnor Tab] Could not create tab:', e.message);
      return null;
    }
  } else if (tabs.length === 1) {
    targetTab = tabs[0];
  } else {
    // Multiple tabs — pick the best one, ignore the rest
    // Priority: preferred > active > most recently accessed
    if (platform === 'instagram' && preferredInstagramTabId) {
      targetTab = tabs.find(t => t.id === preferredInstagramTabId);
    }
    if (!targetTab) {
      const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activePlatform = activeTabs.find(t => (t.url || '').includes(PLATFORM_DOMAIN_MATCHERS[platform] || PLATFORM_DOMAIN_MATCHERS.instagram));
      if (activePlatform) {
        targetTab = tabs.find(t => t.id === activePlatform.id);
      }
    }
    if (!targetTab) {
      // Pick most recently accessed
      targetTab = tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
    }
    console.log(`[Futnor Tab] Multiple tabs found (${tabs.length}), using tab ${targetTab.id}. Ignoring others.`);
  }

  // Store preferred tab
  if (platform === 'instagram' && targetTab?.id) {
    preferredInstagramTabId = targetTab.id;
  }

  // Focus if requested
  if (focus && targetTab?.id) {
    try {
      await chrome.tabs.update(targetTab.id, { active: true });
      await chrome.windows.update(targetTab.windowId, { focused: true });
    } catch {}
  }

  return targetTab || null;
}

// Ensure content script is loaded on a specific tab
async function ensureContentScript(tabId, platform) {
  // Retry PING a few times — content script may be initializing (document_idle can lag)
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const ping = await chrome.tabs.sendMessage(tabId, { type: 'PING' });
      if (ping?.ready) return true;
    } catch {}
    if (attempt < 2) await waitMs(600);
  }

  // Not ready — inject the script manually
  try {
    const scriptFile = platform === 'tiktok'
      ? 'tiktok/content.js'
      : platform === 'whatsapp'
        ? 'whatsapp/content.js'
        : 'instagram/content.js';
    await chrome.scripting.executeScript({ target: { tabId }, files: [scriptFile] });
    await waitMs(2000); // Extra time to let the script fully initialize
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const ping = await chrome.tabs.sendMessage(tabId, { type: 'PING' });
        if (ping?.ready) return true;
      } catch {}
      if (attempt < 2) await waitMs(600);
    }
    return false;
  } catch (e) {
    console.error('[Futnor Tab] ensureContentScript failed:', e.message);
    return false;
  }
}

// Re-validate the preferred tab; if gone, re-scan
async function revalidatePlatformTab(platform) {
  if (preferredInstagramTabId && platform === 'instagram') {
    try {
      await chrome.tabs.get(preferredInstagramTabId);
      return; // Still valid
    } catch {
      console.log('[Futnor Tab] Preferred tab invalid, re-scanning...');
      preferredInstagramTabId = null;
    }
  }
  // Re-scan to find a valid tab
  const tab = await getOrCreatePlatformTab(platform, { createIfMissing: false });
  if (tab) {
    console.log('[Futnor Tab] Reassigned to tab', tab.id);
  }
}

function normalizeInstagramUsername(username) {
  const normalized = (username || '').toString().toLowerCase().replace(/^@/, '').trim();
  return normalized || null;
}

function parseInstagramProfileUsernameFromUrl(rawUrl) {
  if (!rawUrl) return null;

  try {
    const url = new URL(rawUrl);
    const path = url.pathname.replace(/^\/+|\/+$/g, '').toLowerCase();
    if (!path || path.includes('/')) return null;
    if (RESERVED_IG_PATH_SEGMENTS.has(path)) return null;
    if (!/^[a-z0-9._]{2,30}$/.test(path)) return null;
    return path;
  } catch {
    return null;
  }
}

async function getCurrentInstagramProfileUsername() {
  if (sessionState.platform !== 'instagram') return null;

  try {
    const tab = await getOrCreatePlatformTab('instagram', { createIfMissing: false });
    if (!tab) return null;
    return parseInstagramProfileUsernameFromUrl(tab.url || '');
  } catch {
    return null;
  }
}

async function waitForInstagramProfileUsername(options = {}) {
  const {
    exclude = [],
    attempts = 8,
    delayMs = 450,
  } = options;

  const excluded = new Set(
    (Array.isArray(exclude) ? exclude : [exclude])
      .map(normalizeInstagramUsername)
      .filter(Boolean),
  );

  for (let attempt = 0; attempt < attempts; attempt++) {
    const username = normalizeInstagramUsername(await getCurrentInstagramProfileUsername());
    if (username && !excluded.has(username)) {
      return username;
    }

    if (attempt < attempts - 1) {
      await waitMs(delayMs);
    }
  }

  return null;
}

async function sendInstagramDirectComposeDM(customMessage, targetUsername) {
  const normalizedTarget = normalizeInstagramUsername(targetUsername);
  if (sessionState.platform !== 'instagram') {
    return false;
  }

  if (!normalizedTarget || !customMessage) {
    console.log('[Futnor Background] Instagram profile DM aborted — missing target username or message');
    return false;
  }

  const tab = await getOrCreatePlatformTab('instagram', { createIfMissing: false });
  if (!tab?.id) {
    console.log('[Futnor Background] Instagram profile DM aborted — no Instagram tab available');
    return false;
  }

  const tabUrl = tab.url || '';
  const alreadyOnDirectThread = tabUrl.includes('/direct/');

  if (!alreadyOnDirectThread) {
    const onProfile = await sendActionToTab('navigateProfile', null, [normalizedTarget]);
    if (!onProfile) {
      console.log(`[Futnor Background] Failed to navigate to @${normalizedTarget} before DM attempt`);
      const navigated = await navigateTabAndWait(tab.id, `https://www.instagram.com/${normalizedTarget}/`);
      if (!navigated) return false;
      await waitMs(randomInt(1800, 2600));
    } else {
      await waitMs(randomInt(900, 1500));
    }
  }

  let dmSent = alreadyOnDirectThread
    ? await sendActionToTab('sendDMMessage', customMessage, [normalizedTarget])
    : await sendActionToTab('profileDM', customMessage, [normalizedTarget]);

  if (!dmSent) {
    console.log(`[Futnor Background] Profile DM flow failed for @${normalizedTarget} — checking DM recovery...`);
    dmSent = await attemptDMRecovery(customMessage, normalizedTarget);
  }

  return dmSent;
}

// Helper: send profileMultiLike to the platform tab using centralized tab management
async function sendProfileMultiLike() {
  const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
  if (!tab) return { success: false, likesCount: 0 };
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: 'PERFORM_ACTION', action: 'profileMultiLike' });
    return resp || { success: false, likesCount: 0 };
  } catch {
    return { success: false, likesCount: 0 };
  }
}

function getRandom(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function coerceNumber(value, fallback, options = {}) {
  const { min = -Infinity, max = Infinity, integer = false } = options;
  const numeric = typeof value === 'number' ? value : Number(value);
  const safeValue = Number.isFinite(numeric) ? numeric : fallback;
  const normalized = integer ? Math.round(safeValue) : safeValue;
  return Math.min(max, Math.max(min, normalized));
}

function sanitizeSessionConfig(rawConfig = {}) {
  const merged = { ...DEFAULT_STATE.config, ...(rawConfig || {}) };
  const sessionMin = coerceNumber(merged.sessionMin, DEFAULT_STATE.config.sessionMin, { min: 1, integer: true });
  const sessionMax = coerceNumber(
    merged.sessionMax,
    Math.max(sessionMin, DEFAULT_STATE.config.sessionMax),
    { min: sessionMin, integer: true }
  );
  const minActionDelay = coerceNumber(merged.minActionDelay, DEFAULT_STATE.config.minActionDelay, { min: 1, integer: true });
  const maxActionDelay = coerceNumber(
    merged.maxActionDelay,
    Math.max(minActionDelay, DEFAULT_STATE.config.maxActionDelay),
    { min: minActionDelay, integer: true }
  );

  return {
    ...merged,
    sessionMin,
    sessionMax,
    scrollWeight: coerceNumber(merged.scrollWeight, DEFAULT_STATE.config.scrollWeight, { min: 0, integer: true }),
    likeWeight: coerceNumber(merged.likeWeight, DEFAULT_STATE.config.likeWeight, { min: 0, integer: true }),
    dmWeight: coerceNumber(merged.dmWeight, DEFAULT_STATE.config.dmWeight, { min: 0, integer: true }),
    minActionDelay,
    maxActionDelay,
    dailyMaxDMs: coerceNumber(merged.dailyMaxDMs, DEFAULT_STATE.config.dailyMaxDMs, { min: 0, integer: true }),
    dailyMaxLikes: coerceNumber(merged.dailyMaxLikes, DEFAULT_STATE.config.dailyMaxLikes, { min: 0, integer: true }),
    dailyMaxFollows: coerceNumber(merged.dailyMaxFollows, DEFAULT_STATE.config.dailyMaxFollows, { min: 0, integer: true }),
    followEnabled: merged.followEnabled === true,
    sessionDmGoal: coerceNumber(merged.sessionDmGoal, 0, { min: 0, integer: true }),
  };
}

async function waitForTabComplete(tabId, timeoutMs = 15000) {
  const startedAt = Date.now();

  while (Date.now() - startedAt < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab?.status === 'complete') return true;
    } catch {
      return false;
    }

    await new Promise((resolve) => setTimeout(resolve, 400));
  }

  return false;
}

async function primePlatformTabForSession(platform, options = {}) {
  const {
    createIfMissing = true,
    focus = false,
    sessionSignal = 'SESSION_START',
  } = options;

  const targetTab = await getOrCreatePlatformTab(platform, { createIfMissing, focus });
  if (!targetTab?.id) {
    return { ok: false, reason: 'tab_unavailable' };
  }

  if (platform === 'instagram') {
    preferredInstagramTabId = targetTab.id;
  }

  await waitForTabComplete(targetTab.id);

  let contentReady = await ensureContentScript(targetTab.id, platform);
  if (!contentReady) {
    contentReady = await waitForContentScript(platform, 20);
  }

  if (!contentReady) {
    console.warn('[Futnor Tab] Content script not ready after all attempts — tab:', targetTab.id, targetTab.url);
    return { ok: false, reason: 'content_script_not_ready', tab: targetTab };
  }

  try {
    await chrome.tabs.sendMessage(targetTab.id, { type: sessionSignal });
  } catch {}

  try {
    await chrome.tabs.sendMessage(targetTab.id, { type: 'SHOW_BOT_BANNER' });
  } catch {}

  return { ok: true, tab: targetTab };
}

function pickNextAction(config, platform) {
  const total = config.scrollWeight + config.likeWeight + config.dmWeight;
  const rand = Math.random() * total;
  if (rand < config.scrollWeight) return 'scroll';
  if (rand < config.scrollWeight + config.likeWeight) return 'likeFollow';
  return platform === 'tiktok' ? 'comment' : 'dm';
}

function getRandomDelay(config) {
  return getRandom(config.minActionDelay, config.maxActionDelay) * 1000;
}

// Quick check — returns true if session was stopped externally
function shouldStop() {
  return !sessionState.isRunning;
}

// Interruptible delay: resolves early the moment the session is stopped or paused.
// Use this instead of bare setTimeout in the main session loop.
function waitMs(ms) {
  if (shouldStop() || ms <= 0) return Promise.resolve();
  return new Promise(resolve => {
    const end = Date.now() + ms;
    function tick() {
      if (shouldStop() || Date.now() >= end) return resolve();
      setTimeout(tick, Math.min(80, end - Date.now()));
    }
    setTimeout(tick, Math.min(80, ms));
  });
}

// Async pause-aware stop check: waits if paused, returns true if should stop
async function checkPauseOrStop() {
  if (sessionState.isPaused) {
    const shouldContinue = await waitWhilePaused();
    if (!shouldContinue) return true;
  }
  return !sessionState.isRunning;
}

// Wait while session is paused; resolves immediately if not paused.
// Returns false if session was stopped during the pause (caller should break).
async function waitWhilePaused() {
  while (sessionState.isPaused && sessionState.isRunning) {
    await waitMs(300);
  }
  return sessionState.isRunning; // false = stopped while paused
}

// Send an immediate stop/pause signal to the content script so in-flight
// operations (sleep loops, navigation waits, etc.) abort right away.
async function signalContentScriptStop(type = 'SESSION_STOP') {
  try {
    const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { type }, () => { chrome.runtime.lastError; });
    }
  } catch {}
}

function addLog(action, message) {
  sessionState.logs.unshift({
    id: Math.random().toString(36).substring(2, 9),
    timestamp: new Date().toISOString(),
    action,
    message,
  });
  if (sessionState.logs.length > 100) sessionState.logs.length = 100;
  saveState();
  // Push live update to banner on platform tab
  updateBannerLive(message);
}

async function updateBannerLive(latestLog) {
  if (!sessionState.isRunning) return;
  try {
    const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, {
        type: 'UPDATE_BANNER',
        stats: sessionState.stats,
        latestLog,
      }).catch(() => {});
    }
  } catch {}
}

// Wait for content script to be ready by pinging it — uses centralized tab management
async function waitForContentScript(platform, maxAttempts = 20) {
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    console.log(`[Futnor Background] Checking content script readiness (attempt ${attempt}/${maxAttempts})...`);
    
    // NEVER create a new tab here — only reuse the one already created by primePlatformTabForSession
    const tab = await getOrCreatePlatformTab(platform, { createIfMissing: false });
    if (!tab) {
      console.log('[Futnor Background] No tab available, waiting...');
      await waitMs(1000);
      continue;
    }
    
    // Wait for tab to finish loading
    try {
      const freshTab = await chrome.tabs.get(tab.id);
      if (freshTab.status !== 'complete') {
        console.log('[Futnor Background] Tab still loading, waiting...');
        await waitMs(1500);
        continue;
      }
    } catch {
      // Tab gone — clear preferred and retry
      if (platform === 'instagram') preferredInstagramTabId = null;
      continue;
    }
    
    // Try injecting the content script proactively on early attempts
    if (attempt === 2 || attempt === 5 || attempt === 10) {
      await ensureContentScript(tab.id, platform);
    }
    
    try {
      const response = await chrome.tabs.sendMessage(tab.id, { type: 'PING' });
      if (response?.ready) {
        console.log('[Futnor Background] Content script ready on tab', tab.id);
        return true;
      }
    } catch (e) {
      console.log('[Futnor Background] Content script not ready yet:', e.message);
    }
    
    await waitMs(800);
  }
  
  console.error('[Futnor Background] Content script failed to load after', maxAttempts, 'attempts');
  return false;
}

async function handleExtensionReconnect(reason = 'connection_lost') {
  if (!sessionState.isRunning) return false;

  if (!sessionState.reconnecting) {
    console.warn('[Futnor Background] Entering reconnect mode:', reason);
    sessionState.reconnecting = true;
    sessionState.isPaused = true;
    addLog('session_start', 'Reconnecting to extension...');
    saveState();
  }

  while (sessionState.isRunning && sessionState.reconnecting) {
    try {
      await revalidatePlatformTab(sessionState.platform);
      const result = await primePlatformTabForSession(sessionState.platform, {
        createIfMissing: true,
        focus: false,
        sessionSignal: 'SESSION_RESUME',
      });

      if (result.ok) {
        sessionState.reconnecting = false;
        sessionState.isPaused = false;
        addLog('session_start', '✅ Extension reconnected — resuming session');
        saveState();
        return true;
      }
    } catch (error) {
      console.warn('[Futnor Background] Reconnect attempt failed:', error?.message || error);
    }

    await waitMs(2000);
  }

  return false;
}

async function sendActionToTab(action, customMessage, keywords, allowReconnectRecovery = true, handledTabNavigation = false) {
  if (sessionState.isPaused && sessionState.isRunning) {
    const shouldContinue = await waitWhilePaused();
    if (!shouldContinue) {
      return ['checkProfileDemographics', 'extractCommenters', 'getRecentPostLink', 'isProfileAccessible'].includes(action) ? null : false;
    }
  }

  if (shouldStop()) {
    return ['checkProfileDemographics', 'extractCommenters', 'getRecentPostLink', 'isProfileAccessible'].includes(action) ? null : false;
  }

  const platform = sessionState.platform;
  const MAX_RETRIES = 4;
  const RETRY_DELAY_MS = 1500;
  const isInfoAction = ['checkProfileDemographics', 'extractCommenters', 'getRecentPostLink', 'isProfileAccessible'].includes(action);
  const payload = {
    type: 'PERFORM_ACTION',
    action,
    customMessage,
    keywords,
    allowExistingChats: !!sessionState.targeting?.allowExistingChats,
  };

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    await revalidatePlatformTab(platform);
    const targetTab = await getOrCreatePlatformTab(platform, { createIfMissing: false });

    if (!targetTab) {
      if (allowReconnectRecovery) {
        const recovered = await handleExtensionReconnect('platform_tab_missing');
        if (recovered) {
          return sendActionToTab(action, customMessage, keywords, false, handledTabNavigation);
        }
      }

      console.error('[Futnor Background] No platform tab found');
      return isInfoAction ? null : false;
    }

    try {
      console.log(`[Futnor Background] Sending action (attempt ${attempt}/${MAX_RETRIES}):`, targetTab.id, action);
      const response = await chrome.tabs.sendMessage(targetTab.id, payload);
      console.log('[Futnor Background] Response:', response);

      if (response && typeof response === 'object' && response.needsTabNavigation) {
        console.log('[Futnor Background] Content script requests tab navigation to:', response.url);
        const navigated = await navigateTabAndWait(targetTab.id, response.url);
        if (!navigated) return isInfoAction ? null : false;

        if (action === 'dm' || action === 'sendDirectDM') {
          if (handledTabNavigation) {
            console.warn(`[Futnor Background] ${action} requested tab navigation twice — aborting to avoid false success`);
            return false;
          }

          console.log(`[Futnor Background] ${action} tab navigation complete — re-dispatching action`);
          return sendActionToTab(action, customMessage, keywords, allowReconnectRecovery, true);
        }

        return true;
      }

      return isInfoAction ? response : (response?.success ?? false);
    } catch (e) {
      console.error(`[Futnor Background] Attempt ${attempt} failed:`, e.message);

      if (attempt <= 2) {
        const injected = await ensureContentScript(targetTab.id, platform);
        if (injected) {
          try { await chrome.tabs.sendMessage(targetTab.id, { type: 'SHOW_BOT_BANNER' }); } catch {}
          continue;
        }
      }

      if (attempt === MAX_RETRIES) {
        // ── DM-navigation guard ──────────────────────────────────────
        // profileDM clicks the "Message" button which can hard-navigate
        // to /direct/t/…, killing the content script mid-execution.
        // Triggering a full reconnect here would re-send profileDM on
        // the /direct/ page, which SPA-navigates back to the profile,
        // clicks Message again → infinite reconnect loop.
        // Instead, bail immediately so attemptDMRecovery (called by the
        // session loop) can handle the send on the /direct/ page cleanly.
        if (action === 'profileDM' || action === 'sendDMMessage') {
          const dmTab = await getOrCreatePlatformTab(platform, { createIfMissing: false });
          if (dmTab?.url?.includes('/direct/')) {
            console.log('[Futnor Background] profileDM failed — tab is on /direct/, skipping reconnect for DM recovery');
            return false;
          }
        }

        if (allowReconnectRecovery) {
          const recovered = await handleExtensionReconnect('message_channel_lost');
          if (recovered) {
            return sendActionToTab(action, customMessage, keywords, false, handledTabNavigation);
          }
        }

        console.error('[Futnor Background] Max retries reached, skipping action');
        return isInfoAction ? null : false;
      }

      await waitMs(RETRY_DELAY_MS);
    }
  }

  return isInfoAction ? null : false;
}

// Navigate a tab to a URL at the browser level and wait for content script readiness
async function navigateTabAndWait(tabId, url) {
  try {
    await chrome.tabs.update(tabId, { url });
    console.log('[Futnor Background] Tab navigation initiated to:', url);

    const platform = sessionState.platform;
    let tabComplete = false;
    let injectionAttempts = 0;

    // Phase 1: wait for tab to reach 'complete' status (up to ~24 seconds)
    for (let i = 0; i < 30; i++) {
      await waitMs(800);
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab.status === 'complete') { tabComplete = true; break; }
      } catch {
        console.warn('[Futnor Background] navigateTabAndWait: tab gone during load');
        return false; // Tab destroyed — abort
      }
    }

    if (!tabComplete) {
      console.warn('[Futnor Background] navigateTabAndWait: tab never reached complete status');
      // Proceed anyway — might have stalled but content could still be loaded
    }

    // Phase 2: wait for content script to be responsive (up to ~15 seconds)
    for (let i = 0; i < 15; i++) {
      if (i === 0) {
        await waitMs(1200); // Initial settle time after tab complete
      } else {
        await waitMs(700);
      }

      // Inject content script on first and fifth attempt if not responding
      if ((i === 0 || i === 4) && injectionAttempts < 2) {
        try {
          const scriptFile = platform === 'tiktok' ? 'tiktok/content.js' : 'instagram/content.js';
          await chrome.scripting.executeScript({ target: { tabId }, files: [scriptFile] });
          injectionAttempts++;
          console.log(`[Futnor Background] navigateTabAndWait: injected content script (attempt ${injectionAttempts})`);
          await waitMs(800);
        } catch (injectErr) {
          console.warn('[Futnor Background] navigateTabAndWait: injection failed:', injectErr?.message);
        }
      }

      try {
        const ping = await chrome.tabs.sendMessage(tabId, { type: 'PING' });
        if (ping?.ready) {
          console.log('[Futnor Background] Content script ready after tab navigation');
          try { await chrome.tabs.sendMessage(tabId, { type: 'SHOW_BOT_BANNER' }); } catch {}
          return true;
        }
      } catch {}
    }

    console.warn('[Futnor Background] navigateTabAndWait: content script not confirmed ready — proceeding (next action will handle)');
    return true; // Still return true — the action layer has its own retry/timeout
  } catch (e) {
    console.error('[Futnor Background] navigateTabAndWait failed:', e.message);
    return false;
  }
}

function normalizeMonitorUrlPath(rawUrl) {
  if (!rawUrl) return '';

  try {
    const url = new URL(rawUrl, 'https://www.instagram.com');
    return url.pathname.replace(/\/+$/, '') || '/';
  } catch {
    return rawUrl.replace(/^https?:\/\/[^/]+/i, '').replace(/\/+$/, '') || '/';
  }
}

async function loadEngagementMonitorPost(tabId, url, platform) {
  const targetPath = normalizeMonitorUrlPath(url);
  let isSamePost = false;

  try {
    const tab = await chrome.tabs.get(tabId);
    isSamePost = normalizeMonitorUrlPath(tab?.url || '') === targetPath;
  } catch {}

  if (isSamePost) {
    await chrome.tabs.reload(tabId, { bypassCache: true });
    await waitForTabComplete(tabId, 15000);
    console.log('[Futnor Background] Engagement monitor hard-refreshed current post');
  } else {
    const navigated = await navigateTabAndWait(tabId, url);
    if (!navigated) return false;
  }

  await waitMs(900);
  const ready = await ensureContentScript(tabId, platform);
  if (!ready) {
    console.warn('[Futnor Background] Engagement monitor: content script not fully ready after load');
  }
  await waitMs(600);

  try { await chrome.tabs.sendMessage(tabId, { type: 'SHOW_BOT_BANNER' }); } catch {}
  return true;
}

// ─── DM Recovery: handle when clicking Message navigates to /direct/ ───
// After profileDM fails, check if tab navigated to /direct/t/... and send message there
async function attemptDMRecovery(customMessage, targetUsername = null) {
  const platform = sessionState.platform;
  
  // Wait a moment for any navigation to settle
  await waitMs(2000);
  
  const tab = await getOrCreatePlatformTab(platform, { createIfMissing: false });
  if (!tab) return false;

  const tabUrl = tab.url || '';

  // Check if the tab navigated to a DM page
  if (!tabUrl.includes('/direct/')) {
    console.log('[Futnor Background] DM recovery aborted — tab never reached a /direct/ thread after profile flow');
    return false;
  }

  console.log('[Futnor Background] Tab navigated to DM page:', tabUrl);

  // Re-fetch tab to get the most current URL (navigation may have settled further)
  let freshTab;
  try { freshTab = await chrome.tabs.get(tab.id); } catch { freshTab = tab; }
  const freshUrl = freshTab?.url || tabUrl;

  // If on inbox (not a specific thread), click the top conversation to open it
  if (freshUrl.includes('/direct/inbox') && !freshUrl.includes('/direct/t/')) {
    console.log('[Futnor Background] On inbox page — attempting to open top conversation...');

    // Wait for inbox to load
    await waitMs(2500);

    // Ask content script to open the target conversation thread
    const openedThread = await sendActionToTab('openTopDMThread', null, targetUsername ? [targetUsername] : undefined);
    if (!openedThread) {
      // openTopDMThread failed — but the conversation may already be open in the right pane
      // (Instagram sometimes pre-selects the new thread without navigating to /direct/t/).
      // Fall through and let sendDMMessage try to find the composer directly.
      console.log('[Futnor Background] openTopDMThread failed — will still try sendDMMessage in case composer is already visible');
    } else {
      // Wait for thread navigation to settle
      await waitMs(3000);
    }
  }
  
  // Wait for tab to finish loading
  if (tab.status !== 'complete') {
    await new Promise((resolve) => {
      const listener = (updatedTabId, changeInfo) => {
        if (updatedTabId === tab.id && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 8000);
    });
  }
  
  // Ensure content script is injected and ready on the /direct/ page.
  // The manifest auto-injects at document_idle, but after a hard navigation
  // the tab may still be loading.  Explicitly inject if PING fails.
  await waitMs(1500);

  let contentReady = await ensureContentScript(tab.id, platform);
  if (!contentReady) {
    // Second chance — wait longer for the page to settle after navigation
    await waitMs(3000);
    contentReady = await ensureContentScript(tab.id, platform);
  }

  if (!contentReady) {
    console.log('[Futnor Background] Content script not ready on DM page after injection attempts');
    return false;
  }
  
  // Send the message using the sendDMMessage action
  console.log('[Futnor Background] Attempting DM recovery on full DM page...');
  const result = await sendActionToTab('sendDMMessage', customMessage, targetUsername ? [targetUsername] : undefined);
  return result;
}

// Skip when the profile is unreachable (not_found / restricted), but honor the
// "Include Private Accounts" targeting toggle so private profiles get DM'd when
// the user opted in. Private DMs land in the recipient's message-request folder.
function shouldSkipForAccess(accessCheck) {
  if (!accessCheck || accessCheck.accessible) return false;
  if (accessCheck.reason === 'private' && sessionState.targeting?.includePrivateAccounts) {
    return false;
  }
  return true;
}

// ─── Demographics & profile stats filter check ───
// Returns true if profile passes all filters (demographics + follower/post count), false if should be skipped
async function checkDemographicsFilter() {
  const targeting = sessionState.targeting || {};
  const genderEnabled = targeting.filterGenderEnabled;
  const ageEnabled = targeting.filterAgeEnabled;
  const followersEnabled = targeting.filterFollowersEnabled;
  const postsEnabled = targeting.filterPostsEnabled;
  
  // If no filters are enabled, always pass
  if (!genderEnabled && !ageEnabled && !followersEnabled && !postsEnabled) return true;
  
  const result = await sendActionToTab('checkProfileDemographics');
  if (!result || !result.demographics) {
    console.log('[Futnor Background] Could not read profile data, allowing profile');
    return true; // Can't read → don't block
  }
  
  const { gender, age, followers, posts } = result.demographics;
  
  // Follower count check
  if (followersEnabled) {
    const min = targeting.filterFollowersMin ?? 0;
    const max = targeting.filterFollowersMax ?? 999999999;
    if (followers === null || followers === undefined) {
      console.log('[Futnor Background] Follower count unknown, allowing profile');
    } else if (followers < min || followers > max) {
      addLog('dm_skipped', `⏭️ Followers ${followers.toLocaleString()} outside range ${min.toLocaleString()}-${max.toLocaleString()}`);
      return false;
    }
  }
  
  // Post count check
  if (postsEnabled) {
    const min = targeting.filterPostsMin ?? 0;
    const max = targeting.filterPostsMax ?? 999999999;
    if (posts === null || posts === undefined) {
      console.log('[Futnor Background] Post count unknown, allowing profile');
    } else if (posts < min || posts > max) {
      addLog('dm_skipped', `⏭️ Posts ${posts.toLocaleString()} outside range ${min.toLocaleString()}-${max.toLocaleString()}`);
      return false;
    }
  }
  
  // Gender check
  if (genderEnabled && targeting.filterGender && targeting.filterGender !== 'any') {
    if (gender === 'unknown') {
      console.log('[Futnor Background] Gender unknown, allowing profile');
    } else if (gender !== targeting.filterGender) {
      addLog('dm_skipped', `⏭️ Gender mismatch: ${gender} (filter: ${targeting.filterGender})`);
      return false;
    }
  }
  
  // Age check
  if (ageEnabled && targeting.filterAgeMin != null && targeting.filterAgeMax != null) {
    if (age === null || age === undefined) {
      console.log('[Futnor Background] Age unknown, allowing profile');
    } else if (age < targeting.filterAgeMin || age > targeting.filterAgeMax) {
      addLog('dm_skipped', `⏭️ Age ${age} outside range ${targeting.filterAgeMin}-${targeting.filterAgeMax}`);
      return false;
    }
  }
  
  // Log what passed
  const parts = [];
  if (gender !== 'unknown') parts.push(gender);
  if (age !== null && age !== undefined) parts.push(`age ${age}`);
  if (followers !== null && followers !== undefined) parts.push(`${followers.toLocaleString()} followers`);
  if (posts !== null && posts !== undefined) parts.push(`${posts.toLocaleString()} posts`);
  if (parts.length > 0) {
    addLog('scroll', `✅ Profile match: ${parts.join(', ')}`);
  }
  return true;
}

async function runSession(options = {}) {
  // Guard against concurrent session loops
  if (sessionLoopActive && sessionLoopPromise) {
    console.log('[Futnor Background] Session loop already active, waiting for it to finish...');
    try { await sessionLoopPromise; } catch (e) {
      console.error('[Futnor Background] Previous session loop threw before new session:', e?.message || e);
    }
  }

  // Detect the logged-in Instagram account to scope history per account
  try {
    await detectAndSyncActiveAccount(sessionState.platform);
  } catch (err) {
    console.warn('[Futnor Background] Could not detect logged-in username:', err?.message || err);
  }

  console.log(`[Futnor Background] History scoped to account: ${activeAccountUsername || '(global)'}`);

  // Load persistent histories BEFORE anything else so we never revisit handled targets
  await Promise.all([
    refreshBgDMHistory(),
    refreshBgProcessedAccounts(),
  ]);

  const { resume = false } = options;
  sessionLoopActive = true;

  sessionState.config = sanitizeSessionConfig(sessionState.config);

  const { platform, aiTargeting } = sessionState;
  let config = { ...sessionState.config }; // Local copy — safe to modify (e.g. zeroing dmWeight when no templates)
  const isAITargeting = aiTargeting?.enabled && aiTargeting.searchTerms?.length > 0;
  const savedSessionTime = sessionState.stats.sessionTime || 0;
  const savedElapsedTime = sessionState.stats.elapsedTime || 0;
  const nextSessionTime = resume && savedSessionTime > savedElapsedTime
    ? savedSessionTime
    : getRandom(config.sessionMin * 60, config.sessionMax * 60);
  const sessionTime = Number.isFinite(nextSessionTime) && nextSessionTime > 0
    ? nextSessionTime
    : getRandom(DEFAULT_STATE.config.sessionMin * 60, DEFAULT_STATE.config.sessionMax * 60);

  sessionState.stats.sessionTime = sessionTime;
  sessionState.stats.elapsedTime = resume ? Math.min(savedElapsedTime, sessionTime) : 0;
  sessionState.isRunning = true;
  sessionState.isPaused = false;
  sessionState.reconnecting = false;
  saveState();

  // Use dmTemplates from session state only — no cache or fallback sources.
  let customMessage = sanitizeDMTemplates(sessionState.dmTemplates);

  const platformLabel = platform === 'tiktok' ? 'TikTok' : 'Instagram';
  const modeLabel = isAITargeting ? ' [AI Targeting]' : '';
  addLog('session_start', resume
    ? `[${platformLabel}]${modeLabel} Session resumed at ${Math.round(sessionState.stats.elapsedTime / 60)} min elapsed`
    : `[${platformLabel}]${modeLabel} Session started, target: ${Math.round(sessionTime / 60)} min`);

  if (customMessage.length === 0) {
    addLog('dm_skipped', 'ERROR: DM script is empty or not loaded');
    addLog('session_start', '⚠️ No DM scripts found — DMs will be skipped. Configure scripts in the DM Mode section.');
    customMessage = null; // Ensure it's null so DMs are skipped gracefully
    // Zero out dmWeight so the action picker never wastes a cycle picking DM
    if (config.dmWeight > 0) {
      config = { ...config, dmWeight: 0 };
      console.log('[Futnor Background] dmWeight zeroed — no DM templates loaded');
    }
  } else {
    addLog('session_start', `✅ Loaded ${customMessage.length} DM script variation(s)`);
  }

  if (isAITargeting) {
    addLog('scroll', `AI Targeting active — searching for: ${aiTargeting.searchTerms.slice(0, 3).join(', ')}...`);
  } else {
    const t = sessionState.targeting || {};
    const type = t.targetTypes?.[0];
    if (type === 'hashtags') addLog('scroll', `🎯 Targeting hashtags: ${t.hashtags}`);
    else if (type === 'followers') addLog('scroll', `🎯 Targeting followers of @${t.targetUsername}`);
    else if (type === 'following') addLog('scroll', `🎯 Targeting following of @${t.targetUsername}`);
    else if (type === 'custom') addLog('scroll', `🎯 Targeting ${t.customUsernames?.length || 0} custom usernames`);
    else if (type === 'likers') addLog('scroll', `🎯 Targeting likers of post`);
    else if (type === 'commenters') addLog('scroll', `🎯 Targeting commenters of post`);
  }

  addLog('session_start', '✅ Content script ready, starting automation...');

  // Show "Do not close" banner on platform tab
  await showBannerOnPlatformTab(platform);
  // Re-send banner after a short delay in case content script wasn't ready
  setTimeout(() => { if (sessionState.isRunning) showBannerOnPlatformTab(platform); }, 3000);

  const tickAlarm = 'session-tick';
  chrome.alarms.create(tickAlarm, { periodInMinutes: 1 / 60 });

  let elapsed = resume ? Math.min(savedElapsedTime, sessionTime) : 0;
  let aiPhase = 'search';
  let accountsEngaged = 0;
  const searchTermIndex = { current: 0 };
  let customTargetCursor = 0;

  function pickMessage() {
    const availableTemplates = sanitizeDMTemplates(customMessage);
    if (availableTemplates.length === 0) {
      console.log('[Futnor Background] ERROR: DM script is empty or not loaded');
      return null;
    }
    const msg = availableTemplates[Math.floor(Math.random() * availableTemplates.length)];
    console.log('[Futnor Background] Selected DM script:', msg.slice(0, 160));
    return msg;
  }

  const isAccountAlreadyHandled = (username) => {
    const normalized = normalizeInstagramUsername(username);
    if (!normalized) return false;
    return isInBgDMHistory(normalized) || isInBgProcessedAccounts(normalized);
  };

  const rememberProcessedAccount = async (username) => {
    const normalized = normalizeInstagramUsername(username);
    if (!normalized) return;
    await addToBgProcessedAccounts(normalized);
  };

  while (elapsed < sessionTime && sessionState.isRunning) {
    // ── Pause gate: freeze the loop while paused ──
    if (sessionState.isPaused) {
      const shouldContinue = await waitWhilePaused();
      if (!shouldContinue) break; // stopped while paused
    }
    const { stats: s, config: c } = sessionState;
    
    // Only consider a limit "hit" if the max is > 0 AND we've reached it
    const likesHit = c.dailyMaxLikes > 0 && s.likesSent >= c.dailyMaxLikes;
    const followsHit = c.followEnabled && c.dailyMaxFollows > 0 && s.followsSent >= c.dailyMaxFollows;
    const dmsHit = c.dailyMaxDMs > 0 && s.dmsSent >= c.dailyMaxDMs;
    
    // All enabled limits must be hit (limits set to 0 = disabled, not "reached")
    const allEnabled = [
      c.dailyMaxLikes > 0 ? likesHit : null,
      (c.followEnabled && c.dailyMaxFollows > 0) ? followsHit : null,
      c.dailyMaxDMs > 0 ? dmsHit : null,
    ].filter(v => v !== null);
    
    const hitAllLimits = allEnabled.length > 0 && allEnabled.every(v => v === true);
    
    if (hitAllLimits) {
      addLog('session_end', '✅ All daily limits reached — session complete');
      sessionState.warmupOffer = true;
      break;
    }

    // Session DM goal check — auto-stop when the user's DM goal for this session is met
    const dmGoal = sessionState.config.sessionDmGoal || 0;
    if (dmGoal > 0 && s.dmsSent >= dmGoal) {
      addLog('session_end', `🎯 Session ${platform === 'tiktok' ? 'comment' : 'DM'} goal reached (${dmGoal}) — session complete`);
      sessionState.warmupOffer = true;
      break;
    }

    let performed = false;

    if (isAITargeting) {
      switch (aiPhase) {
        case 'search': {
          // Convert search terms to hashtags for better discovery
          const terms = aiTargeting.searchTerms;
          const currentTerm = terms[searchTermIndex.current % terms.length];
          searchTermIndex.current++;
          // Convert term to hashtag format (remove spaces, join words)
          const hashtag = currentTerm.replace(/\s+/g, '').toLowerCase();
          
          if (platform === 'tiktok') {
            performed = await sendActionToTab('discoverSearch', null, [currentTerm]);
          } else {
            // Use hashtag navigation instead of text search for better results
            performed = await sendActionToTab('navigateHashtag', null, [hashtag]);
          }
          if (performed) {
            sessionState.stats.scrolls++;
            addLog('scroll', `#️⃣ AI: Browsing #${hashtag} on ${platformLabel}`);
            aiPhase = 'browse';
          }
          break;
        }
        case 'browse': {
          // Scroll through recent posts on the hashtag page
          performed = await sendActionToTab('scroll');
          if (performed) {
            sessionState.stats.scrolls++;
            addLog('scroll', '👁 AI: Browsing recent posts');
          }
          aiPhase = 'visitProfile';
          break;
        }
        case 'visitProfile': {
          // Visit a profile from the hashtag page, check recency
          performed = await sendActionToTab('engageRecentAccount');
          if (performed) {
            addLog('scroll', '🎯 AI: Visiting recent poster\'s profile');
            aiPhase = 'engage';
          } else {
            // No recent accounts found, try another hashtag
            addLog('scroll', '⏭️ AI: No recent accounts, switching hashtag');
            aiPhase = 'search';
          }
          break;
        }
        case 'engage': {
          const engageActions = [];
          if (sessionState.stats.likesSent < config.dailyMaxLikes) engageActions.push('like');
          if (config.followEnabled && sessionState.stats.followsSent < config.dailyMaxFollows && config.dailyMaxFollows > 0) engageActions.push('follow');
          if (sessionState.stats.dmsSent < config.dailyMaxDMs) engageActions.push('dm');

          if (engageActions.length === 0) {
            addLog('session_end', 'All daily limits reached');
            sessionState.isRunning = false;
            break;
          }

          // Skip AI targets already handled in persistent history
          const aiTargetUsername = normalizeInstagramUsername(await getCurrentInstagramProfileUsername());
          if (aiTargetUsername && isAccountAlreadyHandled(aiTargetUsername)) {
            addLog('scroll', `⏭️ AI: @${aiTargetUsername} already processed — skipping`);
            aiPhase = 'browse';
            break;
          }
          if (aiTargetUsername) {
            await rememberProcessedAccount(aiTargetUsername);
          }

          // Check if profile has recent activity (within 3 months)
          const isRecent = await sendActionToTab('checkProfileRecency');
          if (!isRecent) {
            addLog('scroll', '⏭️ AI: Profile inactive (no posts in 3 months), skipping');
            aiPhase = 'browse';
            break;
          }

          // Demographics filter check for AI targeting
          const demoPassAI = await checkDemographicsFilter();
          if (!demoPassAI) {
            addLog('scroll', '⏭️ AI: Demographics mismatch, skipping');
            aiPhase = 'browse';
            break;
          }

          if (engageActions.includes('like')) {
            const likeAction = platform === 'tiktok' ? 'creatorLike' : 'profileLike';
            performed = await sendActionToTab(likeAction);
            if (performed) {
              sessionState.stats.likesSent++;
              addLog('like', '❤️ AI: Liked post on similar account');
            }
            await waitMs(getRandomDelay(config));
          }

          // Follow (30% chance)
          if (engageActions.includes('follow') && Math.random() < 0.3) {
            const followAction = platform === 'tiktok' ? 'creatorFollow' : 'profileFollow';
            performed = await sendActionToTab(followAction);
            if (performed) {
              sessionState.stats.followsSent++;
              addLog('follow', '➕ AI: Followed similar account');
            }
            await waitMs(getRandomDelay(config));
          }

           // Always attempt DM when action is picked
          if (engageActions.includes('dm')) {
            const msg = pickMessage();
            if (msg) {
              if (platform === 'tiktok') {
                performed = await sendActionToTab('creatorComment', msg);
              } else {
                const aiDmTarget = await waitForInstagramProfileUsername({ attempts: 6, delayMs: 350 });
                performed = aiDmTarget
                  ? await sendInstagramDirectComposeDM(msg, aiDmTarget)
                  : false;
              }
              if (performed) {
                sessionState.stats.dmsSent++;
                addLog('dm', platform === 'tiktok' ? '💬 AI: Comment sent' : `📨 AI: DM sent to recent account`);
                if (platform !== 'tiktok' && aiDmTarget) {
                  try { await postCommentAfterDM(aiDmTarget); } catch {}
                }
              } else {
                addLog('dm_skipped', '⏭️ DM skipped — moving to next account');
              }
            } else {
              addLog('dm_skipped', '⚠️ No DM script configured');
            }
          }

          accountsEngaged++;
          if (accountsEngaged % 3 === 0) {
            aiPhase = 'search';
          } else {
            aiPhase = 'browse';
          }
          break;
        }
      }
    } else {
      // ── Manual Targeting Session Flow ──
      // CLEAR workflow per account: open modal → pick account → go to profile → like → DM via 3-dots → go back → repeat
      const targeting = sessionState.targeting || {};
      const targetType = targeting.targetTypes?.[0] || '';
      const hasTargeting = ['hashtags', 'followers', 'following', 'location', 'likers', 'commenters', 'custom'].includes(targetType);
      
      // Faster delay helper — still varied but tighter
      const humanDelay = (base) => Math.max(300, Math.round(base * 0.5) + getRandom(-200, 200));
      
      if (hasTargeting && (targetType === 'followers' || targetType === 'following') && targeting.targetUsername?.trim()) {
        // ═══ FOLLOWERS/FOLLOWING FLOW ═══
        // Step 1: Navigate to target profile and open followers/following modal
        const onTargetPage = await sendActionToTab('navigateUserFollowers', null, [targeting.targetUsername, targetType]);
        if (!onTargetPage) {
          addLog('dm_skipped', `⚠️ Could not open ${targetType} list for @${targeting.targetUsername}`);
          sessionState.stats.scrolls++;
          await waitMs(humanDelay(1500));
          continue;
        }
        addLog('scroll', `👥 Opened ${targetType} of @${targeting.targetUsername}`);
        sessionState.stats.scrolls++;
        await waitMs(humanDelay(1000));
        
        // Step 2: Pick an account from the modal (retry with deeper scrolling if needed)
        let visited = false;
        let selectedFollowerUsername = null;
        const maxModalAttempts = 5;
        for (let attempt = 0; attempt < maxModalAttempts; attempt++) {
          const engageResult = await sendActionToTab('engageFollowerModalCandidate');
          visited = Boolean(engageResult?.success || engageResult === true);
          selectedFollowerUsername = normalizeInstagramUsername(engageResult?.username);
          if (visited) break;
          addLog('scroll', `🔄 No fresh accounts yet, scrolling follower popup deeper (${attempt + 2}/${maxModalAttempts})...`);
          await sendActionToTab('navigateUserFollowers', null, [targeting.targetUsername, targetType]);
          await waitMs(humanDelay(550));
        }
        if (!visited) {
          addLog('dm_skipped', '⚠️ Could not load new followers/following accounts from popup');
          await waitMs(humanDelay(700));
          continue;
        }
        
        // Now we're on the target user's profile page
        addLog('scroll', '🎯 Opened account profile from list');
        await waitMs(humanDelay(1200));

        // Pre-check: skip if already handled in persistent history (DM sent or already processed)
        const sourceTargetUsername = normalizeInstagramUsername(targeting.targetUsername);
        const followerProfileUsername = selectedFollowerUsername || await waitForInstagramProfileUsername({
          exclude: sourceTargetUsername ? [sourceTargetUsername] : [],
          attempts: 10,
          delayMs: 400,
        });

        if (followerProfileUsername && isAccountAlreadyHandled(followerProfileUsername)) {
          addLog('scroll', `⏭️ @${followerProfileUsername} already processed — skipping`);
          const clean = targeting.targetUsername.replace(/^@/, '');
          await sendActionToTab('navigateProfile', null, [clean]);
          await waitMs(humanDelay(300));
          continue;
        }
        
        // Check if profile is accessible (not found, private, restricted)
        const accessCheck = await sendActionToTab('isProfileAccessible');
        if (shouldSkipForAccess(accessCheck)) {
          const reason = accessCheck.reason === 'not_found' ? 'account not found'
            : accessCheck.reason === 'private' ? 'private account'
            : 'not accessible';
          addLog('dm_skipped', `⏭️ @${followerProfileUsername || 'unknown'} — ${reason}, skipping`);
          if (followerProfileUsername) await rememberProcessedAccount(followerProfileUsername);
          const clean = targeting.targetUsername.replace(/^@/, '');
          await sendActionToTab('navigateProfile', null, [clean]);
          await waitMs(humanDelay(300));
          continue;
        }
        
        // Demographics filter check
        const demoPass1 = await checkDemographicsFilter();
        if (!demoPass1) {
          addLog('dm_skipped', `⏭️ @${followerProfileUsername || 'unknown'} does not match account filters — skipping`);
          if (followerProfileUsername) await rememberProcessedAccount(followerProfileUsername);
          const clean = targeting.targetUsername.replace(/^@/, '');
          await sendActionToTab('navigateProfile', null, [clean]);
          await waitMs(humanDelay(300));
          continue;
        }

        // Mark as processed AFTER all checks pass — so wrongly-rejected accounts can be retried
        if (followerProfileUsername) {
          await rememberProcessedAccount(followerProfileUsername);
        }
        
        // Step 3: Browse profile humanly (scroll, view stories) — especially in human mode
        const isHumanMode = config.dmMode === 'human';
        if (!shouldStop() && (isHumanMode || Math.random() < 0.6)) {
          addLog('scroll', '👀 Browsing profile...');
          await sendActionToTab('browseProfile');
          await waitMs(humanDelay(isHumanMode ? 1500 : 800));
        }
        
        // Step 4: Like 1-3 posts
        if (!shouldStop() && sessionState.stats.likesSent < config.dailyMaxLikes) {
          try {
            const result = await sendProfileMultiLike();
            if (result.success && result.likesCount > 0) {
              sessionState.stats.likesSent += result.likesCount;
              addLog('like', `❤️ Liked ${result.likesCount} post(s)`);
            }
          } catch (e) {
            const liked = await sendActionToTab('profileLike');
            if (liked) {
              sessionState.stats.likesSent++;
              addLog('like', '❤️ Liked a post');
            }
          }
          await waitMs(humanDelay(1000));
        }
        
        // Step 4: Follow (~15% chance)
        if (!shouldStop() && config.followEnabled && sessionState.stats.followsSent < config.dailyMaxFollows && config.dailyMaxFollows > 0 && Math.random() < 0.15) {
          const followed = await sendActionToTab('profileFollow');
          if (followed) {
            sessionState.stats.followsSent++;
            addLog('follow', '➕ Followed account');
          }
          await waitMs(humanDelay(800));
        }
        
        // Step 5: SEND DM — ensure we're on the profile page first
        if (!shouldStop() && sessionState.stats.dmsSent < config.dailyMaxDMs) {
          const msg = pickMessage();
          if (msg) {
            addLog('dm', '💬 Attempting DM...');
            const dmTargetUsername = normalizeInstagramUsername(followerProfileUsername)
              || normalizeInstagramUsername(await getCurrentInstagramProfileUsername());
            // Navigate back to profile in case multiLike left us on /p/ page
            if (dmTargetUsername) {
              await sendActionToTab('navigateProfile', null, [dmTargetUsername]);
              await waitMs(humanDelay(800));
            }
            const dmSent = dmTargetUsername
              ? await sendInstagramDirectComposeDM(msg, dmTargetUsername)
              : false;
            if (dmSent) {
              sessionState.stats.dmsSent++;
              if (dmTargetUsername) await addToBgDMHistory(dmTargetUsername);
              addLog('dm', '📨 DM sent successfully!');
              if (dmTargetUsername) { try { await postCommentAfterDM(dmTargetUsername); } catch {} }
            } else {
              addLog('dm_skipped', '⏭️ DM could not be sent — moving to next account');
            }
            await waitMs(humanDelay(1200));
          } else {
            addLog('dm_skipped', '⚠️ No DM script configured');
          }
        }
        
        if (shouldStop()) continue;
        
        // Step 6: Navigate back
        const clean = targeting.targetUsername.replace(/^@/, '');
        addLog('scroll', `↩️ Navigating back to @${clean}...`);
        await sendActionToTab('navigateProfile', null, [clean]);
        await waitMs(humanDelay(800));
        
        // Pause between accounts (1.5-3.5 seconds)
        await waitMs(getRandom(1500, 3500));
        performed = true;
        
      } else if (hasTargeting && targetType === 'hashtags' && targeting.hashtags?.trim()) {
        // ═══ HASHTAG FLOW (ONE-AT-A-TIME): navigate → pick post → profile → engage → DM → back ═══
        // Mirrors the location flow: content script finds username, stores in chrome.storage,
        // background.js polls for it, then navigates to profile and engages.
        const tags = targeting.hashtags.split(',').map(t => t.trim().replace(/^#/, '')).filter(Boolean);
        const tag = tags[Math.floor(Math.random() * tags.length)];
        
        // Step 1: Navigate to hashtag page (if not already there)
        const onHashtagPage = await sendActionToTab('navigateHashtag', null, [tag]);
        if (!onHashtagPage) {
          sessionState.stats.scrolls++;
          addLog('scroll', `⚠️ Could not load #${tag} page, retrying...`);
          await waitMs(humanDelay(2000));
          await sendActionToTab('scroll');
          continue;
        }
        addLog('scroll', `#️⃣ On #${tag} page — engaging posts one by one`);
        sessionState.stats.scrolls++;
        await waitMs(humanDelay(2000));

        // Drift guard
        {
          const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
          if (tab?.url?.includes('/reels/') || tab?.url?.includes('/direct/')) {
            addLog('scroll', '⚠️ Drifted off hashtag results — restoring');
            await sendActionToTab('navigateHashtag', null, [tag]);
            await waitMs(humanDelay(1800));
            continue;
          }
        }

        // Step 2: Ask the content script to click the next unvisited post,
        // extract the poster username, store it in chrome.storage, and close the modal.
        // Use the location-style direct message flow here to avoid reconnect loops.
        await chrome.storage.local.set({ futnor_hashtag_target_username: '' });

        let hashUsername = null;
        {
          const fireTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
          if (fireTab) {
            await ensureContentScript(fireTab.id, sessionState.platform);
            chrome.tabs.sendMessage(fireTab.id, {
              type: 'PERFORM_ACTION',
              action: 'engageNextHashtagPost',
            }).catch(() => {/* expected if the page hiccups mid-action */});
          }
        }

        for (let poll = 0; poll < 40; poll++) {
          await waitMs(500);
          if (shouldStop()) break;
          try {
            const stored = await chrome.storage.local.get('futnor_hashtag_target_username');
            const candidate = (stored?.futnor_hashtag_target_username || '').toLowerCase().replace(/^@/, '').trim();
            if (candidate) {
              hashUsername = candidate;
              break;
            }
          } catch {}
        }
        if (shouldStop()) break;

        if (hashUsername) await waitMs(humanDelay(1200));

        if (!hashUsername) {
          addLog('dm_skipped', `⚠️ No new account found on #${tag} — moving to the next post...`);
          await sendActionToTab('returnToHashtagResults', null, [tag]);
          await waitMs(humanDelay(1200));
          continue;
        }

        // Navigate to the profile from background.js
        {
          const navOk = await sendActionToTab('navigateProfile', null, [hashUsername]);
          if (!navOk) {
            const fallbackTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
            if (fallbackTab) {
              await navigateTabAndWait(fallbackTab.id, `https://www.instagram.com/${hashUsername}/`);
            }
          }
          await waitMs(humanDelay(2000));
        }

        // Verify we landed on the profile page
        {
          const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
          const tabUrl = tab?.url || '';
          if (!tabUrl.includes(`/${hashUsername}`)) {
            addLog('scroll', `⚠️ Not on @${hashUsername}'s profile — navigating directly`);
            const fallbackTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
            if (fallbackTab) {
              await navigateTabAndWait(fallbackTab.id, `https://www.instagram.com/${hashUsername}/`);
            }
            await waitMs(humanDelay(2000));
          }
        }

        addLog('scroll', `🎯 On @${hashUsername}'s profile — engaging...`);

        // Check DM limits
        if (sessionState.stats.dmsSent >= config.dailyMaxDMs && config.dailyMaxDMs > 0) {
          addLog('session_end', '✅ DM limit reached');
          sessionState.isRunning = false;
          break;
        }

        // Skip already handled
        if (isAccountAlreadyHandled(hashUsername)) {
          addLog('scroll', `⏭️ @${hashUsername} already processed — returning to #${tag}`);
          await sendActionToTab('returnToHashtagResults', null, [tag]);
          await waitMs(humanDelay(800));
          continue;
        }

        // Mark as processed
        await rememberProcessedAccount(hashUsername);

        try {
          sessionState.stats.scrolls++;

          // Check profile accessibility
          const accessCheck = await sendActionToTab('isProfileAccessible');
          if (shouldSkipForAccess(accessCheck)) {
            addLog('dm_skipped', `⏭️ @${hashUsername} — ${accessCheck.reason === 'private' ? 'private account' : 'not accessible'}`);
            await sendActionToTab('returnToHashtagResults', null, [tag]);
            await waitMs(humanDelay(800));
            continue;
          }

          // Demographics filter
          const demoPass = await checkDemographicsFilter();
          if (!demoPass) {
            addLog('scroll', `↩️ @${hashUsername} — demographics mismatch`);
            await sendActionToTab('returnToHashtagResults', null, [tag]);
            await waitMs(humanDelay(800));
            continue;
          }

          // Browse profile humanly
          const isHumanMode = config.dmMode === 'human';
          if (!shouldStop() && (isHumanMode || Math.random() < 0.6)) {
            addLog('scroll', '👀 Browsing profile...');
            await sendActionToTab('browseProfile');
            await waitMs(humanDelay(isHumanMode ? 1500 : 800));
          }

          if (shouldStop()) break;

          // Like 1-3 posts
          if (!shouldStop() && sessionState.stats.likesSent < config.dailyMaxLikes) {
            try {
              const result = await sendProfileMultiLike();
              if (result.success && result.likesCount > 0) {
                sessionState.stats.likesSent += result.likesCount;
                addLog('like', `❤️ Liked ${result.likesCount} post(s)`);
              }
            } catch (e) {
              const liked = await sendActionToTab('profileLike');
              if (liked) { sessionState.stats.likesSent++; addLog('like', '❤️ Liked a post'); }
            }
            await waitMs(humanDelay(1000));
          }

          // Follow (~15% chance)
          if (!shouldStop() && config.followEnabled && sessionState.stats.followsSent < config.dailyMaxFollows && config.dailyMaxFollows > 0 && Math.random() < 0.15) {
            const followed = await sendActionToTab('profileFollow');
            if (followed) {
              sessionState.stats.followsSent++;
              addLog('follow', '➕ Followed account');
            }
            await waitMs(humanDelay(800));
          }

          // Guard: escape /reels/ if needed
          {
            const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
            if (tab?.url?.includes('/reels/')) {
              addLog('scroll', '⚠️ Escaped /reels/ — recovering profile before DM');
              await sendActionToTab('navigateProfile', null, [hashUsername]);
              await waitMs(humanDelay(1800));
            }
          }

          // Send DM
          if (!shouldStop() && sessionState.stats.dmsSent < config.dailyMaxDMs) {
            const msg = pickMessage();
            if (msg) {
              addLog('dm', `💬 Attempting DM to @${hashUsername}...`);
              // Navigate back to profile in case multiLike left us on /p/ page
              const navBackOk = await sendActionToTab('navigateProfile', null, [hashUsername]);
              if (!navBackOk) {
                const fallbackTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
                if (fallbackTab) {
                  await navigateTabAndWait(fallbackTab.id, `https://www.instagram.com/${hashUsername}/`);
                }
              }
              await waitMs(humanDelay(1500));
              const dmSent = await sendInstagramDirectComposeDM(msg, hashUsername);

              if (dmSent) {
                sessionState.stats.dmsSent++;
                await addToBgDMHistory(hashUsername);
                addLog('dm', `📨 DM sent to @${hashUsername}!`);
                try { await postCommentAfterDM(hashUsername); } catch {}
              } else {
                addLog('dm_skipped', `⏭️ DM could not be sent to @${hashUsername}`);
              }
              await waitMs(humanDelay(1200));
            } else {
              addLog('dm_skipped', '⚠️ No DM script configured');
            }
          }

          // Mark visited in content script
          await sendActionToTab('markVisited', null, [hashUsername]);

          // Return to hashtag results while preserving current position when possible
          addLog('scroll', `↩️ Returning to #${tag} results...`);
          await sendActionToTab('returnToHashtagResults', null, [tag]);
          await waitMs(humanDelay(1500));

          // Pause between accounts
          await waitMs(getRandom(2000, 4000));

          const delay2 = getRandomDelay(config);
          elapsed += delay2 / 1000;
          sessionState.stats.elapsedTime = Math.round(elapsed);
          saveState();
        } catch (e) {
          console.error(`[Futnor Background] Error processing hashtag user @${hashUsername}:`, e);
          addLog('dm_skipped', `⚠️ Error while processing @${hashUsername} — moving on`);
          try { await sendActionToTab('markVisited', null, [hashUsername]); } catch {}
          try { await sendActionToTab('returnToHashtagResults', null, [tag]); } catch {}
          await waitMs(humanDelay(800));
        }

        performed = true;
        
      } else if (hasTargeting && targetType === 'commenters' && targeting.targetPostLink?.trim()) {
        // ═══ COMMENTER NETWORK FLOW ═══
        // Recursive: extract commenters from target post → DM each → then visit each commenter's
        // recent post → extract THEIR commenters → DM those → continue expanding the network
        
        const commenterNetworkQueue = []; // Array of { postUrl, depth, sourceCommenter }
        commenterNetworkQueue.push({ postUrl: targeting.targetPostLink.trim(), depth: 0, sourceCommenter: 'original' });
        
        // Track commenters we've already queued to avoid infinite loops
        const queuedCommenters = new Set();
        // Track commenters processed in this session loop (prevents duplicate profile visits)
        const processedCommenters = new Set();
        // Track original post commenters for network expansion
        const originalPostCommenters = [];
        let originalCommenterIndex = 0;
        
        addLog('scroll', `🕸️ Starting commenter network from target post`);
        
        while (commenterNetworkQueue.length > 0 && sessionState.isRunning && elapsed < sessionTime) {
          // Check limits
          const s2 = sessionState.stats;
          const hitLimits = (s2.dmsSent >= config.dailyMaxDMs || config.dailyMaxDMs === 0);
          if (hitLimits) {
            addLog('session_end', '✅ DM limit reached — session complete');
            sessionState.isRunning = false;
            break;
          }
          
          const current = commenterNetworkQueue.shift();
          const depthLabel = current.depth === 0 ? '📌 Original post' : `🔗 Depth ${current.depth} (from @${current.sourceCommenter})`;
          addLog('scroll', `${depthLabel} — navigating to post...`);
          
          // Step 1a: Navigate to the post directly from background (avoids content script reload issues)
          let postUrl = current.postUrl;
          if (!postUrl.startsWith('http')) {
            postUrl = `https://www.instagram.com/p/${postUrl}/`;
          }
          if (!postUrl.includes('instagram.com')) {
            postUrl = `https://www.instagram.com${postUrl.startsWith('/') ? '' : '/p/'}${postUrl}`;
          }
          
          // Navigate the tab directly and wait for it to load
          const postTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
          if (!postTab) {
            addLog('dm_skipped', `⏭️ No Instagram tab found`);
            continue;
          }
          
          const tabId = postTab.id;
          await new Promise((resolve) => {
            chrome.tabs.update(tabId, { url: postUrl }, () => {
              // Wait for the tab to finish loading
              const listener = (updatedTabId, changeInfo) => {
                if (updatedTabId === tabId && changeInfo.status === 'complete') {
                  chrome.tabs.onUpdated.removeListener(listener);
                  resolve();
                }
              };
              chrome.tabs.onUpdated.addListener(listener);
              // Timeout fallback
              setTimeout(() => {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
              }, 8000);
            });
          });
          
          // Wait for content script to re-initialize after page load
          await waitMs(humanDelay(3000));
          
          // Ping content script to make sure it's ready
          let contentReady = false;
          for (let attempt = 0; attempt < 5; attempt++) {
            try {
              const pingResult = await new Promise((resolve, reject) => {
                chrome.tabs.sendMessage(tabId, { type: 'PING' }, (resp) => {
                  if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                  else resolve(resp);
                });
              });
              if (pingResult && pingResult.ready) {
                contentReady = true;
                break;
              }
            } catch (e) {
              await waitMs(1000);
            }
          }
          
          if (!contentReady) {
            addLog('dm_skipped', `⏭️ Content script not ready on post page`);
            continue;
          }
          
          // Step 1b: Now extract commenters from the loaded page (no navigation)
          addLog('scroll', `${depthLabel} — scrolling comments & extracting usernames...`);
          const extractResult = await sendActionToTab('extractCommenters');
          let commenters = [];
          if (extractResult && extractResult.commenters) {
            commenters = extractResult.commenters;
          } else if (extractResult && Array.isArray(extractResult)) {
            commenters = extractResult;
          }
          
          if (commenters.length === 0) {
            addLog('dm_skipped', `⏭️ No commenters found on post — ${current.depth === 0 ? 'check post link' : 'skipping'}`);
            await waitMs(humanDelay(1000));
            
            // If this was from the network expansion, continue to next queued item
            continue;
          }
          
          addLog('scroll', `👥 Found ${commenters.length} commenters to process`);
          
          // Store commenters for network expansion later
          // Include ALL commenters (even already-handled ones) because they can
          // still serve as expansion sources — we visit their posts to find NEW
          // commenters, we don't re-DM them.
          for (const c of commenters) {
            const normalizedCommenter = normalizeInstagramUsername(c);
            if (!normalizedCommenter) continue;
            if (!queuedCommenters.has(normalizedCommenter)) {
              originalPostCommenters.push(normalizedCommenter);
              queuedCommenters.add(normalizedCommenter);
            }
          }
          
          // Step 2: Process each commenter — navigate to profile, filter, browse, DM
          for (let ci = 0; ci < commenters.length && sessionState.isRunning && elapsed < sessionTime; ci++) {
            const commenterUsername = (commenters[ci] || '').toLowerCase().replace(/^@/, '').trim();

            if (!commenterUsername) continue;

            // Check DM limits
            if (sessionState.stats.dmsSent >= config.dailyMaxDMs) {
              addLog('session_end', '✅ DM limit reached');
              sessionState.isRunning = false;
              break;
            }

            // Skip duplicates in the current processing loop
            if (processedCommenters.has(commenterUsername)) {
              continue;
            }
            processedCommenters.add(commenterUsername);

            // Skip ONLY accounts that have actually been DM'd (dm_history).
            // Do NOT skip accounts that are merely in processed_accounts_history
            // but not in dm_history — those may have been wrongly marked due to
            // past timing/web-worker bugs and deserve another attempt.
            const _normCommenter = normalizeInstagramUsername(commenterUsername);
            if (_normCommenter && isInBgDMHistory(_normCommenter)) {
              addLog('scroll', `⏭️ @${commenterUsername} already DM'd — skipping`);
              continue;
            }

            // NOTE: Do NOT mark as processed yet — only mark after a definitive outcome
            // (private/inaccessible, filter mismatch, OR DM sent). This way, if the DM step
            // fails due to a transient issue (timing, popup, etc.), the account stays
            // available to be retried in a future session.

            try {
              addLog('scroll', `🎯 [${ci + 1}/${commenters.length}] Visiting @${commenterUsername}...`);

              // Navigate to commenter's profile
              const navOk = await sendActionToTab('navigateProfile', null, [commenterUsername]);
              if (!navOk) {
                addLog('dm_skipped', `⏭️ Could not navigate to @${commenterUsername} — will retry next session`);
                await waitMs(humanDelay(800));
                continue;
              }
              await waitMs(humanDelay(1500));
              sessionState.stats.scrolls++;

              // Check profile accessibility (private, restricted, etc.)
              // These are definitive rejections — mark as processed so we don't waste time revisiting.
              const accessCheck = await sendActionToTab('isProfileAccessible');
              if (shouldSkipForAccess(accessCheck)) {
                addLog('dm_skipped', `⏭️ @${commenterUsername} — ${accessCheck.reason === 'private' ? 'private account' : 'not accessible'}`);
                await rememberProcessedAccount(commenterUsername);
                await waitMs(humanDelay(800));
                continue;
              }

              // Demographics / follower / post count filter — definitive rejection
              const demoPass = await checkDemographicsFilter();
              if (!demoPass) {
                addLog('scroll', `↩️ @${commenterUsername} — demographics mismatch`);
                await rememberProcessedAccount(commenterUsername);
                await waitMs(humanDelay(800));
                continue;
              }

              // Browse profile humanly (human mode or 60% chance)
              const isHumanMode = config.dmMode === 'human';
              if (!shouldStop() && (isHumanMode || Math.random() < 0.6)) {
                addLog('scroll', '👀 Browsing profile...');
                await sendActionToTab('browseProfile');
                await waitMs(humanDelay(isHumanMode ? 1500 : 800));
              }

              if (shouldStop()) break;

              // Like 1-3 posts
              if (!shouldStop() && sessionState.stats.likesSent < config.dailyMaxLikes) {
                try {
                  const result = await sendProfileMultiLike();
                  if (result.success && result.likesCount > 0) {
                    sessionState.stats.likesSent += result.likesCount;
                    addLog('like', `❤️ Liked ${result.likesCount} post(s)`);
                  }
                } catch (e) {
                  const liked = await sendActionToTab('profileLike');
                  if (liked) { sessionState.stats.likesSent++; addLog('like', '❤️ Liked a post'); }
                }
                await waitMs(humanDelay(1000));
              }

              // Follow (~15% chance)
              if (!shouldStop() && config.followEnabled && sessionState.stats.followsSent < config.dailyMaxFollows && config.dailyMaxFollows > 0 && Math.random() < 0.15) {
                const followed = await sendActionToTab('profileFollow');
                if (followed) {
                  sessionState.stats.followsSent++;
                  addLog('follow', '➕ Followed account');
                }
                await waitMs(humanDelay(800));
              }

              // Send DM
              let dmOutcome = 'no_attempt'; // 'sent' | 'failed' | 'no_script' | 'no_attempt'
              if (!shouldStop() && sessionState.stats.dmsSent < config.dailyMaxDMs) {
                const msg = pickMessage();
                if (msg) {
                  addLog('dm', `💬 Attempting DM to @${commenterUsername}...`);
                  // Navigate back to profile in case multiLike left us on /p/ page
                  const navBackOk = await sendActionToTab('navigateProfile', null, [commenterUsername]);
                  if (!navBackOk) {
                    // Fallback: direct URL navigation via tab
                    addLog('dm', `🔄 Profile nav failed, trying direct URL for @${commenterUsername}...`);
                    const fallbackTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
                    if (fallbackTab) {
                      await navigateTabAndWait(fallbackTab.id, `https://www.instagram.com/${commenterUsername}/`);
                    }
                  }
                  await waitMs(humanDelay(1500));
                  const dmSent = await sendInstagramDirectComposeDM(msg, commenterUsername);

                  if (dmSent) {
                    dmOutcome = 'sent';
                    sessionState.stats.dmsSent++;
                    await addToBgDMHistory(commenterUsername);
                    addLog('dm', `📨 DM sent to @${commenterUsername}!`);
                    try { await postCommentAfterDM(commenterUsername); } catch {}
                  } else {
                    dmOutcome = 'failed';
                    addLog('dm_skipped', `⏭️ DM could not be sent to @${commenterUsername} — will retry next session`);
                  }
                  await waitMs(humanDelay(1200));
                } else {
                  dmOutcome = 'no_script';
                  addLog('dm_skipped', '⚠️ No DM script configured');
                }
              }

              // Only mark as processed/visited when the DM actually went through.
              // Failed DMs (timing issues, popups, transient errors) stay eligible
              // for retry in a future session — we already liked/browsed, so the next
              // attempt picks up where this one left off.
              if (dmOutcome === 'sent') {
                await rememberProcessedAccount(commenterUsername);
                await sendActionToTab('markVisited', null, [commenterUsername]);
              }

              // Navigate back to the post page before processing next commenter
              // (we may be on /direct/ after DM or on a profile page)
              const navTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
              if (navTab) {
                const currentUrl = navTab.url || '';
                if (currentUrl.includes('/direct/') || !currentUrl.includes('/p/')) {
                  // We'll navigate to the next commenter directly in the next iteration
                }
              }

              // Pause between accounts (human-like)
              await waitMs(getRandom(2000, 4000));

              const delay2 = getRandomDelay(config);
              elapsed += delay2 / 1000;
              sessionState.stats.elapsedTime = Math.round(elapsed);
              saveState();
            } catch (e) {
              console.error(`[Futnor Background] Error processing commenter @${commenterUsername}:`, e);
              addLog('dm_skipped', `⚠️ Error while processing @${commenterUsername} — will retry next session`);
              // Do NOT mark as visited/processed on transient errors — let the next session retry.
              await waitMs(humanDelay(800));
            }
          }
          
          // Step 3: After processing all commenters from current post,
          // expand the network — only if commenterNetworkLoop is enabled
          const networkLoopEnabled = targeting.commenterNetworkLoop !== false; // default true for backward compat
          
          if (networkLoopEnabled && sessionState.isRunning && elapsed < sessionTime && sessionState.stats.dmsSent < config.dailyMaxDMs) {
            // Find the next commenter who hasn't been fully handled yet for network expansion.
            // We must loop here instead of using `continue` (which would jump to the outer while
            // and exit immediately when the queue is empty).
            let expanded = false;
            while (originalCommenterIndex < originalPostCommenters.length) {
              const nextCommenter = originalPostCommenters[originalCommenterIndex];
              originalCommenterIndex++;

              if (!nextCommenter) continue;

              // For network expansion we only need their post — it's fine if we already DM'd them.
              // We skip only if we already tried expanding via this commenter before.
              
              addLog('scroll', `🕸️ Expanding network via @${nextCommenter}...`);
              
              // Navigate to commenter's profile
              const navOk = await sendActionToTab('navigateProfile', null, [nextCommenter]);
              if (!navOk) {
                addLog('dm_skipped', `⏭️ Could not navigate to @${nextCommenter} for network expansion`);
                await waitMs(humanDelay(500));
                continue; // try next commenter in originalPostCommenters
              }
              await waitMs(humanDelay(1500));
              
              // Check if profile is accessible
              const accessCheck = await sendActionToTab('isProfileAccessible');
              if (accessCheck && (!accessCheck.accessible || accessCheck.reason === 'no_posts')) {
                addLog('dm_skipped', `⏭️ @${nextCommenter} — ${accessCheck.accessible ? 'no posts' : 'not accessible'}, skipping expansion`);
                await waitMs(humanDelay(500));
                continue; // try next commenter in originalPostCommenters
              }
              
              // Get their recent post
              const postResult = await sendActionToTab('getRecentPostLink');
              if (postResult && postResult.postLink) {
                addLog('scroll', `🔗 Found @${nextCommenter}'s recent post — queuing commenters`);
                commenterNetworkQueue.push({
                  postUrl: postResult.postLink,
                  depth: current.depth + 1,
                  sourceCommenter: nextCommenter,
                });
                expanded = true;
                await waitMs(humanDelay(1500));
                break; // successfully queued — go back to outer while to process this new post
              } else {
                addLog('dm_skipped', `⏭️ @${nextCommenter} has no accessible posts`);
                await waitMs(humanDelay(500));
                continue; // try next commenter
              }
            }
            
            if (!expanded) {
              addLog('scroll', '🕸️ All commenter networks exhausted');
              break;
            }
          } else if (!networkLoopEnabled) {
            // Network loop disabled — just process the original post commenters and stop
            addLog('scroll', '✅ Commenters from target post processed (network loop disabled)');
            break;
          }
        }
        
        performed = true;
        // Skip the generic engagement below — commenters flow handles everything
        
      } else if (hasTargeting && targetType === 'location' && targeting.location?.trim()) {
        // ═══ LOCATION FLOW (ONE-AT-A-TIME): navigate → pick post → profile → engage → DM → back ═══
        // No batch collection — opens one post at a time, extracts username, engages, DMs,
        // then uses history.back() to return to the location grid (preserving posts & scroll).
        const locationUrl = targeting.location.trim();

        // Step 1: Navigate to location page (only if not already there)
        const onLocationPage = await sendActionToTab('navigateLocation', null, [locationUrl]);
        if (!onLocationPage) {
          sessionState.stats.scrolls++;
          addLog('scroll', `⚠️ Could not load location page, retrying...`);
          await waitMs(humanDelay(2000));
          await sendActionToTab('scroll');
          continue;
        }
        addLog('scroll', `📍 On location page — engaging posts one by one`);
        sessionState.stats.scrolls++;
        await waitMs(humanDelay(2000));

        // Drift guard
        {
          const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
          if (tab?.url?.includes('/reels/') || tab?.url?.includes('/direct/')) {
            addLog('scroll', '⚠️ Drifted off location results — restoring');
            await sendActionToTab('navigateLocation', null, [locationUrl]);
            await waitMs(humanDelay(1800));
            continue;
          }
        }

        // Step 2: Open next post → find poster → navigate to their profile.
        // The content script stores the username in chrome.storage BEFORE
        // navigating away (navigation kills sendResponse, so we can't use it).
        // We clear storage first, then fire a TRUE fire-and-forget message
        // (no retries, no reconnect) and poll storage until we see the username.
        await chrome.storage.local.set({ futnor_location_target_username: '' });

        // TRUE fire-and-forget: send directly via chrome.tabs.sendMessage with NO
        // await on the response — we intentionally ignore the error when navigation
        // kills the message channel. Using sendActionToTab would trigger reconnect
        // logic which disrupts the session while the content script is mid-execution.
        {
          const fireTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
          if (fireTab) {
            chrome.tabs.sendMessage(fireTab.id, {
              type: 'PERFORM_ACTION',
              action: 'engageNextLocationPost',
            }).catch(() => {/* expected — navigation kills channel */});
          }
        }

        // Poll chrome.storage every 500ms for up to 20s waiting for the username.
        // The content script awaits the storage write BEFORE it navigates, so
        // as soon as we see a non-empty value the profile navigation has begun.
        let locUsername = null;
        for (let poll = 0; poll < 40; poll++) {
          await waitMs(500);
          if (shouldStop()) break;
          try {
            const stored = await chrome.storage.local.get('futnor_location_target_username');
            const candidate = (stored?.futnor_location_target_username || '').toLowerCase().replace(/^@/, '').trim();
            if (candidate) {
              locUsername = candidate;
              break;
            }
          } catch {}
        }
        if (shouldStop()) break;

        // Give extra time for the tab to finish navigating to the profile
        if (locUsername) await waitMs(humanDelay(2000));

        if (!locUsername) {
          addLog('dm_skipped', '⚠️ No new account found at location — scrolling and retrying...');
          // We might be on the location page or somewhere else — try returning
          try { await sendActionToTab('returnToLocationGrid'); } catch {}
          await sendActionToTab('scrollLocationResults');
          await waitMs(humanDelay(2000));
          continue;
        }

        // Verify we actually landed on the profile page
        {
          const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
          const tabUrl = tab?.url || '';
          if (!tabUrl.includes(`/${locUsername}`) && !tabUrl.includes('/direct/')) {
            // Not on the expected profile — try navigating directly
            addLog('scroll', `⚠️ Not on @${locUsername}'s profile — navigating directly`);
            const navOk = await sendActionToTab('navigateProfile', null, [locUsername]);
            if (!navOk) {
              const fallbackTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
              if (fallbackTab) {
                await navigateTabAndWait(fallbackTab.id, `https://www.instagram.com/${locUsername}/`);
              }
            }
            await waitMs(humanDelay(2000));
          }
        }

        addLog('scroll', `🎯 On @${locUsername}'s profile — engaging...`);

        // Check DM limits
        if (sessionState.stats.dmsSent >= config.dailyMaxDMs && config.dailyMaxDMs > 0) {
          addLog('session_end', '✅ DM limit reached');
          sessionState.isRunning = false;
          break;
        }

        // Skip already handled in persistent history
        if (isAccountAlreadyHandled(locUsername)) {
          addLog('scroll', `⏭️ @${locUsername} already processed — returning to location grid`);
          await sendActionToTab('returnToLocationGrid');
          await waitMs(humanDelay(800));
          continue;
        }

        // Mark as processed immediately
        await rememberProcessedAccount(locUsername);

        try {
          sessionState.stats.scrolls++;

          // Check profile accessibility
          const accessCheck = await sendActionToTab('isProfileAccessible');
          if (shouldSkipForAccess(accessCheck)) {
            addLog('dm_skipped', `⏭️ @${locUsername} — ${accessCheck.reason === 'private' ? 'private account' : 'not accessible'}`);
            // Return to location grid via history.back()
            await sendActionToTab('returnToLocationGrid');
            await waitMs(humanDelay(800));
            continue;
          }

          // Demographics filter
          const demoPassLoc = await checkDemographicsFilter();
          if (!demoPassLoc) {
            addLog('scroll', `↩️ @${locUsername} — demographics mismatch`);
            await sendActionToTab('returnToLocationGrid');
            await waitMs(humanDelay(800));
            continue;
          }

          // Browse profile humanly
          const isHumanModeLoc = config.dmMode === 'human';
          if (!shouldStop() && (isHumanModeLoc || Math.random() < 0.6)) {
            addLog('scroll', '👀 Browsing profile...');
            await sendActionToTab('browseProfile');
            await waitMs(humanDelay(isHumanModeLoc ? 1500 : 800));
          }

          if (shouldStop()) break;

          // Like 1-3 posts
          if (!shouldStop() && sessionState.stats.likesSent < config.dailyMaxLikes) {
            try {
              const result = await sendProfileMultiLike();
              if (result.success && result.likesCount > 0) {
                sessionState.stats.likesSent += result.likesCount;
                addLog('like', `❤️ Liked ${result.likesCount} post(s)`);
              }
            } catch (e) {
              const liked = await sendActionToTab('profileLike');
              if (liked) { sessionState.stats.likesSent++; addLog('like', '❤️ Liked a post'); }
            }
            await waitMs(humanDelay(1000));
          }

          // Follow (~15% chance)
          if (!shouldStop() && config.followEnabled && sessionState.stats.followsSent < config.dailyMaxFollows && config.dailyMaxFollows > 0 && Math.random() < 0.15) {
            const followed = await sendActionToTab('profileFollow');
            if (followed) {
              sessionState.stats.followsSent++;
              addLog('follow', '➕ Followed account');
            }
            await waitMs(humanDelay(800));
          }

          // Guard: escape /reels/ if needed
          {
            const tab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
            if (tab?.url?.includes('/reels/')) {
              addLog('scroll', '⚠️ Escaped /reels/ — recovering profile before DM');
              await sendActionToTab('navigateProfile', null, [locUsername]);
              await waitMs(humanDelay(1800));
            }
          }

          // Send DM
          if (!shouldStop() && sessionState.stats.dmsSent < config.dailyMaxDMs) {
            const msg = pickMessage();
            if (msg) {
              addLog('dm', `💬 Attempting DM to @${locUsername}...`);
              // Navigate back to profile in case multiLike left us on /p/ page
              const navBackOk = await sendActionToTab('navigateProfile', null, [locUsername]);
              if (!navBackOk) {
                const fallbackTab = await getOrCreatePlatformTab(sessionState.platform, { createIfMissing: false });
                if (fallbackTab) {
                  await navigateTabAndWait(fallbackTab.id, `https://www.instagram.com/${locUsername}/`);
                }
              }
              await waitMs(humanDelay(1500));
              const dmSent = await sendInstagramDirectComposeDM(msg, locUsername);

              if (dmSent) {
                sessionState.stats.dmsSent++;
                await addToBgDMHistory(locUsername);
                addLog('dm', `📨 DM sent to @${locUsername}!`);
                try { await postCommentAfterDM(locUsername); } catch {}
              } else {
                addLog('dm_skipped', `⏭️ DM could not be sent to @${locUsername}`);
              }
              await waitMs(humanDelay(1200));
            } else {
              addLog('dm_skipped', '⚠️ No DM script configured');
            }
          }

          // Mark visited in content script
          await sendActionToTab('markVisited', null, [locUsername]);

          // Step 3: Navigate directly to location page.
          // We do NOT use returnToLocationGrid (history.back()) here because
          // performProfileMultiLike clicks post thumbnails which pushes each
          // /p/xxx/ URL into browser history. history.back() would traverse
          // back through every one of those post pages one-by-one, making the
          // bot appear to re-engage with the just-DMed account's posts.
          // Direct navigation skips all that and lands cleanly on the location grid.
          addLog('scroll', `↩️ Returning to location grid...`);
          await sendActionToTab('navigateLocation', null, [locationUrl]);
          await waitMs(humanDelay(1500));

          // Pause between accounts (human-like)
          await waitMs(getRandom(2000, 4000));

          const delay2 = getRandomDelay(config);
          elapsed += delay2 / 1000;
          sessionState.stats.elapsedTime = Math.round(elapsed);
          saveState();
        } catch (e) {
          console.error(`[Futnor Background] Error processing location user @${locUsername}:`, e);
          addLog('dm_skipped', `⚠️ Error while processing @${locUsername} — moving on`);
          try { await sendActionToTab('markVisited', null, [locUsername]); } catch {}
          // Navigate directly to location grid on error (avoid history.back() traversal)
          try { await sendActionToTab('navigateLocation', null, [locationUrl]); } catch {}
          await waitMs(humanDelay(800));
        }

        performed = true;

      } else if (hasTargeting) {
        // ═══ OTHER TARGETING TYPES (custom, likers) ═══
        let onTargetPage = false;
        
        if (targetType === 'likers' && targeting.targetPostLink?.trim()) {
          onTargetPage = await sendActionToTab('navigatePost', null, [targeting.targetPostLink, 'likers']);
          if (onTargetPage) addLog('scroll', `👀 Browsing likers of post`);
        } else if (targetType === 'custom' && targeting.customUsernames?.length > 0) {
          const normalizedCustomUsers = targeting.customUsernames
            .map((entry) => normalizeInstagramUsername(entry))
            .filter(Boolean);

          let selectedCustomUser = null;
          for (let offset = 0; offset < normalizedCustomUsers.length; offset++) {
            const idx = (customTargetCursor + offset) % normalizedCustomUsers.length;
            const candidate = normalizedCustomUsers[idx];
            if (isAccountAlreadyHandled(candidate)) continue;
            selectedCustomUser = candidate;
            customTargetCursor = idx + 1;
            break;
          }

          if (!selectedCustomUser) {
            addLog('session_end', '✅ All custom usernames already processed — session complete');
            sessionState.isRunning = false;
            break;
          }

          onTargetPage = await sendActionToTab('navigateProfile', null, [selectedCustomUser]);
          if (onTargetPage) {
            await waitMs(humanDelay(1000));
            // Check if the profile actually exists / is accessible
            const accessCheck = await sendActionToTab('isProfileAccessible');
            if (shouldSkipForAccess(accessCheck)) {
              addLog('dm_skipped', `⏭️ @${selectedCustomUser} — ${accessCheck.reason === 'not_found' ? 'account not found' : accessCheck.reason === 'private' ? 'private account' : 'not accessible'}, skipping`);
              await rememberProcessedAccount(selectedCustomUser);
              await waitMs(humanDelay(500));
              continue;
            }
            addLog('scroll', `🎯 Visiting @${selectedCustomUser}'s profile`);
          }
        }
        
        if (!onTargetPage) {
          sessionState.stats.scrolls++;
          await sendActionToTab('scroll');
          continue;
        }
        
        await waitMs(humanDelay(1000));
        sessionState.stats.scrolls++;
        
        // For non-custom: pick account from list
        if (targetType !== 'custom') {
          await sendActionToTab('scroll');
          await waitMs(humanDelay(800));
          
          const visited = await sendActionToTab('engageSimilar');
          if (!visited) {
            addLog('dm_skipped', '⚠️ No accounts found, scrolling more...');
            await sendActionToTab('scroll');
            continue;
          }
          addLog('scroll', '🎯 Visiting targeted account profile');
          await waitMs(humanDelay(1200));
        }
        
        const currentTargetUsername = normalizeInstagramUsername(await getCurrentInstagramProfileUsername());
        if (currentTargetUsername && isAccountAlreadyHandled(currentTargetUsername)) {
          addLog('scroll', `⏭️ @${currentTargetUsername} already processed — skipping`);
          await waitMs(humanDelay(800));
          continue;
        }

        if (currentTargetUsername) {
          await rememberProcessedAccount(currentTargetUsername);
        }

        // Demographics filter check
        const demoPass3 = await checkDemographicsFilter();
        if (!demoPass3) {
          addLog('scroll', '↩️ Skipping — demographics mismatch');
          await waitMs(humanDelay(800));
          continue;
        }
        
        // Like 1-3 posts
        if (!shouldStop() && sessionState.stats.likesSent < config.dailyMaxLikes) {
          try {
            const result = await sendProfileMultiLike();
            if (result.success && result.likesCount > 0) {
              sessionState.stats.likesSent += result.likesCount;
              addLog('like', `❤️ Liked ${result.likesCount} post(s)`);
            }
          } catch (e) {
            const liked = await sendActionToTab('profileLike');
            if (liked) { sessionState.stats.likesSent++; addLog('like', '❤️ Liked a post'); }
          }
          await waitMs(humanDelay(1000));
        }
        
        // Follow
        if (!shouldStop() && config.followEnabled && sessionState.stats.followsSent < config.dailyMaxFollows && config.dailyMaxFollows > 0 && Math.random() < 0.15) {
          const followed = await sendActionToTab('profileFollow');
          if (followed) {
            sessionState.stats.followsSent++;
            addLog('follow', '➕ Followed account');
          }
          await waitMs(humanDelay(800));
        }
        
        // DM
        if (!shouldStop() && sessionState.stats.dmsSent < config.dailyMaxDMs) {
          const msg = pickMessage();
          if (msg) {
            const dmTargetUsername = currentTargetUsername || normalizeInstagramUsername(await getCurrentInstagramProfileUsername());
            // Navigate back to profile in case multiLike left us on /p/ page
            if (dmTargetUsername) {
              await sendActionToTab('navigateProfile', null, [dmTargetUsername]);
              await waitMs(humanDelay(800));
            }
            const dmSent = dmTargetUsername
              ? await sendInstagramDirectComposeDM(msg, dmTargetUsername)
              : false;
            if (dmSent) {
              sessionState.stats.dmsSent++;
              if (dmTargetUsername) await addToBgDMHistory(dmTargetUsername);
              addLog('dm', '📨 DM sent to targeted account');
              if (dmTargetUsername) { try { await postCommentAfterDM(dmTargetUsername); } catch {} }
            } else {
              addLog('dm_skipped', '⏭️ DM could not be sent — moving on');
            }
            await waitMs(humanDelay(1200));
          }
        }
        
        await waitMs(getRandom(1500, 3500));
        performed = true;
        
      } else {
        // Non-targeted session: use original random action flow
        const action = pickNextAction(config, platform);
        
        switch (action) {
          case 'scroll': {
            performed = await sendActionToTab('scroll');
            if (performed) {
              sessionState.stats.scrolls++;
              addLog('scroll', 'Scrolled / viewed content');
            }
            break;
          }
          case 'likeFollow': {
            const followAllowed = config.followEnabled && config.dailyMaxFollows > 0;
            if (sessionState.stats.likesSent >= config.dailyMaxLikes &&
                (!followAllowed || sessionState.stats.followsSent >= config.dailyMaxFollows)) break;

            if (Math.random() < 0.5 && sessionState.stats.likesSent < config.dailyMaxLikes) {
              performed = await sendActionToTab('like');
              if (performed) {
                sessionState.stats.likesSent++;
                addLog('like', 'Liked a post');
              }
            } else if (followAllowed && sessionState.stats.followsSent < config.dailyMaxFollows) {
              performed = await sendActionToTab('follow');
              if (performed) {
                sessionState.stats.followsSent++;
                addLog('follow', 'Followed a user');
              }
            }
            break;
          }
          case 'comment':
            if (sessionState.stats.dmsSent >= config.dailyMaxDMs) break;
            
            // Retry comment action to handle multi-step flows
            let commentSuccess = false;
            for (let attempt = 1; attempt <= 3 && !commentSuccess; attempt++) {
              performed = await sendActionToTab('comment', pickMessage());
              if (performed) {
                commentSuccess = true;
                sessionState.stats.dmsSent++;
                addLog('dm', '💬 Comment posted on TikTok');
              } else if (attempt < 3) {
                await waitMs(2000);
              }
            }
            
            if (!commentSuccess) {
              addLog('dm_skipped', '⚠️ Comment failed after 3 attempts');
            }
            break;
          case 'dm': {
            if (sessionState.stats.dmsSent >= config.dailyMaxDMs) break;
            const msg = pickMessage();
            if (!msg) {
              addLog('dm_skipped', '⚠️ No DM script configured');
              break;
            }
            
            if (platform === 'instagram') {
              const dmTargetUsername = await waitForInstagramProfileUsername({ attempts: 6, delayMs: 350 });
              performed = dmTargetUsername
                ? await sendInstagramDirectComposeDM(msg, dmTargetUsername)
                : false;
            } else {
              performed = await sendActionToTab('dm', msg);
            }
            if (performed) {
              sessionState.stats.dmsSent++;
              addLog('dm', '📨 DM sent');
            } else {
              addLog('dm_skipped', '⚠️ DM skipped or failed');
            }
            break;
          }
        }
      }
    }

    const delay = getRandomDelay(config);
    await waitMs(delay);
    elapsed += delay / 1000;
    sessionState.stats.elapsedTime = Math.round(elapsed);
    saveState();
  }

  chrome.alarms.clear(tickAlarm);
  sessionState.isRunning = false;
  sessionState.reconnecting = false;
  sessionLoopActive = false;
  sessionLoopPromise = null;
  addLog('session_end', `[${platformLabel}]${modeLabel} Session complete. DMs=${sessionState.stats.dmsSent}, Likes=${sessionState.stats.likesSent}, Follows=${sessionState.stats.followsSent}${isAITargeting ? ', Accounts=' + accountsEngaged : ''}`);
  saveState();

  // Hide banner when session ends
  await hideBannerOnPlatformTab(platform);
}

// ─── Banner helpers ───
async function showBannerOnPlatformTab(platform, mode) {
  try {
    const tab = await getOrCreatePlatformTab(platform, { createIfMissing: false });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { type: 'SHOW_BOT_BANNER', mode: mode || 'bot' }).catch(() => {});
    }
  } catch (e) {
    console.warn('[Futnor Background] showBannerOnPlatformTab failed:', e?.message || e);
  }
}

async function hideBannerOnPlatformTab(platform) {
  try {
    const tab = await getOrCreatePlatformTab(platform, { createIfMissing: false });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { type: 'HIDE_BOT_BANNER' }).catch(() => {});
    }
  } catch (e) {
    console.warn('[Futnor Background] hideBannerOnPlatformTab failed:', e?.message || e);
  }
}

// ─── Warm-up action sender (bypasses bot session checks) ───
function getWarmupActionTimeoutMs(action) {
  // Timeouts sized ~2x the realistic max execution time of each handler —
  // tight enough that a stalled tab recovers quickly (keeps the session feeling
  // smooth), loose enough to absorb slow Instagram renders.
  switch (action) {
    case 'warmupFeed':
      return 120000;
    case 'warmupExplore':
      return 120000;
    case 'warmupStory':
      return 150000;
    case 'warmupReadComments':
      return 60000;
    case 'warmupLike':
      return 30000;
    case 'warmupComment':
      return 45000;
    default:
      return 90000;
  }
}

async function sendWarmupActionToTab(action, platform) {
  if (!warmupState.isRunning) return { success: false, aborted: true };

  const payload = { type: 'PERFORM_ACTION', action };
  const timeoutMs = getWarmupActionTimeoutMs(action);

  for (let attempt = 1; attempt <= 2; attempt++) {
    const targetTab = await getOrCreatePlatformTab(platform, { createIfMissing: false });
    if (!targetTab) {
      console.error('[Futnor Warmup] No platform tab found for warmup action:', action);
      return { success: false, missingTab: true };
    }

    let timeoutId = null;

    try {
      console.log(`[Futnor Warmup] Sending action (attempt ${attempt}/2):`, action);
      const response = await new Promise((resolve, reject) => {
        timeoutId = setTimeout(() => {
          reject(new Error(`Warm-up action timed out after ${timeoutMs}ms`));
        }, timeoutMs);

        chrome.tabs.sendMessage(targetTab.id, payload)
          .then(resolve)
          .catch(reject);
      });

      console.log('[Futnor Warmup] Response:', response);

      if (response && typeof response === 'object' && response.needsTabNavigation) {
        console.log('[Futnor Warmup] Tab navigation requested:', response.url);
        await navigateTabAndWait(targetTab.id, response.url);
        return { success: true };
      }

      if (response && typeof response === 'object') {
        return {
          success: !!response.success,
          label: response.label,
          stalled: !!response.stalled,
        };
      }

      return { success: !!response };
    } catch (e) {
      const errorMessage = e?.message || String(e);
      const timedOut = /timed out/i.test(errorMessage);
      console.error(`[Futnor Warmup] Attempt ${attempt} failed:`, errorMessage);

      if (timedOut) {
        return { success: false, timedOut: true, error: errorMessage };
      }

      if (attempt < 2) {
        await ensureContentScript(targetTab.id, platform);
      }
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  }

  return { success: false };
}

// ─── Warm-up engine ───
let warmupState = { isRunning: false, stats: {}, logs: [] };

// Helper: chunked sleep that keeps service worker alive and checks for stop
async function warmupChunkedSleep(ms) {
  const chunkMs = 400;
  let remaining = ms;
  while (remaining > 0 && warmupState.isRunning) {
    await waitMs(Math.min(chunkMs, remaining));
    remaining -= chunkMs;
  }
}

// Persist warmup state to chrome.storage.session for service worker restart recovery
async function persistWarmupSession(data) {
  try { await chrome.storage.session.set({ _warmupPersist: data }); } catch (e) {}
}
async function clearWarmupPersistence() {
  try { await chrome.storage.session.remove('_warmupPersist'); } catch (e) {}
}

const WARMUP_ACTIONS = [
  { action: 'warmup_scroll_feed', weight: 30, label: '📜 Scrolling feed' },
  { action: 'warmup_scroll_explore', weight: 25, label: '🔍 Browsing explore' },
  { action: 'warmup_view_story', weight: 12, label: '👁️ Viewing stories' },
  { action: 'warmup_like_post', weight: 12, label: '❤️ Liked a post' },
  { action: 'warmup_pause', weight: 8, label: '⏸️ Taking a break...' },
  { action: 'warmup_read_comments', weight: 8, label: '💬 Reading comments' },
  { action: 'warmup_comment', weight: 0, label: '✍️ Posted a comment' }, // weight set dynamically
];

let warmupLastAction = null;

function pickWarmupAction(enableComments) {
  const pool = WARMUP_ACTIONS.map(a => ({
    ...a,
    weight: a.action === 'warmup_comment' ? (enableComments ? 8 : 0) : a.weight,
  })).filter(a => a.weight > 0 && a.action !== warmupLastAction);

  const total = pool.reduce((s, a) => s + a.weight, 0);
  let rand = Math.random() * total;
  for (const item of pool) {
    rand -= item.weight;
    if (rand <= 0) {
      warmupLastAction = item.action;
      return item;
    }
  }
  return pool[0];
}

function getWarmupDelay() {
  const base = 2000 + Math.random() * 8000;
  const jitter = (Math.random() - 0.5) * 4000;
  const longPause = Math.random() < 0.12 ? 5000 + Math.random() * 10000 : 0;
  return Math.max(1500, base + jitter + longPause);
}

async function runWarmup(sessionMinutes, platform, enableComments, overrideStartTime) {
  const isResume = !!overrideStartTime;
  warmupState.isRunning = true;
  warmupState.stats = {
    storiesViewed: 0, postsLiked: 0,
    feedScrolls: 0, exploreScrolls: 0, commentsRead: 0,
    commentsPosted: 0, totalActions: 0, elapsedTime: 0,
    sessionTime: sessionMinutes * 60,
  };
  warmupState.logs = [];
  warmupLastAction = null;

  const addWarmupLog = (msg) => {
    warmupState.logs.unshift({
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toISOString(),
      message: msg,
    });
    if (warmupState.logs.length > 80) warmupState.logs.length = 80;
  };

  if (isResume) {
    const elapsedMin = Math.round((Date.now() - overrideStartTime) / 60000);
    addWarmupLog(`Warm-up resumed — ${sessionMinutes - elapsedMin} min remaining`);
  } else {
    addWarmupLog(`Warm-up started — ${sessionMinutes} min session`);
  }

  // Ensure we're on the home feed to start
  try {
    const tab = await getOrCreatePlatformTab(platform, { createIfMissing: true });
    if (tab) {
      const homeUrl = platform === 'instagram' ? 'https://www.instagram.com/' : 'https://www.tiktok.com/';
      if (!tab.url || !tab.url.endsWith('.com/')) {
        await navigateTabAndWait(tab.id, homeUrl);
      }
      await ensureContentScript(tab.id, platform);
    }
  } catch (e) {
    console.log('[Futnor Warmup] Could not navigate to home:', e.message);
  }

  // Use wall-clock time for accurate elapsed tracking (survives service worker restart)
  const startTime = overrideStartTime || Date.now();
  const totalMs = sessionMinutes * 60 * 1000;

  // Keep-alive alarm — 12s interval to aggressively prevent MV3 service worker suspension
  chrome.alarms.create('warmup-keepalive', { periodInMinutes: 0.2 });

  // Persist warmup state so we can auto-resume if the service worker restarts
  await persistWarmupSession({ isRunning: true, startTime, sessionMinutes, platform, enableComments });

  let consecutiveFailures = 0;
  const MAX_CONSECUTIVE_FAILURES = 5;

  // Let Instagram finish booting before overlay injection or any DOM-heavy warm-up actions
  await warmupChunkedSleep(2500);
  await showBannerOnPlatformTab(platform, 'warmup');
  setTimeout(() => { if (warmupState.isRunning) showBannerOnPlatformTab(platform, 'warmup'); }, 2000);
  await warmupChunkedSleep(1500);

  while (warmupState.isRunning) {
    // Wall-clock elapsed check
    const elapsed = Date.now() - startTime;
    warmupState.stats.elapsedTime = Math.round(elapsed / 1000);
    if (elapsed >= totalMs) break;

    let picked = pickWarmupAction(enableComments);
    // First action should always be feed scroll
    if (warmupState.stats.totalActions === 0 && picked.action !== 'warmup_scroll_feed') {
      picked = WARMUP_ACTIONS.find(item => item.action === 'warmup_scroll_feed') || picked;
    }

    // Map warmup actions to content script actions
    let extensionAction = 'scroll';
    switch (picked.action) {
      case 'warmup_scroll_feed': extensionAction = 'warmupFeed'; break;
      case 'warmup_scroll_explore': extensionAction = 'warmupExplore'; break;
      case 'warmup_view_story': extensionAction = 'warmupStory'; break;
      case 'warmup_like_post': extensionAction = 'warmupLike'; break;
      case 'warmup_read_comments': extensionAction = 'warmupReadComments'; break;
      case 'warmup_comment': extensionAction = 'warmupComment'; break;
      case 'warmup_pause': extensionAction = null; break;
    }

    let actionSuccess = false;
    let actionTimedOut = false;
    let actionStalled = false;
    let actionLabel = picked.label;

    if (extensionAction) {
      const result = await sendWarmupActionToTab(extensionAction, platform);
      console.log(`[Futnor Warmup] Action "${extensionAction}" result:`, result);
      if (result && typeof result === 'object') {
        actionSuccess = !!result.success;
        actionTimedOut = !!result.timedOut;
        actionStalled = !!result.stalled;
        if (result.label) actionLabel = result.label;
      } else {
        actionSuccess = !!result;
      }
    } else {
      // Pause — just wait
      const pauseMs = getRandom(2000, 5000);
      await warmupChunkedSleep(pauseMs);
      actionSuccess = true;
      actionLabel = `⏸️ Paused for ${Math.round(pauseMs / 1000)}s`;
    }

    // Track consecutive failures for recovery — increment by 1 always, never jump to max
    if (!actionSuccess && extensionAction) {
      consecutiveFailures++;
      console.log(`[Futnor Warmup] Consecutive failures: ${consecutiveFailures}`);

      if (actionTimedOut || actionStalled) {
        addWarmupLog(`⚠️ ${actionLabel} — recovering tab...`);
      }

      if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
        if (!actionTimedOut && !actionStalled) addWarmupLog('⚠️ Tab unresponsive — recovering...');
        // Recovery: reload the tab and re-inject content script
        try {
          const tab = await getOrCreatePlatformTab(platform, { createIfMissing: true });
          if (tab) {
            const homeUrl = platform === 'instagram' ? 'https://www.instagram.com/' : 'https://www.tiktok.com/';
            await navigateTabAndWait(tab.id, homeUrl);
            await ensureContentScript(tab.id, platform);
            await warmupChunkedSleep(5000); // Longer cooldown after recovery
            await showBannerOnPlatformTab(platform, 'warmup');
            consecutiveFailures = 0;
            addWarmupLog('✅ Tab recovered — resuming warm-up');
          }
        } catch (e) {
          console.error('[Futnor Warmup] Recovery failed:', e.message);
          addWarmupLog('❌ Recovery failed — retrying in 10s...');
          await warmupChunkedSleep(10000);
        }
        continue; // Retry the loop without counting this as an action
      }
    } else {
      consecutiveFailures = 0;
    }

    // Only update stats and log on SUCCESS
    if (actionSuccess) {
      warmupState.stats.totalActions++;
      switch (picked.action) {
        case 'warmup_view_story': warmupState.stats.storiesViewed++; break;
        case 'warmup_like_post': warmupState.stats.postsLiked++; break;
        case 'warmup_scroll_feed': warmupState.stats.feedScrolls++; break;
        case 'warmup_scroll_explore': warmupState.stats.exploreScrolls++; break;
        case 'warmup_read_comments': warmupState.stats.commentsRead++; break;
        case 'warmup_comment': warmupState.stats.commentsPosted++; break;
      }
      addWarmupLog(actionLabel);
    }

    // Push live warmup stats to the banner on the Instagram tab
    try {
      const tab = await getOrCreatePlatformTab(platform, { createIfMissing: false });
      if (tab) {
        chrome.tabs.sendMessage(tab.id, {
          type: 'UPDATE_BANNER',
          stats: warmupState.stats,
          latestLog: actionSuccess ? actionLabel : '⏳ Waiting...',
        }).catch(() => {});
      }
    } catch (e) {
      console.warn('[Futnor Background] Warmup: banner update failed:', e?.message || e);
    }

    const delay = getWarmupDelay();
    await warmupChunkedSleep(delay);
  }

  chrome.alarms.clear('warmup-keepalive');
  warmupState.isRunning = false;
  await clearWarmupPersistence();
  addWarmupLog('Warm-up session complete ✓');
  await hideBannerOnPlatformTab(platform);
}

// ─── Engagement Monitor ─────────────────────────────────────────────────
// Watches a post for new commenters/likers and auto-DMs them.
// This is a SEPARATE session type that does NOT affect the main targeting/DM flow.

let engagementMonitorActive = false;

async function runEngagementMonitor(config) {
  const { postUrls: rawPostUrls, postUrl: legacyPostUrl, triggerKeywords, commentToDm, likeToDm, followToDm, dmScript } = config;
  // Support both legacy single postUrl and new postUrls array
  const postUrls = (rawPostUrls && rawPostUrls.length > 0) ? rawPostUrls : (legacyPostUrl ? [legacyPostUrl] : []);
  if (postUrls.length === 0 || !dmScript) {
    addLog('session_end', '❌ Engagement monitor: missing post URLs or DM script');
    return;
  }

  engagementMonitorActive = true;
  sessionState.isRunning = true;
  sessionState.isPaused = false;
  sessionState.stats = { dmsSent: 0, likesSent: 0, followsSent: 0, scrolls: 0, elapsedTime: 0, sessionTime: 0 };
  sessionState.logs = [];
  saveState();

  addLog('session_start', `👁️ Monitoring ${postUrls.length} post${postUrls.length > 1 ? 's' : ''} for engagement → DM`);

  const platform = 'instagram';
  const primeResult = await primePlatformTabForSession(platform, {
    createIfMissing: true, focus: true, sessionSignal: 'SESSION_START',
  });

  if (!primeResult.ok) {
    addLog('session_end', '❌ Could not open Instagram tab');
    sessionState.isRunning = false;
    engagementMonitorActive = false;
    saveState();
    return;
  }

  const tabId = primeResult.tab?.id;

  const dmHistory = new Set(); // Track who we already DMed this session
  let scanCount = 0;
  const MAX_SCANS = 500; // Safety limit
  let postIndex = 0; // Cycles through postUrls
  const normalizeOwnerList = (owners) => new Set(
    (Array.isArray(owners) ? owners : [])
      .map((owner) => normalizeInstagramUsername(owner))
      .filter(Boolean)
  );

  chrome.alarms.create('session-tick', { periodInMinutes: 1 / 60 });

  while (engagementMonitorActive && sessionState.isRunning && !shouldStop() && scanCount < MAX_SCANS) {
    if (sessionState.isPaused) {
      await waitWhilePaused();
      if (!sessionState.isRunning) break;
    }

    scanCount++;
    const newTargets = [];
    const seenTargetsThisScan = new Set();
    const ownerBlacklist = new Set();
    const activeOwner = normalizeInstagramUsername(activeAccountUsername);
    if (activeOwner) {
      ownerBlacklist.add(activeOwner);
    }
    const currentPostUrl = postUrls[postIndex % postUrls.length];
    const postLabel = postUrls.length > 1 ? ` [${postIndex % postUrls.length + 1}/${postUrls.length}]` : '';
    let skippedFirstCommenterThisScan = false;

    // Navigate to the current post (fresh load each time)
    try {
      const loaded = await loadEngagementMonitorPost(tabId, currentPostUrl, platform);
      if (!loaded) {
        throw new Error('post_load_failed');
      }
    } catch (e) {
      addLog('scroll', `🔄 Scan #${scanCount}${postLabel} — could not load post, skipping...`);
      postIndex++;
      await waitMs(5000);
      continue;
    }

    // ── Scan commenters ──
    if (commentToDm) {
      try {
        const commentResult = await chrome.tabs.sendMessage(tabId, {
          type: 'PERFORM_ACTION', action: 'monitorPostComments', keywords: triggerKeywords || [],
        });
        for (const owner of normalizeOwnerList(commentResult?.owners)) {
          ownerBlacklist.add(owner);
        }
        
        if (commentResult?.commenters) {
          for (const c of commentResult.commenters) {
            const normalizedUsername = normalizeInstagramUsername(c.username);
            if (!normalizedUsername || ownerBlacklist.has(normalizedUsername) || dmHistory.has(normalizedUsername) || seenTargetsThisScan.has(normalizedUsername)) {
              continue;
            }

            if (!skippedFirstCommenterThisScan) {
              skippedFirstCommenterThisScan = true;
              addLog('dm_skipped', `⏭️ Skipping first matched commenter @${normalizedUsername}${postLabel}`);
              continue;
            }

            seenTargetsThisScan.add(normalizedUsername);
            newTargets.push({ username: normalizedUsername, reason: `commented "${c.trigger}"` });
          }
        }
      } catch (e) {
        console.error('[Futnor Background] Comment scan error:', e);
      }
    }

    // ── Scan likers ──
    if (likeToDm) {
      try {
        const likerResult = await chrome.tabs.sendMessage(tabId, {
          type: 'PERFORM_ACTION', action: 'monitorPostLikers',
        });
        for (const owner of normalizeOwnerList(likerResult?.owners)) {
          ownerBlacklist.add(owner);
        }

        if (likerResult?.likers) {
          for (const username of likerResult.likers) {
            const normalizedUsername = normalizeInstagramUsername(username);
            if (!normalizedUsername || ownerBlacklist.has(normalizedUsername) || dmHistory.has(normalizedUsername) || seenTargetsThisScan.has(normalizedUsername)) {
              continue;
            }

            seenTargetsThisScan.add(normalizedUsername);
            newTargets.push({ username: normalizedUsername, reason: 'liked post' });
          }
        }
      } catch (e) {
        console.error('[Futnor Background] Liker scan error:', e);
      }
    }

    // ── Scan new followers ──
    if (followToDm) {
      try {
        const followResult = await chrome.tabs.sendMessage(tabId, {
          type: 'PERFORM_ACTION', action: 'monitorNewFollowers',
        });

        if (followResult?.followers) {
          for (const username of followResult.followers) {
            const normalizedUsername = normalizeInstagramUsername(username);
            if (!normalizedUsername || ownerBlacklist.has(normalizedUsername) || dmHistory.has(normalizedUsername) || seenTargetsThisScan.has(normalizedUsername)) {
              continue;
            }

            seenTargetsThisScan.add(normalizedUsername);
            newTargets.push({ username: normalizedUsername, reason: 'new follower' });
          }
        }

        // After follower scan, navigate back to the current post for DM dispatch
        if (followResult?.followers?.length > 0) {
          await navigateTabAndWait(tabId, currentPostUrl);
          await waitMs(randomInt(1000, 2000));
        }
      } catch (e) {
        console.error('[Futnor Background] Follower scan error:', e);
      }
    }

    // ── DM new targets ──
    for (const target of newTargets) {
      if (!engagementMonitorActive || !sessionState.isRunning || shouldStop()) break;
      if (dmHistory.has(target.username)) continue;
      if (ownerBlacklist.has(target.username)) {
        addLog('dm_skipped', `⏭️ Skipping post owner @${target.username}${postLabel}`);
        continue;
      }

      addLog('dm', `📨 DMing @${target.username} (${target.reason})${postLabel}`);

      const dmResult = await sendInstagramDirectComposeDM(dmScript, target.username);

      if (dmResult) {
        dmHistory.add(target.username);
        sessionState.stats.dmsSent++;
        addLog('dm', `✅ DM sent to @${target.username}`);
        updateBannerLive(`✅ DM sent to @${target.username}`);
        try { await postCommentAfterDM(target.username); } catch {}
      } else {
        addLog('dm_skipped', `❌ DM failed for @${target.username}`);
      }

      saveState();

      // Return to post
      await navigateTabAndWait(tabId, currentPostUrl);
      await waitMs(randomInt(1200, 2200));
    }

    if (newTargets.length === 0) {
      addLog('scroll', `🔍 Scan #${scanCount}${postLabel} — no new engagements`);
    } else {
      addLog('scroll', `🔍 Scan #${scanCount}${postLabel} — found ${newTargets.length} new targets`);
    }

    // Advance to next post for next scan cycle
    postIndex++;

    updateBannerLive(`Monitoring${postLabel}... Scan #${scanCount} | ${sessionState.stats.dmsSent} DMs sent`);
    saveState();

    // Wait before next scan — tighter cadence so fresh comments are picked up quickly.
    await waitMs(randomInt(8000, 12000));
  }

  addLog('session_end', `👁️ Engagement monitor stopped — ${sessionState.stats.dmsSent} DMs sent across ${postUrls.length} post${postUrls.length > 1 ? 's' : ''}`);
  sessionState.isRunning = false;
  engagementMonitorActive = false;
  chrome.alarms.clear('session-tick');
  saveState();
  await hideBannerOnPlatformTab(platform);
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ─── Message handler ───
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    // ── Main-world execCommand injection ─────────────────────────────────────
    // Content scripts run in an isolated world; calling execCommand from there
    // can fail to fire isTrusted events into Instagram's Lexical editor.
    // By injecting into world:'MAIN' via chrome.scripting, the call happens
    // in the same JS context as the page code — Lexical treats it as trusted.
    case 'INJECT_EXECCOMMAND': {
      (async () => {
        try {
          const tabId = sender?.tab?.id;
          if (!tabId) { sendResponse({ success: false, error: 'no tabId' }); return; }
          const text = msg.text || '';
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: async (insertText) => {
              function normalizeOutgoingMessage(message) {
                if (!message) return '';
                return message
                  .toString()
                  .replace(/\r\n?/g, '\n')
                  .replace(/\u00A0/g, ' ')
                  .split('\n')
                  .map((line) => line.replace(/[ \t]+$/g, ''))
                  .join('\n');
              }
              function normalizeComposerSnapshot(message) {
                return normalizeOutgoingMessage(message)
                  .replace(/\u200B/g, '')
                  .replace(/[ \t]+\n/g, '\n')
                  .replace(/\n{3,}/g, '\n\n')
                  .trim();
              }
              function composerTextMatchesExpected(actualText, expectedText) {
                const actual = normalizeComposerSnapshot(actualText);
                const expected = normalizeComposerSnapshot(expectedText);
                if (!actual || !expected) return false;
                // Primary: exact match after normalization
                if (actual === expected) return true;
                // Secondary: newline-tolerant match.
                // Lexical's innerText returns \n or \n\n for paragraph boundaries
                // depending on the page's CSS (full-page vs widget have different margins).
                // Collapsing all newline runs to \n confirms text was entered without
                // accepting partial scripts — every non-whitespace character must match.
                const actualNL = actual.replace(/\n+/g, '\n');
                const expectedNL = expected.replace(/\n+/g, '\n');
                return actualNL === expectedNL;
              }
              // Helper: reject search inputs, nav bars on /direct/inbox/
              function isDMCandidate(el) {
                if (!el) return false;
                if (el.tagName === 'INPUT') return false;
                const aria = (el.getAttribute('aria-label') || '').toLowerCase();
                const ph = (el.getAttribute('placeholder') || '').toLowerCase();
                if (aria.includes('search') || ph.includes('search')) return false;
                if (el.closest('nav') || el.closest('[role="search"]')) return false;
                return true;
              }
              function getComposerText(el) {
                if (!el) return '';
                if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return el.value || '';
                const raw = (typeof el.innerText === 'string' && el.innerText.length > 0)
                  ? el.innerText
                  : (el.textContent || '');
                return raw.replace(/\u200B/g, '');
              }
              async function waitForStableComposerMatch(el, expectedText, options = {}) {
                const {
                  maxChecks = 6,
                  requiredConsecutive = 2,
                  delayMs = 100,
                } = options;
                let stablePasses = 0;

                for (let check = 0; check < maxChecks; check++) {
                  const textNow = getComposerText(el);
                  if (composerTextMatchesExpected(textNow, expectedText)) {
                    stablePasses += 1;
                    if (stablePasses >= requiredConsecutive) return true;
                  } else {
                    stablePasses = 0;
                  }
                  await new Promise(r => setTimeout(r, delayMs));
                }

                return false;
              }
              function selectionInsideComposer(el) {
                try {
                  const selection = window.getSelection();
                  if (!selection || selection.rangeCount === 0) return false;
                  return el.contains(selection.getRangeAt(0).commonAncestorContainer);
                } catch (_) {
                  return false;
                }
              }
              function placeCaretAtEnd(el) {
                if (!el || el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return true;
                try {
                  const selection = window.getSelection();
                  const range = document.createRange();
                  let target = el;
                  while (target && target.lastChild) {
                    target = target.lastChild;
                    if (target.nodeType === Node.TEXT_NODE) break;
                    if (target.nodeName === 'BR') {
                      range.setStartBefore(target);
                      range.collapse(true);
                      selection.removeAllRanges();
                      selection.addRange(range);
                      return true;
                    }
                  }
                  if (target && target.nodeType === Node.TEXT_NODE) {
                    range.setStart(target, target.textContent?.length || 0);
                    range.collapse(true);
                  } else if (el.lastElementChild) {
                    range.selectNodeContents(el.lastElementChild);
                    range.collapse(false);
                  } else {
                    range.selectNodeContents(el);
                    range.collapse(false);
                  }
                  selection.removeAllRanges();
                  selection.addRange(range);
                  return true;
                } catch (_) {
                  return false;
                }
              }
              async function primeComposer(el) {
                if (!el) return false;
                if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
                  try { el.focus({ preventScroll: true }); } catch (_) { try { el.focus(); } catch (_) {} }
                  return true;
                }
                for (let i = 0; i < 6; i++) {
                  try { el.click(); } catch (_) {}
                  try { el.focus({ preventScroll: true }); } catch (_) { try { el.focus(); } catch (_) {} }
                  await new Promise(r => setTimeout(r, 90));
                  if (!selectionInsideComposer(el)) {
                    placeCaretAtEnd(el);
                    await new Promise(r => setTimeout(r, 70));
                  }
                  if (selectionInsideComposer(el)) return true;
                }
                return false;
              }
              // Walk up from an element to find the nearest contenteditable/Lexical parent
              function findComposerAncestor(startEl) {
                let node = startEl;
                while (node && node !== document.body) {
                  if (node.getAttribute && (
                    node.getAttribute('contenteditable') === 'true' ||
                    node.hasAttribute('data-lexical-editor') ||
                    node.tagName === 'TEXTAREA'
                  )) {
                    return node;
                  }
                  node = node.parentElement;
                }
                return null;
              }
              function scoreComposerCandidate(candidate) {
                if (!candidate) return -1;
                const rect = candidate.getBoundingClientRect();
                const label = (candidate.getAttribute('aria-label') || '').toLowerCase();
                const placeholder = (candidate.getAttribute('placeholder') || '').toLowerCase();
                let score = 0;
                score += rect.left;
                score += rect.top * 0.45;
                if (label.includes('message') || placeholder.includes('message')) score += 500;
                if (candidate.closest('form')) score += 220;
                if (rect.top > window.innerHeight * 0.45) score += 180;
                if (rect.width > 120) score += 40;
                return score;
              }
              const SELECTORS = [
                'div[role="textbox"][contenteditable="true"]',
                'div[data-lexical-editor="true"]',
                'div[contenteditable="true"][aria-label*="essage"]',
                'div[contenteditable="true"]',
                'textarea',
              ];

              // ── ELEMENT SELECTION ─────────────────────────────────────────────
              // The content script already focused the correct Lexical editor.
              // activeElement might be a CHILD node inside the editor (e.g. <p>, <span>).
              // Walk up to find the actual contenteditable root so we don't re-search
              // and accidentally re-focus a different element (which resets Lexical).
              let el = null;
              let alreadyFocused = false;
              const active = document.activeElement;
              if (active) {
                // Direct match
                if (isDMCandidate(active) &&
                    (active.getAttribute('contenteditable') === 'true' ||
                     active.hasAttribute('data-lexical-editor') ||
                     active.tagName === 'TEXTAREA')) {
                  el = active;
                  alreadyFocused = true;
                }
                // Walk up from active element (handles <p>, <span> inside editor)
                if (!el) {
                  const ancestor = findComposerAncestor(active);
                  if (ancestor && isDMCandidate(ancestor)) {
                    el = ancestor;
                    alreadyFocused = true; // cursor is inside this element's subtree
                  }
                }
              }
              // Fallback: dialog composer, then full-page search
              if (!el) {
                const dialog = document.querySelector('[role="dialog"]');
                if (dialog) {
                  for (const sel of SELECTORS) {
                    const candidate = dialog.querySelector(sel);
                    if (candidate && isDMCandidate(candidate)) { el = candidate; break; }
                  }
                }
              }
              if (!el) {
                let bestScore = -1;
                for (const sel of SELECTORS) {
                  const candidates = document.querySelectorAll(sel);
                  for (const c of candidates) {
                    if (isDMCandidate(c)) {
                      const rect = c.getBoundingClientRect();
                      if (rect.width > 0 && rect.height > 0) {
                        const score = scoreComposerCandidate(c);
                        if (score > bestScore) {
                          bestScore = score;
                          el = c;
                        }
                      }
                    }
                  }
                  // If found with a specific selector (textbox/lexical), use it
                  if (el && (sel.includes('textbox') || sel.includes('lexical') || sel.includes('essage'))) break;
                }
              }
              if (!el) return { ok: false, reason: 'no composer' };
              if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
                // Textarea path: use native value setter so React re-renders
                const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
                if (setter) setter.call(el, insertText); else el.value = insertText;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
                const stable = await waitForStableComposerMatch(el, insertText, { maxChecks: 5, requiredConsecutive: 2, delayMs: 80 });
                return { ok: stable, via: 'textarea-setter' };
              }
              // Contenteditable / Lexical path
              // Only re-focus if we didn't reuse the content script's active element.
              if (!alreadyFocused || !selectionInsideComposer(el)) {
                await primeComposer(el);
              }
              if (!selectionInsideComposer(el)) placeCaretAtEnd(el);

              // ── ADAPTIVE LEXICAL READINESS WAIT ──────────────────────────────
              // Full pointer event activation to properly trigger Lexical's listeners
              const elRect = el.getBoundingClientRect();
              const elCx = elRect.left + elRect.width / 2;
              const elCy = elRect.top + elRect.height / 2;
              const pOpts = { bubbles: true, cancelable: true, clientX: elCx, clientY: elCy, button: 0 };
              el.dispatchEvent(new PointerEvent('pointerdown', { ...pOpts, pointerId: 1, pointerType: 'mouse' }));
              await new Promise(r => setTimeout(r, 30));
              el.dispatchEvent(new MouseEvent('mousedown', pOpts));
              await new Promise(r => setTimeout(r, 30));
              el.dispatchEvent(new PointerEvent('pointerup', { ...pOpts, pointerId: 1, pointerType: 'mouse' }));
              el.dispatchEvent(new MouseEvent('mouseup', pOpts));
              await new Promise(r => setTimeout(r, 20));
              el.dispatchEvent(new MouseEvent('click', pOpts));
              await new Promise(r => setTimeout(r, 150));
              el.focus({ preventScroll: true });
              el.dispatchEvent(new FocusEvent('focus', { bubbles: false }));

              for (let _i = 0; _i < 20; _i++) {
                await new Promise(r => setTimeout(r, 80));
                try {
                  const _sel = window.getSelection();
                  if (_sel && _sel.rangeCount > 0) {
                    const _r = _sel.getRangeAt(0);
                    if (el.contains(_r.commonAncestorContainer)) break;
                  }
                } catch (_) {}
                // Re-activate every 4th attempt
                if (_i > 0 && _i % 4 === 0) {
                  el.dispatchEvent(new PointerEvent('pointerdown', { ...pOpts, pointerId: 1, pointerType: 'mouse' }));
                  await new Promise(r => setTimeout(r, 20));
                  el.dispatchEvent(new MouseEvent('mousedown', pOpts));
                  await new Promise(r => setTimeout(r, 20));
                  el.dispatchEvent(new PointerEvent('pointerup', { ...pOpts, pointerId: 1, pointerType: 'mouse' }));
                  el.dispatchEvent(new MouseEvent('mouseup', pOpts));
                  el.dispatchEvent(new MouseEvent('click', pOpts));
                  await new Promise(r => setTimeout(r, 80));
                  el.focus({ preventScroll: true });
                }
              }

              const replaceComposerContents = (targetEl, value) => {
                if (!targetEl) return false;
                const normalizedValue = normalizeOutgoingMessage(value);

                if (targetEl.tagName === 'TEXTAREA' || targetEl.tagName === 'INPUT') {
                  const proto = targetEl.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                  const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
                  if (setter) setter.call(targetEl, normalizedValue); else targetEl.value = normalizedValue;
                  targetEl.dispatchEvent(new Event('input', { bubbles: true }));
                  targetEl.dispatchEvent(new Event('change', { bubbles: true }));
                  return composerTextMatchesExpected(targetEl.value || '', normalizedValue);
                }

                const lines = normalizedValue.split('\n');
                const paragraphNodes = lines.map((line) => {
                  const p = document.createElement('p');
                  if (line.length > 0) {
                    p.textContent = line;
                  } else {
                    p.appendChild(document.createElement('br'));
                  }
                  return p;
                });

                try {
                  if (typeof targetEl.replaceChildren === 'function') {
                    targetEl.replaceChildren(...paragraphNodes);
                  } else {
                    targetEl.innerHTML = '';
                    paragraphNodes.forEach((node) => targetEl.appendChild(node));
                  }
                } catch (_) {
                  return false;
                }

                try {
                  const selection = window.getSelection();
                  const range = document.createRange();
                  const lastParagraph = paragraphNodes[paragraphNodes.length - 1] || targetEl;
                  const lastNode = lastParagraph.lastChild || lastParagraph;

                  if (lastNode.nodeType === Node.TEXT_NODE) {
                    range.setStart(lastNode, lastNode.textContent?.length || 0);
                    range.collapse(true);
                  } else {
                    range.selectNodeContents(lastParagraph);
                    range.collapse(false);
                  }

                  selection?.removeAllRanges();
                  selection?.addRange(range);
                } catch (_) {}

                try {
                  targetEl.dispatchEvent(new InputEvent('input', {
                    bubbles: true,
                    cancelable: false,
                    inputType: 'insertFromPaste',
                    data: normalizedValue,
                  }));
                } catch (_) {
                  targetEl.dispatchEvent(new Event('input', { bubbles: true }));
                }

                try {
                  targetEl.dispatchEvent(new CompositionEvent('compositionend', {
                    bubbles: true,
                    cancelable: false,
                    data: normalizedValue,
                  }));
                } catch (_) {}

                targetEl.dispatchEvent(new Event('change', { bubbles: true }));
                return composerTextMatchesExpected(getComposerText(targetEl), normalizedValue);
              };

              // ── TEXT INSERTION (with retry) ───────────────────────────────────
              // Instagram configures Lexical in "Enter = send" mode on BOTH the
              // /direct/ full-page layout AND the floating chat widget.
              // execCommand('insertLineBreak') is intercepted by Lexical as a send
              // trigger instead of creating a new paragraph — which caused multi-line
              // scripts to send a TRUNCATED first paragraph to the user and leave
              // only the last paragraph in the composer. The paste-based insertion
              // (replaceComposerContents) bypasses insertLineBreak entirely by
              // shipping the whole text via insertFromPaste, so Lexical treats it
              // as a single paste operation — no spurious sends.
              //
              // CRITICAL: do NOT gate this on isDirectPage. The widget chat has the
              // same Enter=send behaviour. Always use paste for multi-line.
              const isMultiLine = insertText.includes('\n');
              const MAX_INSERT_ATTEMPTS = 3;
              let insertOk = false;
              let textAfter = '';

              // For ANY multi-line script, use paste-based insertion first.
              // This avoids insertLineBreak entirely and handles newlines in one shot.
              if (isMultiLine) {
                const pasteOk = replaceComposerContents(el, insertText);
                if (pasteOk) {
                  await new Promise(r => setTimeout(r, 400));
                  insertOk = await waitForStableComposerMatch(el, insertText, { maxChecks: 8, requiredConsecutive: 3, delayMs: 140 });
                  textAfter = getComposerText(el);
                }
                if (!insertOk) {
                  // Retry once with a re-prime before falling through to execCommand loop
                  await primeComposer(el);
                  await new Promise(r => setTimeout(r, 300));
                  const pasteOk2 = replaceComposerContents(el, insertText);
                  if (pasteOk2) {
                    await new Promise(r => setTimeout(r, 400));
                    insertOk = await waitForStableComposerMatch(el, insertText, { maxChecks: 8, requiredConsecutive: 3, delayMs: 140 });
                    textAfter = getComposerText(el);
                  }
                }
                if (insertOk) {
                  console.log('[Futnor MAIN] multi-line paste insertion succeeded (widget or /direct/)');
                }
              }

              for (let insertAttempt = 0; insertAttempt < MAX_INSERT_ATTEMPTS && !insertOk; insertAttempt++) {
                if (insertAttempt > 0) {
                  // Re-prime composer before retry
                  await primeComposer(el);
                  await new Promise(r => setTimeout(r, 300));
                }
                // Check if composer is empty first; only clear if it has existing text.
                const existingText = getComposerText(el).trim();
                if (normalizeComposerSnapshot(existingText).length > 0) {
                  if (!selectionInsideComposer(el)) placeCaretAtEnd(el);
                  document.execCommand('selectAll', false, null);
                  document.execCommand('delete', false, null);
                  el.textContent = '';
                  el.dispatchEvent(new InputEvent('input', {
                    bubbles: true,
                    cancelable: false,
                    inputType: 'deleteContentBackward',
                    data: null,
                  }));
                  await new Promise(r => setTimeout(r, 100));

                  if (normalizeComposerSnapshot(getComposerText(el)).length > 0) {
                    replaceComposerContents(el, '');
                    await new Promise(r => setTimeout(r, 120));
                  }
                }

                const lines = insertText.split('\n');
                let lineBreakFailed = false;
                for (let li = 0; li < lines.length; li++) {
                  if (!selectionInsideComposer(el)) placeCaretAtEnd(el);
                  if (lines[li].length > 0) {
                    document.execCommand('insertText', false, lines[li]);
                  }
                  if (li < lines.length - 1) {
                    const insertedBreak = document.execCommand('insertLineBreak', false, null)
                      || document.execCommand('insertHTML', false, '<br>');
                    if (!insertedBreak) {
                      // insertLineBreak not supported — bail out of this method and
                      // let replaceComposerContents handle the full text below.
                      lineBreakFailed = true;
                      break;
                    }
                    await new Promise(r => setTimeout(r, 30));
                  }
                }

                // If insertLineBreak failed mid-loop, clear and use paste fallback immediately
                if (lineBreakFailed) {
                  document.execCommand('selectAll', false, null);
                  document.execCommand('delete', false, null);
                  await new Promise(r => setTimeout(r, 100));
                  replaceComposerContents(el, insertText);
                  await new Promise(r => setTimeout(r, 400));
                }

                await new Promise(r => setTimeout(r, 200));
                insertOk = await waitForStableComposerMatch(el, insertText, { maxChecks: 8, requiredConsecutive: 3, delayMs: 140 });
                textAfter = getComposerText(el);
                if (insertOk) break;
                // If not ok, wait before retry
                await new Promise(r => setTimeout(r, 500));
              }

              // If execCommand failed after all attempts, try DOM mutation as final fallback
              if (!insertOk) {
                console.log('[Futnor MAIN] execCommand failed — trying replaceComposerContents fallback...');
                const replaceOk = replaceComposerContents(el, insertText);
                if (replaceOk) {
                  await new Promise(r => setTimeout(r, 300));
                  insertOk = await waitForStableComposerMatch(el, insertText, { maxChecks: 6, requiredConsecutive: 2, delayMs: 120 });
                  textAfter = getComposerText(el);
                  if (insertOk) {
                    return { ok: true, via: 'replaceComposerContents-fallback', text: textAfter.slice(0, 80), alreadyFocused };
                  }
                }
              }

              const ok = insertOk || composerTextMatchesExpected(textAfter, insertText);
              return { ok, via: 'execCommand-main-world', text: textAfter.slice(0, 80), alreadyFocused, attempts: MAX_INSERT_ATTEMPTS };
            },
            args: [text],
          });
          const result = results?.[0]?.result;
          console.log('[Futnor Background] INJECT_EXECCOMMAND result:', JSON.stringify(result));
          const success = result?.ok === true;
          sendResponse({ success, result });
        } catch (e) {
          console.error('[Futnor Background] INJECT_EXECCOMMAND error:', e.message);
          sendResponse({ success: false, error: e.message });
        }
      })();
      return true; // async response
    }
    // Inject a trusted-like Send button click into the main world — this is more
    // reliable than synthetic Enter on full-page /direct/t/ chats where Instagram
    // wires sending to the compose-row button instead of keyboard shortcuts.
    case 'INJECT_DM_SEND_CLICK': {
      (async () => {
        try {
          const tabId = sender?.tab?.id;
          if (!tabId) { sendResponse({ success: false, error: 'no tabId' }); return; }
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: () => {
              function isDMCandidate(el) {
                if (!el) return false;
                if (el.tagName === 'INPUT') return false;
                const aria = (el.getAttribute('aria-label') || '').toLowerCase();
                const ph = (el.getAttribute('placeholder') || '').toLowerCase();
                if (aria.includes('search') || ph.includes('search')) return false;
                if (el.closest('nav') || el.closest('[role="search"]')) return false;
                return true;
              }
              function findComposerAncestor(startEl) {
                let node = startEl;
                while (node && node !== document.body) {
                  if (node.getAttribute && (
                    node.getAttribute('contenteditable') === 'true' ||
                    node.hasAttribute('data-lexical-editor') ||
                    node.tagName === 'TEXTAREA'
                  )) {
                    return node;
                  }
                  node = node.parentElement;
                }
                return null;
              }
              function resolveComposer() {
                const SELECTORS = [
                  'div[role="textbox"][contenteditable="true"]',
                  'div[data-lexical-editor="true"]',
                  'div[contenteditable="true"][aria-label*="essage"]',
                  'div[contenteditable="true"]',
                  'textarea',
                ];
                const active = document.activeElement;
                if (active) {
                  if (isDMCandidate(active) && (
                    active.getAttribute('contenteditable') === 'true' ||
                    active.hasAttribute('data-lexical-editor') ||
                    active.tagName === 'TEXTAREA'
                  )) {
                    return active;
                  }
                  const ancestor = findComposerAncestor(active);
                  if (ancestor && isDMCandidate(ancestor)) return ancestor;
                }
                const dialog = document.querySelector('[role="dialog"]');
                if (dialog) {
                  for (const sel of SELECTORS) {
                    const candidate = dialog.querySelector(sel);
                    if (candidate && isDMCandidate(candidate)) return candidate;
                  }
                }
                let best = null;
                let bestX = -1;
                for (const sel of SELECTORS) {
                  for (const candidate of document.querySelectorAll(sel)) {
                    if (!isDMCandidate(candidate)) continue;
                    const rect = candidate.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0 && rect.left > bestX) {
                      best = candidate;
                      bestX = rect.left;
                    }
                  }
                }
                return best;
              }
              function getLabel(btn) {
                return [
                  btn.getAttribute('aria-label') || '',
                  btn.textContent || '',
                  btn.querySelector('svg')?.getAttribute('aria-label') || '',
                  btn.getAttribute('type') || '',
                ].join(' ').toLowerCase();
              }
              function scoreSendButton(btn, composerRect, composer) {
                if (!btn || !btn.isConnected) return -1;
                const rect = btn.getBoundingClientRect();
                if (rect.width <= 0 || rect.height <= 0) return -1;

                const label = getLabel(btn);
                const rejectKeywords = [
                  'detail', 'info', 'option', 'more', 'back', 'close', 'minimize',
                  'call', 'audio', 'video', 'phone', 'conversation', 'thread',
                  'action', 'flag', 'report', 'block', 'mute', 'setting',
                  'preference', 'delete', 'remove', 'leave'
                ];
                if (rejectKeywords.some((kw) => label.includes(kw))) return -1;
                if (rect.bottom < composerRect.top - 80) return -1;

                let score = 0;
                if (label.includes('send')) score += 100;
                if (label.includes('submit')) score += 60;
                if ((btn.getAttribute('type') || '').toLowerCase() === 'submit') score += 80;
                if (rect.left >= composerRect.right - 40) score += 30;
                if (rect.left > composerRect.left) score += 10;
                if (Math.abs(rect.top - composerRect.top) < 80) score += 25;
                if (Math.abs(rect.bottom - composerRect.bottom) < 80) score += 15;
                if (composer.closest('form') && btn.closest('form') === composer.closest('form')) score += 30;
                return score;
              }
              function findSendButton(composer) {
                const composerRect = composer.getBoundingClientRect();
                const containers = [
                  composer.closest('form'),
                  composer.parentElement,
                  composer.closest('section'),
                  composer.closest('[role="presentation"]'),
                  composer.closest('[role="main"]'),
                  document,
                ].filter((node, idx, arr) => node && arr.indexOf(node) === idx);

                let bestBtn = null;
                let bestScore = -1;
                for (const container of containers) {
                  const buttons = container.querySelectorAll ? container.querySelectorAll('button, [role="button"]') : [];
                  for (const btn of buttons) {
                    const score = scoreSendButton(btn, composerRect, composer);
                    if (score > bestScore) {
                      bestScore = score;
                      bestBtn = btn;
                    }
                  }
                  if (bestScore >= 100) break;
                }
                return bestScore >= 70 ? { button: bestBtn, score: bestScore } : null;
              }

              const composer = resolveComposer();
              if (!composer) return { ok: false, reason: 'no composer' };

              const found = findSendButton(composer);
              if (!found?.button) return { ok: false, reason: 'no send button' };

              const btn = found.button;
              btn.focus?.();
              const pointerOpts = { bubbles: true, cancelable: true, isPrimary: true, button: 0, buttons: 1 };
              const mouseOpts = { bubbles: true, cancelable: true, button: 0, buttons: 1 };
              // Fire the full pointer/mouse down→up sequence so React's
              // synthetic event system sees a realistic interaction.
              try { btn.dispatchEvent(new PointerEvent('pointerdown', pointerOpts)); } catch {}
              try { btn.dispatchEvent(new MouseEvent('mousedown', mouseOpts)); } catch {}
              try { btn.dispatchEvent(new PointerEvent('pointerup', { ...pointerOpts, buttons: 0 })); } catch {}
              try { btn.dispatchEvent(new MouseEvent('mouseup', { ...mouseOpts, buttons: 0 })); } catch {}
              // CRITICAL: fire the click EXACTLY ONCE. Previously this code
              // called BOTH dispatchEvent(new MouseEvent('click')) AND
              // btn.click() — Instagram's React onClick fired for each
              // event and the DM was sent TWICE. btn.click() is the
              // native path that properly triggers React's delegated
              // click handler, so we use only that one.
              try { btn.click?.(); } catch {}

              const btnRect = btn.getBoundingClientRect();
              const composerRectForLog = composer.getBoundingClientRect();
              return {
                ok: true,
                via: 'main-world-send-click',
                score: found.score,
                label: getLabel(btn).slice(0, 60),
                btnRect: { x: Math.round(btnRect.left), y: Math.round(btnRect.top), w: Math.round(btnRect.width), h: Math.round(btnRect.height) },
                composerRect: { x: Math.round(composerRectForLog.left), y: Math.round(composerRectForLog.top), w: Math.round(composerRectForLog.width), h: Math.round(composerRectForLog.height) },
                disabled: btn.disabled === true || btn.getAttribute('aria-disabled') === 'true',
                tag: btn.tagName,
              };
            },
          });
          const result = results?.[0]?.result;
          console.log('[Futnor Background] INJECT_DM_SEND_CLICK result:', JSON.stringify(result));
          sendResponse({ success: result?.ok === true, result });
        } catch (e) {
          console.error('[Futnor Background] INJECT_DM_SEND_CLICK error:', e.message);
          sendResponse({ success: false, error: e.message });
        }
      })();
      return true;
    }
    // Inject a trusted Enter keypress into the main world — Instagram's Lexical
    // editor only honours isTrusted=true keyboard events for the send shortcut.
    case 'INJECT_ENTER_KEY': {
      (async () => {
        try {
          const tabId = sender?.tab?.id;
          if (!tabId) { sendResponse({ success: false, error: 'no tabId' }); return; }
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: () => {
              // Helper: reject search inputs, nav bars on /direct/inbox/
              function isDMCandidate(el) {
                if (!el) return false;
                if (el.tagName === 'INPUT') return false;
                const aria = (el.getAttribute('aria-label') || '').toLowerCase();
                const ph = (el.getAttribute('placeholder') || '').toLowerCase();
                if (aria.includes('search') || ph.includes('search')) return false;
                if (el.closest('nav') || el.closest('[role="search"]')) return false;
                return true;
              }
              // Walk up from an element to find the nearest contenteditable/Lexical parent
              function findComposerAncestor(startEl) {
                let node = startEl;
                while (node && node !== document.body) {
                  if (node.getAttribute && (
                    node.getAttribute('contenteditable') === 'true' ||
                    node.hasAttribute('data-lexical-editor') ||
                    node.tagName === 'TEXTAREA'
                  )) {
                    return node;
                  }
                  node = node.parentElement;
                }
                return null;
              }
              // Prefer the already-focused composer (content script set it up)
              const SELECTORS = [
                'div[role="textbox"][contenteditable="true"]',
                'div[data-lexical-editor="true"]',
                'div[contenteditable="true"][aria-label*="essage"]',
                'div[contenteditable="true"]',
                'textarea',
              ];
              let el = null;
              const active = document.activeElement;
              if (active) {
                if (isDMCandidate(active) &&
                    (active.getAttribute('contenteditable') === 'true' ||
                     active.hasAttribute('data-lexical-editor') ||
                     active.tagName === 'TEXTAREA')) {
                  el = active;
                }
                if (!el) {
                  const ancestor = findComposerAncestor(active);
                  if (ancestor && isDMCandidate(ancestor)) {
                    el = ancestor;
                  }
                }
              }
              if (!el) {
                const dialog = document.querySelector('[role="dialog"]');
                if (dialog) {
                  for (const sel of SELECTORS) {
                    const candidate = dialog.querySelector(sel);
                    if (candidate && isDMCandidate(candidate)) { el = candidate; break; }
                  }
                }
              }
              if (!el) {
                let bestX = -1;
                for (const sel of SELECTORS) {
                  const candidates = document.querySelectorAll(sel);
                  for (const c of candidates) {
                    if (isDMCandidate(c)) {
                      const rect = c.getBoundingClientRect();
                      if (rect.width > 0 && rect.height > 0 && rect.left > bestX) {
                        bestX = rect.left;
                        el = c;
                      }
                    }
                  }
                  if (el && (sel.includes('textbox') || sel.includes('lexical') || sel.includes('essage'))) break;
                }
              }
              if (!el) return { ok: false, reason: 'no composer' };
              el.focus();
              // Dispatch a full trusted-like Enter key sequence
              const opts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
              el.dispatchEvent(new KeyboardEvent('keydown', opts));
              el.dispatchEvent(new KeyboardEvent('keypress', opts));
              el.dispatchEvent(new KeyboardEvent('keyup', { ...opts, cancelable: false }));
              return { ok: true, via: 'main-world-enter' };
            },
          });
          const result = results?.[0]?.result;
          console.log('[Futnor Background] INJECT_ENTER_KEY result:', JSON.stringify(result));
          sendResponse({ success: result?.ok === true, result });
        } catch (e) {
          console.error('[Futnor Background] INJECT_ENTER_KEY error:', e.message);
          sendResponse({ success: false, error: e.message });
        }
      })();
      return true;
    }
    case 'INJECT_WHATSAPP_TEXT': {
      (async () => {
        try {
          const tabId = sender?.tab?.id;
          if (!tabId) { sendResponse({ success: false, error: 'no tabId' }); return; }
          const response = await new Promise((resolve) => {
            chrome.tabs.sendMessage(tabId, { type: 'INJECT_EXECCOMMAND', text: msg.text || '' }, (res) => {
              if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
              else resolve(res || { success: false, error: 'no_response' });
            });
          });
          console.log('[Futnor Background] INJECT_WHATSAPP_TEXT delegated result:', JSON.stringify(response));
          sendResponse(response);
        } catch (e) {
          console.error('[Futnor Background] INJECT_WHATSAPP_TEXT error:', e.message);
          sendResponse({ success: false, error: e.message });
        }
      })();
      return true;
    }
    case 'INJECT_WHATSAPP_SEARCH': {
      (async () => {
        try {
          const tabId = sender?.tab?.id;
          if (!tabId) { sendResponse({ success: false, error: 'no tabId' }); return; }
          const text = msg.text || '';
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: async (searchText) => {
              function normalize(value) {
                return (value || '').toString().replace(/\u200B/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
              }
              function getSearchBox() {
                const selectors = [
                  'div[data-testid="chat-list-search"] div[contenteditable="true"]',
                  'div[role="textbox"][title*="earch"]',
                  'div[role="textbox"][title*="Buscar"]',
                  'div[role="textbox"][title*="Rechercher"]',
                  '#side div[contenteditable="true"]',
                  'div[contenteditable="true"][data-tab="3"]',
                  'p.selectable-text[data-tab="3"]',
                ];

                for (const sel of selectors) {
                  const candidate = document.querySelector(sel);
                  if (!candidate) continue;
                  const rect = candidate.getBoundingClientRect();
                  if (rect.width < 40 || rect.height < 18) continue;
                  if (candidate.closest('#main footer, #main [data-testid="conversation-compose-box-input"], #main div[role="textbox"]')) continue;
                  const aria = (candidate.getAttribute('aria-label') || candidate.getAttribute('title') || '').toLowerCase();
                  const placeholder = (candidate.getAttribute('data-placeholder') || candidate.getAttribute('placeholder') || '').toLowerCase();
                  const meta = `${aria} ${placeholder} ${candidate.closest('[data-testid]')?.getAttribute('data-testid') || ''}`;
                  if (
                    sel.includes('chat-list-search') ||
                    meta.includes('search') ||
                    meta.includes('buscar') ||
                    meta.includes('rechercher')
                  ) {
                    return candidate;
                  }
                  if (candidate.closest('#side')) return candidate;
                }

                return null;
              }
              function focusEnd(el) {
                el.focus?.({ preventScroll: true });
                const selection = window.getSelection();
                if (!selection) return;
                const range = document.createRange();
                range.selectNodeContents(el);
                range.collapse(false);
                selection.removeAllRanges();
                selection.addRange(range);
              }

              const searchBox = getSearchBox();
              if (!searchBox) return { ok: false, reason: 'no search box' };

              focusEnd(searchBox);
              await new Promise((resolve) => setTimeout(resolve, 50));
              try { document.execCommand('selectAll', false); } catch {}
              try { document.execCommand('delete', false); } catch {}
              searchBox.textContent = '';
              searchBox.innerHTML = '';
              try {
                searchBox.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward', data: null }));
              } catch {
                searchBox.dispatchEvent(new Event('input', { bubbles: true }));
              }

              focusEnd(searchBox);
              await new Promise((resolve) => setTimeout(resolve, 50));
              try { document.execCommand('insertText', false, searchText); } catch {}
              try {
                searchBox.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: searchText }));
              } catch {
                searchBox.dispatchEvent(new Event('input', { bubbles: true }));
              }

              await new Promise((resolve) => setTimeout(resolve, 120));
              const finalText = (searchBox.innerText || searchBox.textContent || '').replace(/\u200B/g, '');
              return {
                ok: normalize(finalText).includes(normalize(searchText)) || normalize(finalText) === normalize(searchText),
                text: finalText.slice(0, 80),
                via: 'whatsapp-search-main-world',
              };
            },
            args: [text],
          });

          const result = results?.[0]?.result;
          console.log('[Futnor Background] INJECT_WHATSAPP_SEARCH result:', JSON.stringify(result));
          sendResponse({ success: result?.ok === true, result });
        } catch (e) {
          console.error('[Futnor Background] INJECT_WHATSAPP_SEARCH error:', e.message);
          sendResponse({ success: false, error: e.message });
        }
      })();
      return true;
    }
    case 'INJECT_WHATSAPP_SEND': {
      (async () => {
        try {
          const tabId = sender?.tab?.id;
          if (!tabId) { sendResponse({ success: false, error: 'no tabId' }); return; }
          const message = msg.message || '';
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: (expectedText) => {
              function normalize(value) {
                return (value || '').toString().replace(/\u200B/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
              }
              function composerText(el) {
                if (!el) return '';
                return ((typeof el.innerText === 'string' && el.innerText.length > 0) ? el.innerText : (el.textContent || '')).replace(/\u200B/g, '');
              }
              function activate(node) {
                const target = node?.closest?.('button, [role="button"], [tabindex]') || node;
                if (!target) return false;
                try { target.focus?.({ preventScroll: true }); } catch {}
                const pointerOpts = { bubbles: true, cancelable: true, isPrimary: true, button: 0, buttons: 1 };
                const mouseOpts = { bubbles: true, cancelable: true, button: 0, buttons: 1 };
                try { target.dispatchEvent(new PointerEvent('pointerdown', pointerOpts)); } catch {}
                try { target.dispatchEvent(new MouseEvent('mousedown', mouseOpts)); } catch {}
                try { target.dispatchEvent(new PointerEvent('pointerup', { ...pointerOpts, buttons: 0 })); } catch {}
                try { target.dispatchEvent(new MouseEvent('mouseup', { ...mouseOpts, buttons: 0 })); } catch {}
                try { target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0 })); } catch {}
                try { target.click?.(); } catch {}
                return true;
              }
              function getComposer() {
                const composerSelectors = [
                  'div[data-testid="conversation-compose-box-input"]',
                  'div[contenteditable="true"][data-tab="10"]',
                  '#main footer div[contenteditable="true"]',
                  'footer div[contenteditable="true"]',
                  '#main div[role="textbox"][contenteditable="true"]',
                  '#main div[contenteditable="true"]',
                ];

                for (const sel of composerSelectors) {
                  const candidate = document.querySelector(sel);
                  if (!candidate) continue;
                  const rect = candidate.getBoundingClientRect();
                  if (rect.width < 40 || rect.height < 18) continue;
                  const aria = (candidate.getAttribute('aria-label') || candidate.getAttribute('title') || '').toLowerCase();
                  const placeholder = (candidate.getAttribute('data-placeholder') || candidate.getAttribute('placeholder') || '').toLowerCase();
                  if (
                    aria.includes('search') ||
                    placeholder.includes('search') ||
                    aria.includes('buscar') ||
                    placeholder.includes('buscar') ||
                    aria.includes('rechercher') ||
                    placeholder.includes('rechercher')
                  ) continue;
                  return candidate;
                }
                return null;
              }
              const sendSelectors = [
                '#main footer button[data-testid="compose-btn-send"]',
                '#main footer [data-testid="compose-btn-send"]',
                '#main footer button span[data-testid="send"]',
                '#main footer span[data-testid="send"]',
                '#main footer span[data-icon="send"]',
                '#main footer span[data-icon="send-filled"]',
                '#main footer button[aria-label*="Send"]',
                '#main footer button[aria-label*="Envoyer"]',
                '#main footer button[aria-label*="Enviar"]',
                '#main footer [role="button"][aria-label*="Send"]',
              ];

              const composer = getComposer();
              const currentText = normalize(composerText(composer));
              const expected = normalize(expectedText);
              const hasText = currentText.length > 0;
              const textMatches = !expected || currentText === expected || currentText.includes(expected.slice(0, 24)) || expected.includes(currentText);

              if (!composer || !hasText || !textMatches) {
                return {
                  ok: false,
                  reason: !composer ? 'no composer or send button' : (!hasText ? 'composer_empty' : 'composer_text_mismatch'),
                  composerText: composerText(composer).slice(0, 80),
                };
              }

              for (const sel of sendSelectors) {
                const node = document.querySelector(sel);
                if (!node) continue;
                const rect = node.getBoundingClientRect();
                if (rect.width < 12 || rect.height < 12) continue;
                activate(node);
                return { ok: true, via: 'whatsapp-send-button', selector: sel };
              }
              if (!composer) return { ok: false, reason: 'no composer or send button' };

              try { composer.focus?.({ preventScroll: true }); } catch {}
              const opts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
              composer.dispatchEvent(new KeyboardEvent('keydown', opts));
              composer.dispatchEvent(new KeyboardEvent('keypress', opts));
              composer.dispatchEvent(new KeyboardEvent('keyup', { ...opts, cancelable: false }));
              return { ok: true, via: 'whatsapp-enter-fallback' };
            },
            args: [message],
          });

          const result = results?.[0]?.result;
          console.log('[Futnor Background] INJECT_WHATSAPP_SEND result:', JSON.stringify(result));
          sendResponse({ success: result?.ok === true, result });
        } catch (e) {
          console.error('[Futnor Background] INJECT_WHATSAPP_SEND error:', e.message);
          sendResponse({ success: false, error: e.message });
        }
      })();
      return true;
    }
    case 'PING':
      sendResponse({ status: 'connected', ready: true });
      break;
    case 'PING_EXTENSION':
      sendResponse({ status: 'connected', ready: true });
      break;
    case 'REQUEST_ACTIVE_ACCOUNT_DETECTION':
      // Dashboard bridge calls this when its localStorage mirror is empty,
      // so users on every plan get an immediate detection attempt instead of
      // waiting for the SW startup poll cycle.
      (async () => {
        const username = await detectAndSyncActiveAccount('instagram').catch(() => null);
        sendResponse({ success: !!username, username: username || null });
      })();
      return true; // async sendResponse
    case 'RESET_ACTIVE_ACCOUNT':
      // Explicit reset path. Used when the user switches the logged-in IG
      // account in Chrome and wants the extension to re-detect from scratch.
      // Without this, the hard guard in detectAndSyncActiveAccount would
      // refuse to ever change the stored account.
      (async () => {
        console.log(`[Futnor Background] RESET_ACTIVE_ACCOUNT (was: ${activeAccountUsername || '(none)'})`);
        activeAccountUsername = null;
        try { await chrome.storage.local.remove('futnor_active_account'); } catch {}
        const username = await detectAndSyncActiveAccount('instagram').catch(() => null);
        sendResponse({ success: true, username: username || null });
      })();
      return true; // async sendResponse
    case 'GET_ACTIVE_ACCOUNT':
      sendResponse({ username: activeAccountUsername || null });
      break;
    case 'GET_STATE':
      sendResponse({ ...sessionState, warmup: warmupState });
      break;
    case 'START_SESSION':
      (async () => {
        const startFingerprint = getSessionStartFingerprint(msg);
        console.log('[Futnor Background] START_SESSION received:', msg, 'fingerprint:', startFingerprint);

        if (pendingSessionStart) {
          console.log('[Futnor Background] START_SESSION already in progress, joining existing request:', pendingSessionStartFingerprint);
          try {
            const result = await pendingSessionStart;
            sendResponse(result);
          } catch (error) {
            sendResponse({ ok: false, status: 'start_failed', reason: 'start_in_progress_failed', message: error?.message || 'Concurrent start failed' });
          }
          return;
        }

        pendingSessionStartFingerprint = startFingerprint;
        pendingSessionStart = (async () => {
          if (sessionState.isRunning && !sessionState.isPaused && !sessionState.reconnecting) {
            return { ok: true, status: 'session_started', alreadyRunning: true, tabId: preferredInstagramTabId || null };
          }

          const stored = await chrome.storage.local.get(['subscriptionTier', 'futnor_user_id']);
          // Accept tier from the message itself (dashboard passes it directly)
          const msgTier = msg.tier || msg.subscriptionTier;

          // Build tier from all sources, but NEVER silently default to 'free' —
          // if the user has a futnor_user_id they've authenticated and their tier
          // may simply not have been passed in this message.  Treat that as a
          // recoverable "unknown" state instead of an instant block.
          const rawResolvedTier = msgTier || stored.subscriptionTier || sessionState.tier;
          const hasUserId = !!(stored.futnor_user_id || msg.userId);
          const rawTier = rawResolvedTier || (hasUserId ? 'pending' : 'free');
          const tier = rawTier === 'pending' ? 'pending' : normalizeTier(rawTier);

          console.log('[Futnor Background] Tier check - msg:', msgTier,
            'stored:', stored.subscriptionTier,
            'sessionState:', sessionState.tier,
            'hasUserId:', hasUserId,
            'raw:', rawTier,
            'normalized:', tier);

          // Persist the tier from the message so future sessions work without needing it resent.
          // Store the normalized form so downstream reads (popup, dashboard sync) stay consistent
          // regardless of what casing / variant the dashboard sent this time.
          if (msgTier && normalizeTier(msgTier) !== 'free') {
            const normalizedMsgTier = normalizeTier(msgTier);
            chrome.storage.local.set({ subscriptionTier: normalizedMsgTier }).catch(() => {});
            sessionState.tier = normalizedMsgTier;
          }

          if (tier === 'free') {
            // Last-chance refresh from Supabase — the user may have just
            // started a trial on the dashboard and the bridge hasn't fired
            // syncTier() yet.  If Supabase confirms a paid / trial tier,
            // flip the block and continue; otherwise stay blocked.
            const refreshed = hasUserId
              ? await refreshSubscriptionFromSupabase().catch(() => null)
              : null;
            if (refreshed && refreshed !== 'free') {
              console.log('[Futnor Background] Tier refreshed just-in-time:', refreshed);
              sessionState.tier = refreshed;
            } else {
              console.log('[Futnor Background] Free tier - session blocked');
              addLog('session_blocked', 'Session blocked — subscription or trial required');
              return { ok: false, status: 'start_rejected', reason: 'no_subscription', tabId: null };
            }
          }

          if (tier === 'pending') {
            // User is authenticated but tier wasn't passed — likely a dashboard sync issue.
            // Log it clearly so it's debuggable, but don't block the session.
            console.warn('[Futnor Background] Tier could not be determined for authenticated user — allowing session but flagging for dashboard re-sync');
            addLog('tier_warning', 'Tier unknown — session allowed, but please refresh your dashboard to sync your subscription');
          }

          console.log('[Futnor Background] Tier approved:', tier);

          if (msg.config) {
            const incomingConfig = { ...msg.config };
            if (Object.prototype.hasOwnProperty.call(incomingConfig, 'dmTemplates')) {
              sessionState.dmTemplates = sanitizeDMTemplates(incomingConfig.dmTemplates);
              console.log('[Futnor Background] DM templates loaded:', sessionState.dmTemplates.length);
              delete incomingConfig.dmTemplates;
            }
            sessionState.config = sanitizeSessionConfig({ ...sessionState.config, ...incomingConfig });
          } else {
            sessionState.config = sanitizeSessionConfig(sessionState.config);
          }
          if (msg.platform) sessionState.platform = msg.platform;
          if (msg.targeting) sessionState.targeting = { ...DEFAULT_STATE.targeting, ...msg.targeting };
          if (msg.aiTargeting) sessionState.aiTargeting = msg.aiTargeting;

          console.log('[Futnor Background] Session config applied:', {
            platform: sessionState.platform,
            targeting: sessionState.targeting?.targetTypes,
            aiEnabled: sessionState.aiTargeting?.enabled
          });

          if (sessionState.dmTemplates.length === 0) {
            addLog('dm_skipped', 'ERROR: DM script is empty or not loaded');
            return { ok: false, status: 'start_rejected', reason: 'missing_dm_script', tabId: null };
          }

          const ai = sessionState.aiTargeting;
          const isAI = ai?.enabled && (ai.searchTerms?.length > 0 || ai.keywords?.length > 0);
          const t = sessionState.targeting;
          const hasManualTarget = t?.targetTypes?.length > 0 && (
            (t.targetTypes.includes('hashtags') && t.hashtags?.trim()) ||
            (t.targetTypes.includes('location') && t.location?.trim()) ||
            ((t.targetTypes.includes('followers') || t.targetTypes.includes('following')) && t.targetUsername?.trim()) ||
            ((t.targetTypes.includes('likers') || t.targetTypes.includes('commenters')) && t.targetPostLink?.trim()) ||
            (t.targetTypes.includes('custom') && t.customUsernames?.length > 0)
          );

          console.log('[Futnor Background] Targeting validation - AI:', isAI, 'Manual:', hasManualTarget);

          if (!isAI && !hasManualTarget) {
            console.log('[Futnor Background] No targeting configured - session blocked');
            addLog('session_blocked', 'Set up targeting on the dashboard before starting');
            return { ok: false, status: 'start_rejected', reason: 'no_targeting', tabId: null };
          }

          const platform = sessionState.platform;
          const shouldResumeExistingSession = sessionState.isPaused
            && (sessionState.stats.sessionTime || 0) > (sessionState.stats.elapsedTime || 0);

          if (!shouldResumeExistingSession) {
            sessionState.stats = { dmsSent: 0, likesSent: 0, followsSent: 0, scrolls: 0, elapsedTime: 0, sessionTime: 0 };
            sessionState.logs = [];
          }

          const primeResult = await primePlatformTabForSession(platform, {
            createIfMissing: true,
            focus: true,
            sessionSignal: shouldResumeExistingSession ? 'SESSION_RESUME' : 'SESSION_START',
          });

          if (!primeResult.ok) {
            console.log('[Futnor Background] Session preflight failed:', primeResult.reason);
            return { ok: false, status: 'start_failed', reason: primeResult.reason || 'start_preflight_failed', tabId: null };
          }

          // Pre-session force-detect: with the tab open and the content script
          // ready, sync the logged-in user one last time BEFORE isRunning flips.
          // After isRunning is true, the detectAndSync guard refuses to replace
          // the active account — so any wrong value (e.g. detected earlier on a
          // /p/ page where the post author's header link leaked through) would
          // stay stuck. Doing one clean detect here, while the guard is still
          // open, is the last chance to correct it for commenters targeting.
          if (platform === 'instagram' && !shouldResumeExistingSession) {
            try {
              await detectAndSyncActiveAccount('instagram');
            } catch {}
          }

          sessionState.tier = tier;
          sessionState.isRunning = true;
          sessionState.isPaused = false;
          sessionState.reconnecting = false;
          saveState();

          // Include tabId in all success responses — the dashboard expects it
          const sessionTabId = primeResult.tab?.id || null;

          if (shouldResumeExistingSession && sessionLoopActive) {
            addLog('session_start', '▶️ Session resumed (loop still active)');
            saveState();
            return { ok: true, status: 'session_started', resumed: true, tabId: sessionTabId };
          }

          sessionLoopPromise = runSession({ resume: shouldResumeExistingSession }).catch((error) => {
            console.error(
              shouldResumeExistingSession
                ? '[Futnor Background] Session failed after resume:'
                : '[Futnor Background] Session failed after start:',
              error?.message || error
            );
            sessionLoopActive = false;
            sessionLoopPromise = null;
            sessionState.isRunning = false;
            sessionState.isPaused = false;
            sessionState.reconnecting = false;
            saveState();
          });

          return { ok: true, status: 'session_started', resumed: shouldResumeExistingSession, tabId: sessionTabId };
        })();

        try {
          const result = await pendingSessionStart;
          sendResponse(result || { ok: false, status: 'start_failed', reason: 'no_response', tabId: null });
        } catch (e) {
          console.error('[Futnor Background] pendingSessionStart threw:', e?.message || e);
          sendResponse({ ok: false, status: 'start_failed', reason: 'internal_error', message: e?.message, tabId: null });
        } finally {
          pendingSessionStart = null;
          pendingSessionStartFingerprint = null;
        }
      })();
      return true; // Keep message channel open for async response
      break;
    case 'START_WARMUP':
      if (!warmupState.isRunning) {
        const platform = msg.platform || sessionState.platform;
        sessionState.platform = platform;
        runWarmup(msg.sessionMinutes || 20, platform, msg.enableComments || false);
      }
      sendResponse({ ok: true });
      break;
    case 'STOP_WARMUP':
      warmupState.isRunning = false;
      clearWarmupPersistence();
      sendResponse({ ok: true });
      break;
    case 'GET_WARMUP_STATE':
      sendResponse(warmupState);
      break;
    case 'PAUSE_SESSION':
      if (sessionState.isRunning && !sessionState.isPaused) {
        sessionState.isPaused = true;
        addLog('session_start', '⏸️ Session paused');
        saveState();
        // Immediately abort any in-progress content script operation
        signalContentScriptStop('SESSION_PAUSE');
      }
      sendResponse({ ok: true });
      break;
    case 'RESUME_SESSION':
      (async () => {
        if (sessionState.isRunning && sessionState.isPaused) {
          try {
            const primeResult = await primePlatformTabForSession(sessionState.platform, {
              createIfMissing: true,
              focus: true,
              sessionSignal: 'SESSION_RESUME',
            });

            if (!primeResult.ok) {
              sessionState.isPaused = true;
              sessionState.reconnecting = true;
              saveState();
              addLog('session_start', 'Reconnecting to extension...');
              sendResponse({ ok: true });
              return;
            }

            sessionState.isPaused = false;
            sessionState.reconnecting = false;
            addLog('session_start', '▶️ Session resumed');
            saveState();

            if (!sessionLoopActive) {
              sessionLoopPromise = runSession({ resume: true }).catch((error) => {
                console.error('[Futnor Background] Session failed after resume:', error?.message || error);
                sessionLoopActive = false;
                sessionLoopPromise = null;
                sessionState.isRunning = false;
                sessionState.isPaused = false;
                sessionState.reconnecting = false;
                saveState();
              });
            }
          } catch (error) {
            sessionState.isPaused = true;
            sessionState.reconnecting = true;
            saveState();
            console.error('[Futnor Background] Resume handshake failed:', error?.message || error);
          }
        }
        sendResponse({ ok: true });
      })();
      return true;
      break;
    case 'STOP_SESSION':
      sessionState.isRunning = false;
      sessionState.isPaused = false;
      sessionState.reconnecting = false;
      sessionLoopActive = false;
      sessionLoopPromise = null;
      engagementMonitorActive = false;
      addLog('session_end', 'Stopped by user');
      saveState();
      hideBannerOnPlatformTab(sessionState.platform);
      // Immediately abort any in-progress content script operation
      signalContentScriptStop('SESSION_STOP');
      sendResponse({ ok: true });
      break;
    case 'START_ENGAGEMENT_MONITOR':
      (async () => {
        if (sessionState.isRunning) {
          sendResponse({ ok: false, reason: 'session_already_running' });
          return;
        }
        const monitorConfig = msg.engagementMonitor;
        const hasUrls = (monitorConfig?.postUrls?.length > 0) || monitorConfig?.postUrl;
        if (!hasUrls || !monitorConfig?.dmScript) {
          sendResponse({ ok: false, reason: 'missing_config' });
          return;
        }
        sendResponse({ ok: true, status: 'monitor_started' });
        runEngagementMonitor(monitorConfig).catch(e => {
          console.error('[Futnor Background] Engagement monitor crashed:', e);
          engagementMonitorActive = false;
          sessionState.isRunning = false;
          saveState();
        });
      })();
      return true;
    case 'STOP_ENGAGEMENT_MONITOR':
      engagementMonitorActive = false;
      sessionState.isRunning = false;
      addLog('session_end', 'Engagement monitor stopped by user');
      saveState();
      hideBannerOnPlatformTab('instagram');
      signalContentScriptStop('MONITOR_STOP');
      sendResponse({ ok: true });
      break;
    case 'RESET_STATS':
      sessionState.stats = { dmsSent: 0, likesSent: 0, followsSent: 0, scrolls: 0, elapsedTime: 0, sessionTime: 0 };
      sessionState.logs = [];
      sessionState.reconnecting = false;
      // Clear visited posts so fresh sessions start clean
      chrome.storage.local.remove('futnor_visited_posts');
      saveState();
      sendResponse({ ok: true });
      break;
    case 'UPDATE_CONFIG':
      sessionState.config = msg.config;
      saveState();
      sendResponse({ ok: true });
      break;
    case 'CLEAR_WARMUP_OFFER':
      sessionState.warmupOffer = false;
      sendResponse({ ok: true });
      break;
    case 'SET_PLATFORM':
      if (!sessionState.isRunning) {
        sessionState.platform = msg.platform;
        saveState();
      }
      sendResponse({ ok: true, platform: sessionState.platform });
      break;
    case 'SET_SUBSCRIPTION_TIER': {
      // Called by the dashboard to persist the user's subscription tier in the extension.
      // Store normalized so a `scale_trial` / `Growth` / `trialing` payload from the
      // billing provider doesn't mysteriously render as "Free Plan" in the popup.
      const incomingTier = msg.tier || msg.subscriptionTier;
      if (incomingTier && typeof incomingTier === 'string') {
        const normalized = normalizeTier(incomingTier);
        sessionState.tier = normalized;
        chrome.storage.local.set({ subscriptionTier: normalized }).catch(() => {});
        console.log('[Futnor Background] Subscription tier set to:', incomingTier, '→', normalized);
        sendResponse({ ok: true, tier: normalized });
      } else {
        sendResponse({ ok: false, error: 'Invalid tier value' });
      }
      break;
    }
    case 'REFRESH_TIER': {
      // On-demand tier refresh from Supabase — the popup fires this on open
      // when it has no stored tier but the user is authenticated, so a
      // user who started a Scale / Growth trial on the dashboard and never
      // reopened that tab gets the right badge the first time they open
      // the popup (instead of seeing "Free Plan" until the dashboard syncs).
      (async () => {
        try {
          const tier = await refreshSubscriptionFromSupabase({ force: !!msg.force });
          sendResponse({ ok: true, tier: tier || null });
        } catch (e) {
          sendResponse({ ok: false, error: e?.message || 'refresh_failed' });
        }
      })();
      return true; // async
    }
    case 'FOCUS_BOT_TAB': {
      const platform = msg.platform || sessionState.platform;
      (async () => {
        const tab = await getOrCreatePlatformTab(platform, { createIfMissing: true, focus: true });
        sendResponse({ ok: !!tab });
      })();
      return true; // async
    }

    // ── Sales Agent Commands ──
    case 'START_SALES_AGENT': {
      (async () => {
        try {
          salesAgentRepliedSet.clear();
          salesAgentConfig = {
            active: true,
            platform: msg.platform || 'instagram',
            interval: msg.interval || 45000,
          };
          const storagePayload = { futnor_sales_agent_config: salesAgentConfig };
          if (msg.authToken) {
            storagePayload.futnor_supabase_token = msg.authToken;
          }
          await chrome.storage.local.set(storagePayload);
          if (!salesAgentLoopActive) {
            runSalesAgentLoop();
          }
          await showBannerOnPlatformTab(salesAgentConfig.platform, 'sales-agent');
          updateSalesAgentStatus({ active: true });
          sendResponse({ ok: true });
        } catch (e) {
          sendResponse({ ok: false, error: e.message });
        }
      })();
      return true;
    }
    case 'STOP_SALES_AGENT': {
      salesAgentConfig.active = false;
      salesAgentLoopActive = false;
      salesAgentRepliedSet.clear();
      chrome.storage.local.set({ futnor_sales_agent_config: salesAgentConfig });
      hideBannerOnPlatformTab(salesAgentConfig.platform);
      updateSalesAgentStatus({ active: false });
      sendResponse({ ok: true });
      break;
    }
  }
  return true;
});

// ─── Sales Agent Auto-Reply Loop ────────────────────────────────────────────

let salesAgentConfig = { active: false, platform: 'instagram', interval: 45000 };
let salesAgentLoopActive = false;
let salesAgentRepliedSet = new Set(); // Track handled thread states this session

function getSalesAgentThreadKey(platform, thread) {
  return [
    platform || 'instagram',
    (thread?.username || '').toString().trim().toLowerCase(),
    (thread?.messageFingerprint || thread?.lastMessage || '').toString().trim().toLowerCase(),
    Number(thread?.unreadCount || 0),
  ].join('::');
}

// Load persisted config on startup
(async () => {
  try {
    const stored = await chrome.storage.local.get('futnor_sales_agent_config');
    if (stored.futnor_sales_agent_config) {
      salesAgentConfig = stored.futnor_sales_agent_config;
      if (salesAgentConfig.active && !salesAgentLoopActive) {
        runSalesAgentLoop();
      }
    }
  } catch {}
})();

function updateSalesAgentStatus(overrides = {}) {
  const status = {
    active: salesAgentConfig.active,
    platform: salesAgentConfig.platform || 'instagram',
    lastScan: Date.now(),
    ...overrides,
  };
  chrome.storage.local.set({ futnor_sales_agent_status: status });
}

function normalizeSalesAgentBaseUrl(baseUrl) {
  const value = (baseUrl || '').toString().trim().replace(/\/$/, '');
  if (!value) return '';
  if (/^https?:\/\//i.test(value)) return value;
  return `https://${value}`;
}

async function getBestWhatsAppTab() {
  const tabs = await chrome.tabs.query({ url: PLATFORM_URLS.whatsapp });
  if (!tabs.length) return null;

  return [...tabs].sort((left, right) => {
    const activeDelta = Number(Boolean(right.active)) - Number(Boolean(left.active));
    if (activeDelta !== 0) return activeDelta;
    return Number(right.lastAccessed || 0) - Number(left.lastAccessed || 0);
  })[0];
}

async function runSalesAgentLoop() {
  if (salesAgentLoopActive) return;
  salesAgentLoopActive = true;
  console.log('[Futnor] Sales agent loop started');

  while (salesAgentConfig.active && salesAgentLoopActive) {
    try {
      await performSalesAgentScan();
      updateSalesAgentStatus({ active: true });
    } catch (e) {
      console.error('[Futnor] Sales agent scan error:', e);
    }

    // Wait before next scan (30-60s randomized)
    const delay = salesAgentConfig.interval + Math.floor(Math.random() * 15000);
    await new Promise(r => setTimeout(r, delay));
  }

  salesAgentLoopActive = false;
  console.log('[Futnor] Sales agent loop stopped');
}

async function performSalesAgentScan() {
  const platform = salesAgentConfig.platform || 'instagram';
  console.log(`[Futnor] Sales agent scanning ${platform} inbox...`);

  // Platform-specific inbox URLs and base domains
  const platformConfig = {
    instagram: {
      inboxUrl: 'https://www.instagram.com/direct/inbox/',
      baseDomain: 'https://www.instagram.com',
      contentScript: 'instagram/content.js',
    },
    tiktok: {
      inboxUrl: 'https://www.tiktok.com/messages',
      baseDomain: 'https://www.tiktok.com',
      contentScript: 'tiktok/content.js',
    },
    whatsapp: {
      inboxUrl: 'https://web.whatsapp.com/',
      baseDomain: 'https://web.whatsapp.com',
      contentScript: 'whatsapp/content.js',
    },
  };

  const config = platformConfig[platform] || platformConfig.instagram;

  // For WhatsApp, find existing tab or create one (don't navigate away from an active chat)
  let tab;
  if (platform === 'whatsapp') {
    const existingTab = await getBestWhatsAppTab();
    if (existingTab) {
      tab = existingTab;
      console.log(`[Futnor] Sales agent: found existing WhatsApp tab ${tab.id}`);
    } else {
      console.log('[Futnor] Sales agent: opening new WhatsApp Web tab...');
      tab = await chrome.tabs.create({ url: config.inboxUrl, active: false });
      await waitMs(10000); // WhatsApp Web takes longer to load
    }
  } else {
    tab = await getOrCreatePlatformTab(platform, { createIfMissing: true, focus: false });
    if (!tab?.id) {
      console.log('[Futnor] Sales agent: no platform tab available');
      return;
    }
    // Navigate to inbox
    await new Promise((resolve, reject) => {
      chrome.tabs.update(tab.id, { url: config.inboxUrl }, () => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });
    await waitMs(4000);
  }

  if (!tab?.id) {
    console.log('[Futnor] Sales agent: no tab available after setup');
    return;
  }

  // Ensure content script is ready
  let contentScriptReady = false;
  try {
    const pingResult = await new Promise((resolve) => {
      chrome.tabs.sendMessage(tab.id, { type: 'PING' }, (res) => {
        if (chrome.runtime.lastError) resolve(null);
        else resolve(res);
      });
    });
    contentScriptReady = !!pingResult?.ready;
    console.log(`[Futnor] Sales agent: content script PING result:`, contentScriptReady);
  } catch {}

  if (!contentScriptReady) {
    console.log(`[Futnor] Sales agent: injecting ${platform} content script...`);
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: [config.contentScript],
      });
      await waitMs(2000);
      // Verify injection
      const verifyPing = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tab.id, { type: 'PING' }, (res) => {
          if (chrome.runtime.lastError) resolve(null);
          else resolve(res);
        });
      });
      console.log(`[Futnor] Sales agent: post-injection PING:`, !!verifyPing?.ready);
      if (!verifyPing?.ready) {
        console.log('[Futnor] Sales agent: content script not responding after injection, aborting scan');
        return;
      }
    } catch (e) {
      console.error(`[Futnor] Sales agent: script injection failed:`, e.message);
      return;
    }
  } else {
    await waitMs(1000);
  }

  if (platform === 'whatsapp') {
    await showBannerOnPlatformTab(platform, 'sales-agent');
  }

  // Scan for unread DMs
  let unreadThreads = [];
  try {
    const response = await new Promise((resolve) => {
      const timeout = setTimeout(() => resolve(null), 10000); // 10s timeout
      chrome.tabs.sendMessage(tab.id, {
        type: 'SALES_AGENT_ACTION',
        action: 'scanInboxForNewDMs',
      }, (res) => {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) {
          console.log('[Futnor] Sales agent: scanInbox message error:', chrome.runtime.lastError.message);
          resolve(null);
        } else {
          resolve(res);
        }
      });
    });

    console.log('[Futnor] Sales agent: scanInbox response:', JSON.stringify(response)?.substring(0, 200));

    if (response?.ok && response.threads?.length > 0) {
      unreadThreads = response.threads;
    }
  } catch (e) {
    console.error('[Futnor] Sales agent scan inbox failed:', e);
    return;
  }

  console.log(`[Futnor] Sales agent: found ${unreadThreads.length} unread threads on ${platform}`);

  // Track responses — any unread thread from a user we previously DMed counts as a response
  if (unreadThreads.length > 0) {
    trackDMResponsesToSupabase(unreadThreads.map(t => t.username).filter(Boolean), platform);
  }

  // Process each unread thread
  for (const thread of unreadThreads) {
    if (!salesAgentConfig.active) break;
    const threadKey = getSalesAgentThreadKey(platform, thread);
    if (salesAgentRepliedSet.has(threadKey)) continue;

    try {
      // Get the Supabase auth token from storage
      const stored = await chrome.storage.local.get(['futnor_supabase_token', 'futnor_supabase_url', 'futnor_supabase_anon_key']);
      const token = stored.futnor_supabase_token;
      const baseUrl = normalizeSalesAgentBaseUrl(stored.futnor_supabase_url);
      const anonKey = stored.futnor_supabase_anon_key;

      if (!token || !baseUrl) {
        console.log('[Futnor] Sales agent: no auth token or URL, skipping. hasToken:', !!token, 'hasUrl:', !!baseUrl, 'hasAnonKey:', !!anonKey);
        updateSalesAgentStatus({
          active: salesAgentConfig.active,
          error: !token ? 'missing_auth_token' : 'missing_backend_url',
        });
        break;
      }

      console.log(`[Futnor] Sales agent: calling chat for @${thread.username} on ${platform}`);
      const response = await fetch(`${baseUrl}/functions/v1/sales-agent`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'apikey': anonKey || token,
        },
        body: JSON.stringify({
          action: 'chat',
          customerIdentifier: thread.username,
          customerMessage: thread.lastMessage || 'Hey',
          platform: platform,
          conversationHistory: Array.isArray(thread.conversationHistory) ? thread.conversationHistory : [],
        }),
      });

      const data = await response.json();
      console.log(`[Futnor] Sales agent response for @${thread.username}:`, response.status, data?.reply ? 'has reply' : 'no reply', data?.error || '');

      if (!response.ok) {
        updateSalesAgentStatus({
          active: salesAgentConfig.active,
          error: data?.error || `backend_${response.status}`,
        });
        continue;
      }

      if (data?.reply) {
        console.log(`[Futnor] Sales agent reply to @${thread.username}: ${data.reply.substring(0, 50)}...`);
        let replySent = false;

        // Platform-specific reply sending
        if (platform === 'whatsapp') {
          // Open the chat by name and send
          const openChatResult = await new Promise((resolve) => {
            chrome.tabs.sendMessage(tab.id, {
              type: 'SALES_AGENT_ACTION',
              action: 'openChat',
              contactName: thread.username,
              messageHint: thread.lastMessage || '',
            }, (res) => resolve(res));
          });
          if (!openChatResult?.ok) {
            console.log(`[Futnor] Sales agent: failed to open WhatsApp chat for @${thread.username}:`, openChatResult?.error || 'unknown_error');
            updateSalesAgentStatus({
              active: salesAgentConfig.active,
              error: openChatResult?.error || 'whatsapp_open_chat_failed',
            });
            continue;
          }
          await waitMs(2000);

          const sendMessageResult = await new Promise((resolve) => {
            chrome.tabs.sendMessage(tab.id, {
              type: 'SALES_AGENT_ACTION',
              action: 'sendMessage',
              message: data.reply,
            }, (res) => resolve(res));
          });
          if (!sendMessageResult?.ok) {
            console.log(`[Futnor] Sales agent: failed to send WhatsApp reply to @${thread.username}:`, sendMessageResult?.error || 'unknown_error');
            updateSalesAgentStatus({
              active: salesAgentConfig.active,
              error: sendMessageResult?.error || 'whatsapp_send_failed',
            });
            continue;
          }
          replySent = true;
        } else if (thread.href) {
          // Instagram / TikTok: navigate to thread URL and use sales agent reply
          const threadUrl = thread.href.startsWith('http')
            ? thread.href
            : `${config.baseDomain}${thread.href}`;

          await new Promise((resolve, reject) => {
            chrome.tabs.update(tab.id, { url: threadUrl }, () => {
              if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
              else resolve();
            });
          });
          await waitMs(3000);
          await ensureContentScript(tab.id, platform);
          await waitMs(1500);

          try {
            // Use SALES_AGENT_ACTION sendReply — bypasses deduplication
            // so the agent can reply to ongoing conversations
            const sendResult = await new Promise((resolve) => {
              chrome.tabs.sendMessage(tab.id, {
                type: 'SALES_AGENT_ACTION',
                action: 'sendReply',
                message: data.reply,
              }, (res) => {
                if (chrome.runtime.lastError) {
                  console.log('[Futnor] Sales agent sendReply error:', chrome.runtime.lastError.message);
                  resolve(null);
                } else {
                  resolve(res);
                }
              });
            });
            console.log(`[Futnor] Sales agent DM result for @${thread.username}:`, sendResult?.status || sendResult?.error);
            replySent = sendResult?.ok && sendResult?.status === 'dm_sent';
          } catch (e) {
            console.error(`[Futnor] Sales agent DM send failed for @${thread.username}:`, e);
          }
        }

        if (!replySent) {
          continue;
        }

        salesAgentRepliedSet.add(threadKey);
        updateSalesAgentStatus({ active: true, lastReplyAt: Date.now(), error: null });

        // Also add to DM history to prevent outreach bot from messaging them
        if (platform !== 'whatsapp') {
          addToDMHistory(thread.username);
        }

        // Human-like delay between threads
        await waitMs(getRandom(8000, 15000));
        continue;
      }

      updateSalesAgentStatus({
        active: salesAgentConfig.active,
        error: data?.error || 'empty_reply',
      });
    } catch (e) {
      console.error(`[Futnor] Sales agent error processing @${thread.username}:`, e);
      updateSalesAgentStatus({
        active: salesAgentConfig.active,
        error: e?.message || 'thread_processing_failed',
      });
    }
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'session-tick' && sessionState.isRunning && !sessionState.isPaused) {
    sessionState.stats.elapsedTime++;
  }
  // Warmup keepalive — just waking the service worker is enough
  if (alarm.name === 'warmup-keepalive') {
    console.log('[Futnor] Warmup keepalive ping');
  }
  // Idle keepalive — fires at all times to prevent MV3 service worker termination.
  // The dashboard pings the extension (PING_EXTENSION) continuously; if the service
  // worker is asleep those pings time out and the UI shows "disconnected".
  if (alarm.name === IDLE_KEEPALIVE_ALARM) {
    // Just being woken up by the alarm is enough — worker stays alive for another 30s
    console.log('[Futnor Background] Idle keepalive — worker active');
  }
});
