# Human Behavior Bot — Chrome Extension

Instagram & TikTok automation bot that mimics human behavior patterns.

## Installation

1. Download/clone this `chrome-extension` folder to your computer
2. Open Chrome → navigate to `chrome://extensions/`
3. Enable **Developer mode** (top right toggle)
4. Click **Load unpacked** → select this folder
5. Add icon files (16x16, 48x48, 128x128 PNG) to the `icons/` folder

## Usage

1. Navigate to `https://www.instagram.com/` or `https://www.tiktok.com/` and log in
2. Click the extension icon in Chrome toolbar
3. **Select your platform** — Instagram or TikTok
4. Configure session duration, delays, and daily limits
5. Click **Start** to begin the session
6. The bot will scroll, like, follow, and DM/comment with randomized timing

## Platform Differences

| Feature | Instagram | TikTok |
|---------|-----------|--------|
| Scrolling | Feed browsing | Video feed browsing |
| Liking | Like posts | Like videos |
| Following | Follow users | Follow creators |
| Engagement | Send DMs + GIFs | Post comments on videos |
| DM Messaging | Custom text + GIF | DM via messages tab |

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Extension configuration (Manifest V3) — both platforms |
| `background.js` | Service worker — platform-aware session logic |
| `instagram/content.js` | Instagram-specific DOM interactions |
| `tiktok/content.js` | TikTok-specific DOM interactions |
| `popup.html` | Extension popup UI with platform selector |
| `popup.js` | Popup logic — communicates with background worker |

## Important Notes

- **Platform ToS**: Automation violates both Instagram and TikTok Terms of Service. Use at your own risk.
- **Detection risk**: TikTok has more aggressive anti-bot detection than Instagram.
- **DOM selectors**: Both platforms frequently change their DOM structure. Selectors may need updates.
