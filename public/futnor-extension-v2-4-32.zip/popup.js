// Popup — lightweight control panel, syncs with background worker

const $ = (id) => document.getElementById(id);
const DASHBOARD_URL = 'https://futnor-dm-bot.lovable.app';

let currentPlatform = 'instagram';

// ─── Subscription / Tier Display ───
function updateTierDisplay(tier) {
  const badge = $('tierBadge');
  const banner = $('subBanner');
  const icon = $('subIcon');
  const tierText = $('subTierText');
  const detail = $('subDetail');
  const actionBtn = $('subActionBtn');

  badge.className = 'tier-badge';
  banner.className = 'sub-banner';

  const tiers = {
    trial:    { badge: '🎁 TRIAL',    cls: 'trial',    bannerCls: 'trial',   icon: '⏳', name: 'Free Trial Active',  desc: '14-day trial — all features unlocked', btn: 'Upgrade', link: '/pricing' },
    starter:  { badge: '⭐ STARTER',  cls: 'starter',  bannerCls: 'premium', icon: '⭐', name: 'Starter Plan',       desc: '$9/mo — Core automation',               btn: 'Manage',  link: '' },
    pro:      { badge: '💎 PRO',      cls: 'pro',      bannerCls: 'premium', icon: '💎', name: 'Pro Plan',           desc: '$29/mo — AI + advanced targeting',      btn: 'Manage',  link: '' },
    business: { badge: '👑 BUSINESS', cls: 'business', bannerCls: 'premium', icon: '👑', name: 'Business Plan',      desc: '$79/mo — Unlimited everything',         btn: 'Manage',  link: '' },
    admin:    { badge: '👑 ADMIN',    cls: 'admin',    bannerCls: 'premium', icon: '🛡️', name: 'Admin',              desc: 'Full access',                           btn: 'Dashboard', link: '' },
  };

  const t = tiers[tier] || { badge: 'FREE', cls: 'free', bannerCls: '', icon: '🔒', name: 'Free Plan', desc: 'Upgrade to unlock all features', btn: 'Upgrade', link: '/pricing' };

  badge.textContent = t.badge;
  badge.classList.add(t.cls);
  if (t.bannerCls) banner.classList.add(t.bannerCls);
  icon.textContent = t.icon;
  tierText.textContent = t.name;
  detail.textContent = t.desc;
  actionBtn.textContent = t.btn;
  actionBtn.className = 'sub-action-btn' + (t.btn === 'Manage' || t.btn === 'Dashboard' ? ' manage' : '');
  actionBtn.onclick = () => chrome.tabs.create({ url: DASHBOARD_URL + t.link });
}

// ─── Platform ───
function setPlatform(platform) {
  currentPlatform = platform;
  $('platformIG').classList.toggle('active', platform === 'instagram');
  $('platformTT').classList.toggle('active', platform === 'tiktok');
  $('dmLabel').textContent = platform === 'tiktok' ? 'Comments' : 'DMs';
  chrome.runtime.sendMessage({ type: 'SET_PLATFORM', platform });
}
$('platformIG').addEventListener('click', () => setPlatform('instagram'));
$('platformTT').addEventListener('click', () => setPlatform('tiktok'));

// ─── Auto-open platform tab ───
function openPlatformTab(platform) {
  const url = platform === 'tiktok' ? 'https://www.tiktok.com' : 'https://www.instagram.com';
  const pattern = platform === 'tiktok' ? 'https://www.tiktok.com/*' : 'https://www.instagram.com/*';
  chrome.tabs.query({ url: pattern }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.update(tabs[0].id, { active: true });
      chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      chrome.tabs.create({ url, active: true });
    }
  });
}

// ─── Controls ───
$('startBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (state) => {
    const tier = state?.tier || 'free';
    if (tier === 'free') {
      const banner = $('subBanner');
      banner.classList.add('shake');
      setTimeout(() => banner.classList.remove('shake'), 600);
      $('subDetail').textContent = '⚠️ Subscribe or start a trial to use the bot';
      chrome.tabs.create({ url: DASHBOARD_URL + '/pricing' });
      return;
    }

    const ai = state?.aiTargeting;
    const hasAI = ai?.enabled && ((ai.searchTerms?.length || 0) > 0 || (ai.keywords?.length || 0) > 0);
    const t = state?.targeting;
    const hasManual = t?.targetTypes?.length > 0 && (
      (t.targetTypes.includes('hashtags') && t.hashtags?.trim()) ||
      (t.targetTypes.includes('location') && t.location?.trim()) ||
      ((t.targetTypes.includes('followers') || t.targetTypes.includes('following')) && t.targetUsername?.trim()) ||
      ((t.targetTypes.includes('likers') || t.targetTypes.includes('commenters')) && t.targetPostLink?.trim()) ||
      (t.targetTypes.includes('custom') && t.customUsernames?.length > 0)
    );
    if (!hasAI && !hasManual) {
      $('idleHint').innerHTML = '<p style="color:#f59e0b;font-weight:600">⚠️ Set up targeting on the dashboard first</p><p>Configure who to reach before starting a session.</p>';
      chrome.tabs.create({ url: DASHBOARD_URL + '/#section-targeting' });
      return;
    }

    chrome.runtime.sendMessage({ type: 'START_SESSION', platform: currentPlatform }, (resp) => {
      if (resp?.status === 'session_started') {
        updateUI(true);
        return;
      }

      if (resp?.reason === 'no_targeting') {
        $('idleHint').innerHTML = '<p style="color:#f59e0b;font-weight:600">⚠️ Set up targeting first</p>';
        chrome.tabs.create({ url: DASHBOARD_URL + '/#section-targeting' });
        return;
      }

      $('idleHint').innerHTML = '<p style="color:#ef4444;font-weight:600">⚠️ Extension connected but failed to start session</p><p>Make sure Instagram is open and the extension content script is ready.</p>';
    });
  });
});

$('stopBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'STOP_SESSION' });
  updateUI(false);
});

$('resetBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'RESET_STATS' });
  updateStats({ dmsSent: 0, likesSent: 0, followsSent: 0, scrolls: 0 });
  $('logContainer').innerHTML = '<div class="log-empty">Waiting for actions…</div>';
});

$('dashboardBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: DASHBOARD_URL });
});

// ─── Bot Name (editable, persisted) ───
const botNameEl = $('statusText');
chrome.storage.local.get(['botName'], (r) => {
  if (r.botName) botNameEl.textContent = r.botName;
});
botNameEl.addEventListener('blur', () => {
  const name = botNameEl.textContent.trim() || 'My Bot';
  botNameEl.textContent = name;
  chrome.storage.local.set({ botName: name });
});
botNameEl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); botNameEl.blur(); }
});

// ─── UI Updates ───
function updateUI(running) {
  $('startBtn').style.display = running ? 'none' : 'block';
  $('stopBtn').style.display = running ? 'block' : 'none';
  $('resetBtn').disabled = running;
  $('statusDot').className = `status-dot ${running ? 'running' : 'stopped'}`;
  // Don't overwrite the custom bot name
  $('livePanel').style.display = running ? 'block' : 'none';
  $('idleHint').style.display = running ? 'none' : 'block';
  $('platformIG').disabled = running;
  $('platformTT').disabled = running;
}

function updateStats(s) {
  $('scrolls').textContent = s.scrolls || 0;
  $('likes').textContent = s.likesSent || 0;
  $('follows').textContent = s.followsSent || 0;
  $('dms').textContent = s.dmsSent || 0;
}

function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function updateProgress(stats) {
  if (stats.sessionTime > 0) {
    const pct = Math.min(100, (stats.elapsedTime / stats.sessionTime) * 100);
    $('progressFill').style.width = pct + '%';
    $('progressText').textContent = `${formatTime(stats.elapsedTime)} / ${formatTime(stats.sessionTime)}`;
  }
}

function getActionClass(action) {
  if (!action) return '';
  if (action.includes('scroll')) return 'action-scroll';
  if (action.includes('like')) return 'action-like';
  if (action.includes('follow')) return 'action-follow';
  if (action.includes('dm') || action.includes('comment')) return 'action-dm';
  if (action.includes('session')) return 'action-session';
  return '';
}

function updateLogs(logs) {
  if (!logs || logs.length === 0) return;
  $('logContainer').innerHTML = logs.slice(0, 15).map(log => {
    const time = new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const cls = getActionClass(log.action || '');
    return `<div class="log-entry"><span class="time">${time}</span><span class="${cls}">${log.message}</span></div>`;
  }).join('');
}

// ─── Poll state from background ───
function refreshState() {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (state) => {
    if (!state) return;
    updateUI(state.isRunning);
    updateStats(state.stats || {});
    updateProgress(state.stats || {});
    updateLogs(state.logs);
    if (state.tier) updateTierDisplay(state.tier);
    if (state.platform && state.platform !== currentPlatform) setPlatform(state.platform);
  });
}

// ─── Init ───
chrome.storage.local.get(['subscriptionTier'], (result) => {
  updateTierDisplay(result.subscriptionTier || 'free');
});

// Listen for tier changes from the web app
chrome.storage.onChanged.addListener((changes) => {
  if (changes.subscriptionTier) {
    updateTierDisplay(changes.subscriptionTier.newValue || 'free');
  }
});

refreshState();
setInterval(refreshState, 1000);
